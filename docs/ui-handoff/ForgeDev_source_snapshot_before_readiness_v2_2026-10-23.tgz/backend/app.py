from dotenv import load_dotenv
load_dotenv()
import os
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, create_refresh_token, jwt_required, get_jwt_identity, decode_token, verify_jwt_in_request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta, timezone
from functools import wraps
import subprocess, sys, time, csv, json, io, unicodedata, re, base64, secrets, string
from io import StringIO
from sqlalchemy import text, inspect, distinct
from sqlalchemy.exc import IntegrityError, OperationalError
import logging
import uuid as _uuid
logger = logging.getLogger('forge')
from routes.sandbox import sandbox_bp, _run_in_docker, handles_setup_errors
import re as _re
from datetime import datetime as _dt, timedelta as _td
from collections import defaultdict as _dd

app = Flask(__name__)
app.register_blueprint(sandbox_bp)

# FORGE_ENV=production (set in docker-compose.yml) switches on strict config:
# the app refuses to start on missing/placeholder secrets instead of silently
# falling back to the public dev defaults below, and the debugger is forced off.
FORGE_ENV = os.environ.get('FORGE_ENV', 'development').strip().lower()
IS_PRODUCTION = FORGE_ENV == 'production'

_DEV_SECRET_KEY = 'dev-secret-change-in-production'
_DEV_JWT_SECRET_KEY = 'jwt-secret-change-in-production'
_PLACEHOLDER_SECRETS = {'', 'change-me', 'change-me-too', _DEV_SECRET_KEY, _DEV_JWT_SECRET_KEY}

def _require_env(name):
    # production-only: a required setting must be present and not a known placeholder
    value = os.environ.get(name, '').strip()
    if not value or (name.endswith('_KEY') and value in _PLACEHOLDER_SECRETS):
        raise RuntimeError(
            f"{name} is missing or still a placeholder, and FORGE_ENV=production. "
            f"Set a real value in backend/.env (see backend/.env.example)."
        )
    return value

# Locally (no .env needed) the dev fallbacks are used; in production they never are.
if IS_PRODUCTION:
    app.config['SECRET_KEY'] = _require_env('SECRET_KEY')
    app.config['JWT_SECRET_KEY'] = _require_env('JWT_SECRET_KEY')
    app.config['SQLALCHEMY_DATABASE_URI'] = _require_env('DATABASE_URL')
else:
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', _DEV_SECRET_KEY)
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', _DEV_JWT_SECRET_KEY)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:@localhost/forge_dev')

# Behind nginx every request arrives from the proxy's address, which breaks
# per-IP rate limiting / lockouts / audit logs. TRUSTED_PROXY_COUNT is how many
# proxies sit in front of the app (1 = just nginx); 0 (default) trusts no
# forwarded headers, which is right when the app is reached directly.
_trusted_proxies = int(os.environ.get('TRUSTED_PROXY_COUNT', '0') or 0)
if _trusted_proxies > 0:
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=_trusted_proxies, x_proto=_trusted_proxies, x_host=_trusted_proxies)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# CORS_ORIGINS can be a comma-separated list, so both the local Vite dev server
# and the deployed frontend can be allowed at once (e.g. during a staged rollout).
_cors_origins = os.environ.get('CORS_ORIGINS', 'http://localhost:5173').split(',')
CORS(app, origins=_cors_origins, supports_credentials=True)
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=15)    # same as the library default, now explicit
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=7)
jwt = JWTManager(app)
# Demo/test mode may only ever point at a database whose name says so. This is the
# guard that keeps a demo run from touching the real database by mistake.
if os.environ.get('FORGE_DEMO', '').strip().lower() in ('1', 'true', 'yes'):
    from sqlalchemy.engine import make_url as _mk
    _dbname = (_mk(app.config['SQLALCHEMY_DATABASE_URI']).database or '').lower()
    if not any(w in _dbname for w in ('demo', 'test')):
        raise SystemExit(f"FORGE_DEMO is on but the database name {_dbname!r} does not contain 'demo' or 'test'. Refusing to start.")
    # a name is not enough: a demo may only use a local file or a database on this machine, never a remote server
    _u = _mk(app.config['SQLALCHEMY_DATABASE_URI'])
    if not _u.drivername.startswith('sqlite') and (_u.host or '').lower() not in ('127.0.0.1', 'localhost', '::1'):
        raise SystemExit(f"FORGE_DEMO is on but the database host {_u.host!r} is not this machine. Refusing to start.")
# How code is run for grading. 'docker-sandbox' is the only real mode. demo_runner.py can switch
# a throwaway demo process to 'demo-stub' (simulated results); that is recorded on every result
# and shown by /api/health, so simulated results can never pass as real execution evidence.
EXECUTION_MODE = 'docker-sandbox'
_demo_flags = [k for k in ('FORGE_DEMO', 'FORGE_DEMO_RUNNER') if os.environ.get(k, '').strip()]
if IS_PRODUCTION and _demo_flags:
    raise SystemExit(f"Refusing to start in production with demo settings enabled: {', '.join(_demo_flags)}.")
if IS_PRODUCTION and os.environ.get('FORGE_AUTO_SCHEMA', '').strip():
    # start-up must never write to a production schema; upgrades are the explicit manage_schema.py command
    raise SystemExit("Refusing to start in production with FORGE_AUTO_SCHEMA set (it would change the schema at start-up). Use manage_schema.py upgrade.")
db = SQLAlchemy(app)

@jwt.token_in_blocklist_loader
def _reject_deactivated_users(jwt_header, jwt_payload):
    # runs on every protected request: a deactivated/deleted account is
    # locked out immediately instead of riding out its token's lifetime.
    # The user row is cached in the session, so handlers' own User lookup is free.
    # Refresh tokens are validated (incl. is_active) in /api/auth/refresh itself.
    if jwt_payload.get('type') == 'refresh':
        return False
    try:
        user = db.session.get(User, int(jwt_payload['sub']))
    except (KeyError, TypeError, ValueError):
        return True
    # `is False` (not `not`): legacy rows with NULL is_active stay allowed
    if user is None or user.is_active is False:
        return True
    # a password change/reset bumps token_version: older tokens (no claim = version 0) die
    return int(jwt_payload.get('tv', 0)) != int(user.token_version or 0)


# ===== PASSWORD POLICY (one rule everywhere: change, admin reset, admin-set passwords) =====
PASSWORD_MIN_LENGTH = 8
PASSWORD_MAX_LENGTH = 128


def password_policy_error(password, user=None):
    """None if acceptable, else a plain-language reason. Never logs the password."""
    if not isinstance(password, str) or not password:
        return "A password is required."
    if len(password) < PASSWORD_MIN_LENGTH:
        return f"Password must be at least {PASSWORD_MIN_LENGTH} characters."
    if len(password) > PASSWORD_MAX_LENGTH:
        return f"Password must be at most {PASSWORD_MAX_LENGTH} characters."
    if not _re.search(r'[A-Za-z]', password) or not _re.search(r'\d', password):
        return "Password must contain at least one letter and one number."
    if user is not None:
        low = password.lower()
        for ident in (user.username, (user.email or '').split('@')[0]):
            if ident and len(ident) >= 4 and low == ident.lower():
                return "Password must not be the same as your username or email name."
    return None


def issue_tokens(user):
    claims = {'tv': int(user.token_version or 0)}
    return (create_access_token(identity=str(user.id), additional_claims=claims),
            create_refresh_token(identity=str(user.id), additional_claims=claims))


# Until a temporary/reset password is replaced, only these calls work.
_PASSWORD_CHANGE_ALLOWED = {'/api/auth/login', '/api/auth/refresh', '/api/auth/me', '/api/auth/change-password'}


@app.before_request
def _enforce_password_change():
    if request.method == 'OPTIONS' or not request.path.startswith('/api/') or request.path in _PASSWORD_CHANGE_ALLOWED:
        return None
    try:
        verify_jwt_in_request(optional=True)
        ident = get_jwt_identity()
    except Exception:
        return None            # bad/expired token: the route's own jwt check answers
    if not ident:
        return None
    u = db.session.get(User, int(ident))
    if u is not None and u.must_change_password:
        return jsonify({"error": "password_change_required",
                        "message": "You must change your temporary password before continuing."}), 403
    return None

# ===== RATE LIMITING =====
rate_limit_store = {}
login_fail_store = {}   # { ip: {'count': n, 'locked_until': timestamp} }

def rate_limit(max_calls=5, period=60):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Signed-in callers are counted per account, not per IP: a whole
            # classroom behind one school/NAT address would otherwise share a
            # single allowance. Anonymous callers (e.g. login) still use the IP.
            try:
                ident = get_jwt_identity()
            except Exception:
                ident = None
            ip = f"user:{ident}" if ident else request.remote_addr
            now = time.time()
            if ip not in rate_limit_store: rate_limit_store[ip] = []
            rate_limit_store[ip] = [t for t in rate_limit_store[ip] if now - t < period]
            if len(rate_limit_store[ip]) >= max_calls:
                return jsonify({"error": "Rate limit exceeded. Try again later."}), 429
            rate_limit_store[ip].append(now)
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ===== MODELS =====
# ===== ACHIEVEMENT MODELS =====
class Achievement(db.Model):
    __tablename__ = 'achievements'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(50), nullable=False)
    xp_reward = db.Column(db.Integer, default=0)
    requirement_type = db.Column(db.String(50), nullable=False)  # e.g., 'quest_count', 'streak'
    requirement_value = db.Column(db.Integer, nullable=False)
    category = db.Column(db.Enum('student', 'instructor'), default='student')

class UserAchievement(db.Model):
    __tablename__ = 'user_achievements'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievements.id'), nullable=False)
    earned_at = db.Column(db.DateTime, default=datetime.utcnow)
    progress = db.Column(db.Integer, default=0)

    # One award per user per achievement. db.create_all() adds this to NEW databases only; an existing
    # database gets it from the explicit `manage_schema.py upgrade`, which refuses (and changes nothing)
    # while duplicate pairs exist. schema_status() reports it as missing until it is effectively present.
    __table_args__ = (db.UniqueConstraint('user_id', 'achievement_id', name='uq_user_achievement'),)

    user = db.relationship('User', backref=db.backref('user_achievements', lazy=True))
    achievement = db.relationship('Achievement')

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('student', 'instructor', 'administrator'), default='student')
    full_name = db.Column(db.String(200), nullable=True)
    xp = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)
    # temporary/reset passwords must be replaced before anything else is allowed
    must_change_password = db.Column(db.Boolean, nullable=False, default=False, server_default='0')
    # bumped on every password change/reset: tokens issued earlier stop working
    token_version = db.Column(db.Integer, nullable=False, default=0, server_default='0')
    password_changed_at = db.Column(db.DateTime, nullable=True)

class Problem(db.Model):
    __tablename__ = 'problems'
    __table_args__ = (
        db.Index('idx_problem_published_subject', 'is_published', 'subject_id'),
    )
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    difficulty = db.Column(db.Enum('Easy', 'Medium', 'Hard'), nullable=False)
    category = db.Column(db.String(100))
    test_cases = db.Column(db.JSON, nullable=False)
    starter_code = db.Column(db.JSON)  # Stores {language: code}
    xp_reward = db.Column(db.Integer, nullable=False)
    is_published = db.Column(db.Boolean, default=False)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # extra quest fields below
    problem_type = db.Column(db.Enum('coding', 'debugging'), default='coding')
    languages = db.Column(db.JSON, default=['python'])  # ['python', 'java', 'csharp']
    is_event_quest = db.Column(db.Boolean, default=False)
    visible_to_sections = db.Column(db.JSON, default=[])
    hints = db.Column(db.JSON, default=[])  # [{text: "...", xp_penalty: 10}]
    tags = db.Column(db.JSON, default=[])
    prerequisites = db.Column(db.JSON, default=[])
    estimated_time = db.Column(db.String(50))
    partial_credit = db.Column(db.Integer, default=100)
    auto_grade = db.Column(db.Boolean, default=True)
    plagiarism_threshold = db.Column(db.Float, default=0.85)
    due_date = db.Column(db.DateTime, nullable=True)  # for quest deadlines
    # this is for which subject a quest belongs to
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'), nullable=True)

class Submission(db.Model):
    __tablename__ = 'submissions'
    __table_args__ = (
        db.Index('idx_submission_user_problem', 'user_id', 'problem_id'),
        db.Index('idx_submission_user_status', 'user_id', 'status'),
    )
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False)
    code = db.Column(db.Text, nullable=False)
    language = db.Column(db.Enum('python', 'java', 'csharp'), nullable=False)
    status       = db.Column(db.Enum(
                       'accepted', 'partial', 'wrong_answer',
                       'timeout', 'error', 'compile_error'
                   ), nullable=False, default='error')
    score        = db.Column(db.Integer, default=0)
    passed_cases = db.Column(db.Integer, default=0)
    total_cases  = db.Column(db.Integer, default=0)
    exec_ms      = db.Column(db.Integer, default=0)
    error_msg    = db.Column(db.Text,    nullable=True)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    # what the grader recorded at submission time: {"runner": ..., "tests": [{index, passed, kind, hidden, message, output?}]}.
    # NULL on records made before this column existed (the viewer says so instead of guessing).
    result_details = db.Column(db.JSON, nullable=True)

class SubmissionSlot(db.Model):
    """
    Reservation of the single graded attempt for (student, problem).
    UNIQUE(user_id, problem_id) is what makes simultaneous requests safe.
    status: pending (being graded) | done (graded, result saved) | failed (runner broke; retry allowed)
    """
    __tablename__ = 'submission_slots'
    __table_args__ = (
        db.UniqueConstraint('user_id', 'problem_id', name='uq_submission_slot_user_problem'),
    )
    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    problem_id  = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False)
    status      = db.Column(db.String(10), nullable=False, default='pending')
    claimed_at  = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime, nullable=True)
    error_msg   = db.Column(db.String(500), nullable=True)
    # random value written by whoever currently owns the pending reservation;
    # finishing or releasing only works while it still matches (late workers lose)
    owner_token = db.Column(db.String(36), nullable=True)

class CodeDraft(db.Model):
    # in-progress code for a quest a student hasn't submitted yet.
    # autosaved every few seconds from the editor so a power outage,
    # a crashed browser, or opening the quest on a different machine
    # doesn't lose the student's work -- this used to live only in
    # the browser's localStorage, which none of those situations survive.
    __tablename__ = 'code_drafts'
    __table_args__ = (
        db.UniqueConstraint('user_id', 'problem_id', 'language', name='uq_code_draft'),
    )
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False)
    language = db.Column(db.Enum('python', 'java', 'csharp'), nullable=False)
    code = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class HintReveal(db.Model):
    # records that a specific student revealed a specific hint on a
    # specific problem — one row per (student, problem, hint) combo,
    # enforced by the unique constraint below so revealing the same
    # hint twice never creates duplicate rows
    __tablename__ = 'hint_reveals'
    __table_args__ = (
        db.UniqueConstraint('user_id', 'problem_id', 'hint_index', name='uq_hint_reveal'),
    )
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False)
    hint_index = db.Column(db.Integer, nullable=False)
    revealed_at = db.Column(db.DateTime, default=datetime.utcnow)

class Announcement(db.Model):
    __tablename__ = 'announcements'
    id = db.Column(db.Integer, primary_key=True)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    class_id = db.Column(db.Integer, nullable=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_pinned = db.Column(db.Boolean, default=False)
    priority = db.Column(db.Enum('low', 'medium', 'high', 'urgent'), default='medium')  # NEW
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# ── Subject model — IT/programming subjects only ──────────────────────
class Subject(db.Model):
    __tablename__ = 'subjects'
    id                  = db.Column(db.Integer, primary_key=True)
    internal_subject_no = db.Column(db.String(10),  nullable=True)
    name                = db.Column(db.String(200),  nullable=False)
    description         = db.Column(db.Text,         nullable=True)
    subject_code        = db.Column(db.String(20),   nullable=True, unique=True)
    units               = db.Column(db.Integer,      nullable=True)
    department          = db.Column(db.String(100),  nullable=True)
    year_level          = db.Column(db.Integer,      nullable=True)
    semester            = db.Column(db.Integer,      nullable=True)
    subject_type        = db.Column(
                            db.Enum('lecture', 'lab', 'lecture_lab', 'elective'),
                            nullable=True, default='lab')
    # Forge.dev supports Lab-type subjects only. Each subject should be offered
    # in 3-5 Class Codes (sections) to accommodate regular and irregular students.
    supported_languages = db.Column(db.String(100),  nullable=False, default='python')
    default_difficulty  = db.Column(db.String(10),   nullable=False, default='easy')
    is_active           = db.Column(db.Boolean,      nullable=False, default=True)
    created_at          = db.Column(db.DateTime,     default=datetime.utcnow)

# ===== COURSE MATERIALS MODELS =====
class Lesson(db.Model):
    __tablename__ = 'lessons'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    week_number = db.Column(db.Integer, nullable=False)  # Week 1, 2, 3...
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'), nullable=False)
    # which specific class code this module belongs to. nullable only so
    # rows created before this column existed don't break -- a lesson with
    # no section_id is legacy/orphaned and won't show up to anyone anymore
    # (see get_lessons/get_student_lessons below). every lesson created
    # from here on always gets one.
    section_id = db.Column(db.Integer, db.ForeignKey('subject_sections.id'), nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    is_published = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    subject = db.relationship('Subject', backref=db.backref('lessons', lazy=True))
    instructor = db.relationship('User', backref=db.backref('created_lessons', lazy=True))
    files = db.relationship('LessonFile', backref='lesson', lazy=True, cascade='all, delete-orphan')

class LessonFile(db.Model):
    __tablename__ = 'lesson_files'
    id = db.Column(db.Integer, primary_key=True)
    lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'), nullable=False)
    filename = db.Column(db.String(255), nullable=False)  # Secure server name (UUID)
    original_filename = db.Column(db.String(255), nullable=False)  # User's original name
    file_type = db.Column(db.String(50), nullable=False)  # pdf, pptx, docx, mp4, etc.
    file_size = db.Column(db.Integer, nullable=False)  # in bytes
    storage_path = db.Column(db.String(500), nullable=False)  # relative path to uploads folder
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

#  Teacher Assignment (Who teaches what, where)
class TeacherAssignment(db.Model):
    __tablename__ = 'teacher_assignments'
    __table_args__ = (
        db.UniqueConstraint('instructor_id', 'subject_id', 'section_id',
                            name='uq_teacher_assignment'),
    )
    id            = db.Column(db.Integer, primary_key=True)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'),              nullable=False)
    subject_id    = db.Column(db.Integer, db.ForeignKey('subjects.id'),            nullable=False)
    section_id    = db.Column(db.Integer, db.ForeignKey('subject_sections.id'),    nullable=True)

    instructor = db.relationship('User',           foreign_keys=[instructor_id])
    subject    = db.relationship('Subject')
    section    = db.relationship('SubjectSection')

class SubjectSection(db.Model):
    __tablename__ = 'subject_sections'
    id            = db.Column(db.Integer, primary_key=True)
    section_no    = db.Column(db.String(20),  nullable=False)
    subject_id    = db.Column(db.Integer,     db.ForeignKey('subjects.id'), nullable=False)
    schedule      = db.Column(db.String(100), nullable=True)
    room          = db.Column(db.String(50),  nullable=True)
    capacity      = db.Column(db.Integer,     nullable=False, default=40)
    current_count = db.Column(db.Integer,     nullable=False, default=0)
    semester      = db.Column(db.String(50),  nullable=True)
    academic_year = db.Column(db.String(9),   nullable=True)
    is_active     = db.Column(db.Boolean,     nullable=False, default=True)
    created_at    = db.Column(db.DateTime,    default=datetime.utcnow)

class IrregularEnrollment(db.Model):
    __tablename__ = 'irregular_enrollments'
    __table_args__ = (
        db.UniqueConstraint('student_id', 'section_id', name='unique_irregular_enrollment'),
    )
    id          = db.Column(db.Integer, primary_key=True)
    student_id  = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    section_id  = db.Column(db.Integer, db.ForeignKey('subject_sections.id'), nullable=False)
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    target_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SystemConfig(db.Model):
    __tablename__ = 'system_config'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PlagiarismReport(db.Model):
    __tablename__ = 'plagiarism_reports'
    id = db.Column(db.Integer, primary_key=True)
    submission_a_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=False)
    submission_b_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=False)
    similarity_score = db.Column(db.Float, nullable=False)
    status = db.Column(db.Enum('pending', 'reviewed', 'resolved', 'dismissed'), default='pending')
    admin_notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# ============================================================
# IT SUBJECT CONSTANTS — Forge.dev scope (final confirmed)
# 12 subjects | 6 LEC/LAB pairs | Python, Java, C# only
# ============================================================
SUPPORTED_IT_SUBJECTS = [
    # Year 1, Semester 1
    ("290007", "IT115",  "Introduction to Computing Lec",      2, "lecture", 1, 1),
    ("290008", "IT115L", "Introduction to Computing Lab",      1, "lab",     1, 1),
    ("290009", "IT116",  "Fundamentals of Programming Lec",    2, "lecture", 1, 1),
    ("290010", "IT116L", "Fundamentals of Programming Lab",    1, "lab",     1, 1),
    # Year 1, Semester 2
    ("290013", "IT125",  "Computer Programming 1 Lec",         2, "lecture", 1, 2),
    ("290014", "IT125L", "Computer Programming 1 Lab",         1, "lab",     1, 2),
    ("290015", "IT126",  "Data Structure & Algorithm Lec",     2, "lecture", 1, 2),
    ("290016", "IT126L", "Data Structure & Algorithm Lab",     1, "lab",     1, 2),
    # Year 2, Semester 1
    ("290017", "IT215",  "Database Management System Lec",     2, "lecture", 2, 1),
    ("290018", "IT215L", "Database Management System Lab",     1, "lab",     2, 1),
    ("290019", "IT216",  "Computer Programming 2 Lec",         2, "lecture", 2, 1),
    ("290020", "IT216L", "Computer Programming 2 Lab",         1, "lab",     2, 1),
    # Year 2, Semester 2
    ("290025", "IT225",  "Object Oriented Programming Lec",    2, "lecture", 2, 2),
    ("290026", "IT225L", "Object Oriented Programming Lab",    1, "lab",     2, 2),
    ("290027", "IT226",  "Adv. Database Mgt System Lec",       2, "lecture", 2, 2),
    ("290028", "IT226L", "Adv. Database Mgt System Lab",       1, "lab",     2, 2),
]

SUBJECT_LANGUAGE_MAP = {
    "IT115":  "python",
    "IT115L": "python",
    "IT116":  "python",
    "IT116L": "python",
    "IT125":  "python,java,csharp",
    "IT125L": "python,java,csharp",
    "IT126":  "python,java,csharp",
    "IT126L": "python,java,csharp",
    "IT215":  "python,java,csharp",
    "IT215L": "python,java,csharp",
    "IT216":  "java,csharp",
    "IT216L": "java,csharp",
    "IT225":  "java,csharp,python",
    "IT225L": "java,csharp,python",
    "IT226":  "java,csharp,python",
    "IT226L": "java,csharp,python",
}

SUBJECT_DIFFICULTY_DEFAULTS = {
    "IT115":  "easy",   "IT115L": "easy",
    "IT116":  "easy",   "IT116L": "easy",
    "IT125":  "easy",   "IT125L": "easy",
    "IT126":  "medium", "IT126L": "medium",
    "IT215":  "medium", "IT215L": "medium",
    "IT216":  "medium", "IT216L": "medium",
    "IT225":  "medium", "IT225L": "medium",
    "IT226":  "hard",   "IT226L": "hard",
}

SUPPORTED_SUBJECT_CODES = frozenset(row[1] for row in SUPPORTED_IT_SUBJECTS)

# Curriculum year of the subjects Forge.dev supports (a property of the
# SUBJECT only — students of any year level may take these subjects).
FIRST_YEAR_CURRICULUM = 1

# Highest XP an instructor may attach to a problem, by difficulty.
MAX_XP_BY_DIFFICULTY = {'Easy': 100, 'Medium': 250, 'Hard': 500}

# Where uploaded lesson files live. Default: <this folder>/uploads (in Docker: /app/uploads, the
# forge-uploads volume). FORGE_UPLOADS_DIR relocates it (used for isolated recovery rehearsals).
# Database rows keep a relative storage_path such as 'uploads/lessons/<lesson_id>/<uuid>.pdf'.
UPLOAD_ROOT = os.path.abspath(os.environ.get('FORGE_UPLOADS_DIR') or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads'))

def upload_abs_path(storage_path):
    """Absolute path for a stored relative path, or None if it would leave the uploads folder."""
    rel = (storage_path or '').replace('\\', '/').lstrip('/')
    if rel.startswith('uploads/'):
        rel = rel[len('uploads/'):]
    full = os.path.abspath(os.path.join(UPLOAD_ROOT, rel))
    return full if full.startswith(UPLOAD_ROOT + os.sep) else None

def parse_due_date(value):
    """Parse a quest deadline sent by a client.
    Returns (datetime_or_None, error_message_or_None). The database stores deadlines as naive UTC.
    - ISO 8601 only ('2026-11-05T17:00:00', '2026-11-05T17:00:00+08:00', '...Z', or a plain date).
    - A value with an offset or Z is converted to UTC; a value without one is taken as UTC.
    - Empty / null means 'no value given' (None, no error). Any other unparseable value is an error;
      it is never silently dropped."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None, None
    if not isinstance(value, str):
        return None, "due_date must be an ISO 8601 date-time string"
    text = value.strip()
    if text.endswith(('Z', 'z')):
        text = text[:-1] + '+00:00'
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None, "due_date is not a valid ISO 8601 date-time (example: 2026-11-05T17:00:00+08:00)"
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt, None

# Institution settings (La Consolacion University deployment).
# There is deliberately NO built-in institution default for staff email rules or
# the head administrator: an unset value disables the dependent feature instead of
# silently authorizing some old address.
#   STUDENT_EMAIL_DOMAIN  domain used for GENERATED student identifiers
#                         (<student_id>@student.com). These are sign-in identifiers,
#                         not deliverable inboxes, and the project does not own the domain.
#   ALLOWED_EMAIL_DOMAIN  optional restriction for STAFF emails; empty = any valid email.
#   HEAD_ADMIN_EMAIL      existing administrator account allowed to create/promote
#                         administrators; empty = those operations are disabled.
_DEFAULT_STUDENT_EMAIL_DOMAIN = 'student.com'
_DOMAIN_RE = _re.compile(r'^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$')
_EMAIL_RE = _re.compile(r'^[^@\s]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$')

# human-readable problems found while reading the settings (shown at startup and
# by /api/admin/policy); never contain secrets
CONFIG_DIAGNOSTICS = []


def _read_setting(name, default, valid):
    """Env value if present and well formed, else the default (with a diagnostic). Never crashes."""
    raw = os.environ.get(name, '').strip().lower()
    if name.endswith('_DOMAIN'):
        raw = raw.lstrip('@')
    if not raw:
        return default
    if not valid.match(raw):
        CONFIG_DIAGNOSTICS.append(f"{name} is not a valid value ({raw!r}) and was ignored.")
        print(f"WARNING: {name} is not a valid value ({raw!r}); ignored.")
        return default
    return raw


STUDENT_EMAIL_DOMAIN = _read_setting('STUDENT_EMAIL_DOMAIN', _DEFAULT_STUDENT_EMAIL_DOMAIN, _DOMAIN_RE)
ALLOWED_EMAIL_DOMAIN = _read_setting('ALLOWED_EMAIL_DOMAIN', '', _DOMAIN_RE)
HEAD_ADMIN_EMAIL = _read_setting('HEAD_ADMIN_EMAIL', '', _EMAIL_RE)
if not HEAD_ADMIN_EMAIL:
    CONFIG_DIAGNOSTICS.append(
        "HEAD_ADMIN_EMAIL is not set (or invalid): creating or promoting administrator "
        "accounts is disabled. Ordinary sign-in is not affected.")
    print("NOTICE: HEAD_ADMIN_EMAIL is not configured; creating/promoting administrators is disabled.")


def normalize_email(value):
    """Trimmed, lower-cased email for comparison (None for empty)."""
    v = (value or '').strip().lower()
    return v or None


def normalize_student_id(value):
    """Student IDs are strings; only surrounding whitespace is removed (leading zeros kept)."""
    return str(value if value is not None else '').strip()


def valid_student_id(sid):
    """Non-empty, no whitespace, no '@' (so an ID can never look like an email)."""
    return bool(sid) and len(sid) <= 64 and not _re.search(r'[\s@]', sid)


def generated_student_email(student_id):
    """Generated sign-in identifier for a student: <student_id>@<STUDENT_EMAIL_DOMAIN>."""
    return f"{normalize_student_id(student_id).lower()}@{STUDENT_EMAIL_DOMAIN}"


def email_domain_allowed(email):
    """Staff email rule: a well-formed address, restricted to ALLOWED_EMAIL_DOMAIN only when one is configured."""
    e = normalize_email(email)
    if not e or not _EMAIL_RE.match(e):
        return False
    return (not ALLOWED_EMAIL_DOMAIN) or e.endswith('@' + ALLOWED_EMAIL_DOMAIN)


def is_head_admin(user):
    """The head admin is the only account allowed to create or promote admins (never true when unconfigured)."""
    return bool(HEAD_ADMIN_EMAIL) and bool(user) and user.role == 'administrator' \
        and normalize_email(user.email) == HEAD_ADMIN_EMAIL


def subject_out_of_scope(subject):
    """
    True unless the subject is recorded as first-year curriculum. A missing or
    invalid curriculum year counts as unclassified, so it is blocked too.
    Year 1 alone does not prove the subject is in the official institutional
    curriculum; that approval is a separate, still pending, step.
    Used only to stop NEW activity: existing records stay readable and usable.
    """
    return bool(subject) and subject.year_level != FIRST_YEAR_CURRICULUM


OUT_OF_SCOPE_MSG = ("This subject is not a recorded first-year curriculum subject, "
                    "so new activity cannot be added to it.")


def validate_it_subject_scope(subject_code: str):
    if not subject_code:
        return False, "Subject code is required."
    code = subject_code.upper().strip()
    if code in SUPPORTED_SUBJECT_CODES:
        return True, ""
    NON_IT = ('TH', 'PE', 'HI', 'HU', 'PY', 'EN', 'NS', 'CM', 'PC', 'MH', 'NSTP')
    for prefix in NON_IT:
        if code.startswith(prefix):
            return False, (
                f"'{subject_code}' is a non-IT subject and is not supported by Forge.dev. "
                f"Only IT programming subjects (IT115–IT225L) are in scope."
            )
    return False, (
        f"'{subject_code}' is not in the supported subject list. "
        f"Supported codes: {', '.join(sorted(SUPPORTED_SUBJECT_CODES))}"
    )


def seed_it_subjects():
    # Only first-year curriculum subjects are seeded (same rule as the admin
    # create/edit endpoints). Entries marked for another curriculum year are
    # left out of NEW seeding; existing rows are never touched or removed.
    seeded, skipped, out_of_scope = 0, 0, 0
    for row in SUPPORTED_IT_SUBJECTS:
        internal_no, code, name, units, stype, yr, sem = row
        if yr != FIRST_YEAR_CURRICULUM:
            out_of_scope += 1
            continue
        if Subject.query.filter_by(subject_code=code).first():
            skipped += 1
            continue
        db.session.add(Subject(
            internal_subject_no = internal_no,
            subject_code        = code,
            name                = name,
            units               = units,
            subject_type        = stype,
            year_level          = yr,
            semester            = sem,
            department          = 'CCIT',
            supported_languages = SUBJECT_LANGUAGE_MAP.get(code, 'python'),
            default_difficulty  = SUBJECT_DIFFICULTY_DEFAULTS.get(code, 'easy'),
            is_active           = True
        ))
        seeded += 1
    db.session.commit()
    return {'seeded': seeded, 'skipped': skipped, 'out_of_scope': out_of_scope,
            'total': len(SUPPORTED_IT_SUBJECTS)}


# ===== HELPERS =====
def is_instructor_or_admin(user): return user and user.role in ['instructor', 'administrator']
def is_administrator(user): return user and user.role == 'administrator'

def is_instructor_assigned(instructor_id, subject_id, section_id=None):
    """Return True if the instructor has any assignment for the subject.
    If section_id is given, also verify they teach that specific section.
    """
    query = TeacherAssignment.query.filter_by(
        instructor_id=instructor_id,
        subject_id=subject_id
    )
    if section_id is not None:
        query = query.filter_by(section_id=section_id)
    return query.first() is not None

def get_instructor_sections_for_subject(instructor_id, subject_id):
    """Return list of SubjectSection IDs where this instructor teaches the subject."""
    assignments = TeacherAssignment.query.filter_by(
        instructor_id=instructor_id,
        subject_id=subject_id
    ).all()
    return [a.section_id for a in assignments if a.section_id is not None]

def admin_required(f):
    @wraps(f)
    @jwt_required()
    def decorated(*args, **kwargs):
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        if not is_administrator(user):
            return jsonify({"error": "Administrator access required"}), 403
        return f(user, *args, **kwargs)
    return decorated

def log_admin_action(admin_id, action, details=None, target_id=None):
    try:
        log = AuditLog(
            admin_id=admin_id,
            action=action,
            details=details or "",
            target_id=target_id,
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"⚠️ audit log failed: {e}")

def sanitize_code(code, language):
    """
    Simple substring checks — no regex, no ReDoS risk.
    Returns True if code is considered safe, False otherwise.
    """
    if language == 'python':
        dangerous_patterns = [
            '__import__',
            'os.system',
            'os.popen',
            'os.exec',
            'subprocess',
            'eval(',
            'exec(',
            'open(',
            'import os',
            'import sys',
            'import socket',
            'import shutil',
            'importlib',
            'pty.spawn',
            'ctypes',
        ]
        code_lower = code.lower()
        return not any(pattern.lower() in code_lower for pattern in dangerous_patterns)
    return True

@handles_setup_errors
def _run_in_docker_with_stdin(code: str, language: str, stdin_input: str) -> dict:
    """
    like _run_in_docker() but pipes stdin_input into the container.
    student code is written untouched; the wrapper reads from stdin.
    """
    import tempfile, os, time

    from routes.sandbox import (
        DOCKER_IMAGES, MEM_LIMITS, CAP_DROP, SECURITY_OPTS,
        LANGUAGE_TIMEOUTS, LIMITS,
        _write_source, _generate_java_wrapper, _generate_csharp_wrapper,
        _get_docker_client, sandbox_workdir, make_workdir_readable,
    )

    client  = _get_docker_client()
    image   = DOCKER_IMAGES[language]
    started = time.time()

    with sandbox_workdir() as tmpdir:
        src_path = _write_source(tmpdir, code, language)
        filename = os.path.basename(src_path)

        # ── Write input to file so container can read it ──────────────────
        # cap stdin so nobody can abuse the sandbox with a huge input
        max_input_size = 64 * 1024  # 64kb
        if stdin_input and len(stdin_input.encode('utf-8')) > max_input_size:
            return {
                'stdout': '',
                'stderr': 'input too large (max 64kb)',
                'returncode': -1,
                'elapsed': 0,
                'timed_out': False,
                'timeout_used': 0
            }

        input_path = os.path.join(tmpdir, 'input.txt')
        with open(input_path, 'w', encoding='utf-8') as f:
            f.write(stdin_input if stdin_input else '')

        if language == 'java':
            with open(os.path.join(tmpdir, 'Main.java'), 'w', encoding='utf-8') as f:
                f.write(_generate_java_wrapper())
        elif language == 'csharp':
            with open(os.path.join(tmpdir, 'Program.cs'), 'w', encoding='utf-8') as f:
                f.write(_generate_csharp_wrapper())

        make_workdir_readable(tmpdir)
        container_src = f'/tmp/sandbox/{filename}'

        try:
            container = client.containers.run(
                image=image,
                command=[container_src],
                # stdin_open removed — using file-based input

                volumes={tmpdir: {'bind': '/tmp/sandbox', 'mode': 'ro'}},
                tmpfs={
                    '/tmp':      'size=256m,mode=1777',
                    '/tmp/work': 'size=256m,mode=1777',
                },

                network_disabled=True,
                read_only=True,
                cap_drop=CAP_DROP[language],
                security_opt=SECURITY_OPTS[language],
                mem_limit=MEM_LIMITS[language],
                memswap_limit=MEM_LIMITS[language],
                cpu_period=LIMITS['cpu_period'],
                cpu_quota=LIMITS['cpu_quota'],
                pids_limit=LIMITS['pids_limit'],

                detach=True,
                remove=False,
                stdout=True,
                stderr=True,

                environment={
                    'PYTHONUNBUFFERED':                  '1',
                    'DOTNET_CLI_TELEMETRY_OPTOUT':       '1',
                    'JAVA_OPTS':                         '-XX:TieredStopAtLevel=1',
                    'HOME':                              '/dotnet-sentinel',
                    'DOTNET_CLI_HOME':                   '/dotnet-sentinel/.dotnet',
                    'NUGET_PACKAGES':                    '/dotnet-sentinel/.nuget/packages',
                    'NUGET_HTTP_CACHE_PATH':             '/tmp/work/.nuget-http-cache',
                    'NUGET_SCRATCH':                     '/tmp/work/.nuget-scratch',
                    'DOTNET_NOLOGO':                     '1',
                    'DOTNET_SKIP_FIRST_TIME_EXPERIENCE': '1',
                    'DOTNET_MULTILEVEL_LOOKUP':          '0',
                },
            )

            # Input is already in /tmp/sandbox/input.txt — nothing to pipe

            try:
                timeout    = LANGUAGE_TIMEOUTS.get(language, LIMITS['timeout_seconds'])
                result_obj = container.wait(timeout=timeout)
                timed_out  = False
                returncode = result_obj.get('StatusCode', -1)
            except Exception:
                try: container.kill()
                except Exception: pass
                timed_out  = True
                returncode = -1

            raw_stdout = raw_stderr = b''
            try:
                raw_stdout = container.logs(stdout=True,  stderr=False)
                raw_stderr = container.logs(stdout=False, stderr=True)
            except Exception:
                pass

            try: container.remove(force=True)
            except Exception: pass

            stdout = raw_stdout.decode('utf-8', errors='replace')
            stderr = raw_stderr.decode('utf-8', errors='replace')
            max_b  = LIMITS['output_bytes']
            if len(stdout) > max_b:
                stdout = stdout[:max_b] + '\n⚠️ [Output truncated]'
            if len(stderr) > max_b:
                stderr = stderr[:max_b] + '\n⚠️ [Error truncated]'

            elapsed_ms = int((time.time() - started) * 1000)
            return {
                'stdout':       stdout,
                'stderr':       stderr,
                'returncode':   returncode,
                'elapsed':      elapsed_ms,
                'timed_out':    timed_out,
                'timeout_used': timeout,
            }

        except Exception as e:
            elapsed_ms = int((time.time() - started) * 1000)
            return {
                'stdout': '', 'stderr': '',
                'error':  f'💥 Execution error: {str(e)}',
                'returncode': -1, 'elapsed': elapsed_ms, 'timed_out': False,
            }


def serialize_hints_for_viewer(problem, user):
    """
    Hints as the given user may see them. Instructors/admins get the stored
    hints untouched. Students only get each hint's penalty plus the text of
    hints they have already revealed (recorded in HintReveal); everything else
    is withheld until /hints/<idx>/reveal is called, so the XP penalty can't
    be bypassed by reading the API response.
    """
    hints = problem.hints or []
    if user is not None and user.role != 'student':
        return hints

    revealed = set()
    if user is not None and hints:
        rows = HintReveal.query.filter_by(user_id=user.id, problem_id=problem.id).all()
        revealed = {r.hint_index for r in rows}

    out = []
    for i, h in enumerate(hints):
        h = h if isinstance(h, dict) else {}
        is_revealed = i in revealed
        out.append({
            "xp_penalty": h.get('xp_penalty', 0),
            "revealed":   is_revealed,
            "text":       h.get('text', '') if is_revealed else None,
        })
    return out


def sanitize_test_cases_for_student(test_cases):
    # strips the real input/expected off any test case an instructor
    # marked hidden, before it ever reaches a student — this covers the
    # initial quest data (Examples panel, Test Cases tab, Network tab).
    # grading itself never calls this — it always reads the real values
    # straight from the database.
    sanitized = []
    for tc in (test_cases or []):
        if tc.get('visible', True) is False:
            sanitized.append({"input": "🔒 Hidden", "expected": "🔒 Hidden", "visible": False})
        else:
            sanitized.append(tc)
    return sanitized

def _student_section_ids(user_id):
    return {e.section_id for e in IrregularEnrollment.query.filter_by(student_id=user_id).all()}


def user_can_access_problem(user, problem, historical=False):
    """
    Server-side access rule for a quest and everything attached to it
    (details, test cases, hints, drafts, Run, Submit).
      administrator : always
      instructor    : created it, or is assigned to one of its classes / its subject
      student       : enrolled (regular or irregular) in a class the quest is visible to.
    historical=True additionally lets a student who ALREADY has a submission for the
    quest keep reading it after leaving the class; it never allows new activity.
    """
    if not user or not problem:
        return False
    if user.role == 'administrator':
        return True
    if user.role == 'instructor':
        if problem.created_by == user.id:
            return True
        q = TeacherAssignment.query.filter_by(instructor_id=user.id)
        for ta in q.all():
            if ta.section_id and ta.section_id in (problem.visible_to_sections or []):
                return True
        return False
    if user.role == 'student':
        if _student_section_ids(user.id) & set(problem.visible_to_sections or []):
            return True
        if historical and Submission.query.filter_by(user_id=user.id, problem_id=problem.id).first():
            return True
    return False


def instructor_teaches_section(user, section_id):
    """Administrators: any class. Instructors: only classes they are assigned to."""
    if not user:
        return False
    if user.role == 'administrator':
        return True
    return user.role == 'instructor' and TeacherAssignment.query.filter_by(
        instructor_id=user.id, section_id=section_id).first() is not None


def deny_problem_access():
    # 404 rather than 403 so a quest id in another class is not even confirmed to exist
    return jsonify({"error": "Problem not available"}), 404


class ExecutionInfrastructureError(RuntimeError):
    """The code runner itself failed (Docker, setup, disk); this says nothing about the student's code."""


def recorded_result_details(results):
    """What is kept per graded submission. Hidden tests keep only pass/fail and kind: never their data."""
    tests = []
    for i, r in enumerate(results or []):
        hidden = bool(r.get('hidden'))
        item = {"index": i + 1, "passed": bool(r.get('passed')), "kind": r.get('kind') or ('passed' if r.get('passed') else 'wrong_output'),
                "hidden": hidden}
        if not hidden:
            item["message"] = str(r.get('message') or '')[:200]
            if not r.get('passed'):
                item["output"] = str(r.get('output') or '')[:300]
        tests.append(item)
    return {"runner": EXECUTION_MODE, "tests": tests}


def evaluate_code(code, test_cases, language, raise_on_infra=False):
    """
    Execute code in Docker sandbox and compare against test cases.
    With raise_on_infra=True (used for GRADING) a runner failure raises
    ExecutionInfrastructureError instead of being scored as a failed test.
    """
    results = []

    for tc in test_cases:
        input_val = tc.get('input', '').strip()
        expected  = tc.get('expected', '').strip()
        is_hidden = tc.get('visible', True) is False

        try:
            result = _run_in_docker_with_stdin(code, language, input_val)
        except Exception as exc:
            if raise_on_infra:
                raise ExecutionInfrastructureError(str(exc)) from exc
            raise

        actual    = result.get('stdout', '').strip()
        stderr    = result.get('stderr', '').strip()
        timed_out = result.get('timed_out', False)
        error     = result.get('error', '')
        if error and raise_on_infra:
            raise ExecutionInfrastructureError(error)

        # grading itself always compares the real values above — this
        # only controls what gets reported back for a hidden test case,
        # so students only ever see pass/fail for these, never the
        # actual input, expected output, or program output
        shown_case     = "🔒 Hidden" if is_hidden else input_val[:50]
        shown_expected = "🔒 Hidden" if is_hidden else expected[:50]

        if timed_out:
            results.append({
                "test_case": shown_case,
                "expected":  shown_expected,
                "passed":    False,
                "output":    "🔒 Hidden" if is_hidden else "Timeout: execution exceeded time limit",
                "runtime":   f"{result.get('elapsed', 0)/1000:.2f}s",
                "message":   "Execution timeout",
                "kind":      "timeout",
                "hidden":    is_hidden
            })
        elif error or (result.get('returncode', 0) != 0 and not actual):
            results.append({
                "test_case": shown_case,
                "expected":  shown_expected,
                "passed":    False,
                "output":    "🔒 Hidden" if is_hidden else (stderr or error)[:500],
                "runtime":   f"{result.get('elapsed', 0)/1000:.2f}s",
                "message":   "🔒 Hidden test failed" if is_hidden else (stderr or error)[:80],
                "kind":      "runtime_error",     # compile failure, crash, or no output at all
                "hidden":    is_hidden
            })
        else:
            passed = actual == expected
            results.append({
                "test_case": shown_case,
                "expected":  shown_expected,
                "passed":    passed,
                "output":    "🔒 Hidden" if is_hidden else actual[:100],
                "runtime":   f"{result.get('elapsed', 0)/1000:.2f}s",
                "message":   "Passed" if passed else ("🔒 Hidden test failed" if is_hidden else f"Expected: {expected[:50]}"),
                "kind":      "passed" if passed else "wrong_output",
                "hidden":    is_hidden
            })

    return results

# ===== AUTH ROUTES =====
@app.route('/api/auth/register', methods=['POST'])
def register():
    # public self-registration removed — every account (student or
    # instructor) is now provisioned centrally by an admin, via the Add
    # User modal or the CSV bulk-enrollment upload. same 410 pattern
    # already used for the removed blocks endpoints below, so a stray
    # request here gets a clear reason instead of a confusing 404.
    return jsonify({"error": "Public registration is disabled. Accounts are created by an administrator."}), 410

def resolve_login_identifier(identifier):
    """
    Map what the person typed to ONE account. Returns (user, ambiguous).
    Accepts the username / student ID, or the account's email (case-insensitive).
    A student's generated identifier <student_id>@<STUDENT_EMAIL_DOMAIN> also reaches
    the student whose ID is that local part. If the possible matches are different
    accounts the attempt is refused rather than guessed.
    """
    ident = (identifier or '').strip()
    found = {}
    u = User.query.filter_by(username=ident).first()
    if u:
        found[u.id] = u
    if '@' in ident:
        email = normalize_email(ident)
        for u in User.query.filter(db.func.lower(User.email) == email).all():
            found[u.id] = u
        local, _, domain = email.rpartition('@')
        if domain == STUDENT_EMAIL_DOMAIN and local:
            u = User.query.filter(db.func.lower(User.username) == local, User.role == 'student').first()
            if u:
                found[u.id] = u
    if len(found) > 1:
        return None, True
    return (next(iter(found.values())) if found else None), False


@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data.get('username') or not data.get('password'):
        return jsonify({"error": "Missing credentials"}), 400

    identifier = str(data['username']).strip()
    if not identifier:
        return jsonify({"error": "Missing credentials"}), 400
    ip = request.remote_addr
    now = time.time()

    # Check if IP is locked out
    fail_record = login_fail_store.get(ip, {'count': 0, 'locked_until': 0})
    if fail_record['locked_until'] > now:
        remaining = int(fail_record['locked_until'] - now)
        return jsonify({"error": f"Too many failed attempts. Try again in {remaining} seconds."}), 429

    user, ambiguous = resolve_login_identifier(identifier)
    if ambiguous:
        logger.warning("Login identifier matched more than one account; refused.")
        return jsonify({"error": "Invalid credentials"}), 401

    # Check account-level lockout first
    if user and user.locked_until:
        if user.locked_until > datetime.utcnow():
            remaining = int((user.locked_until - datetime.utcnow()).total_seconds())
            return jsonify({
                "error": "Account locked",
                "message": f"Your account has been locked after 3 failed attempts. Please contact your system administrator.",
                "locked_until": user.locked_until.isoformat(),
                "remaining_seconds": remaining
            }), 423
        else:
            # Auto-unlock after 15 min
            user.login_attempts = 0
            user.locked_until = None
            db.session.commit()

    if not user or not check_password_hash(user.password_hash, data['password']):
        if user:
            user.login_attempts = (user.login_attempts or 0) + 1
            if user.login_attempts >= 3:
                user.locked_until = datetime.utcnow() + timedelta(minutes=15)
                db.session.commit()
                return jsonify({
                    "error": "Account locked",
                    "message": "Your account has been locked after 3 failed attempts. Please contact your system administrator.",
                    "locked_until": user.locked_until.isoformat(),
                    "remaining_seconds": 900
                }), 423
            db.session.commit()
            attempts_left = 3 - user.login_attempts
            return jsonify({
                "error": "Invalid credentials",
                "attempts_left": attempts_left,
                "warning": f"{attempts_left} attempt(s) remaining before account lockout."
            }), 401
        return jsonify({"error": "Invalid credentials"}), 401

    if not user.is_active:
        return jsonify({"error": "Account disabled"}), 403

    # Clear fail record and login attempts on successful login
    login_fail_store.pop(ip, None)
    user.login_attempts = 0
    user.locked_until = None
    db.session.commit()

    # real refresh token (type=refresh): jwt_required() rejects it on normal
    # endpoints, so it can only be used at /api/auth/refresh
    access_token, refresh_token = issue_tokens(user)

    return jsonify({
        "message": "Login successful",
        "access_token": access_token,
        "refresh_token": refresh_token,
        "must_change_password": bool(user.must_change_password),
        "user": {
            "id": user.id,
            "username": user.username,
            "full_name": user.full_name,
            "email": user.email,
            "role": user.role,
            "xp": user.xp,
            "level": user.level
        }
    }), 200

@app.route('/api/auth/change-password', methods=['POST'])
@jwt_required()
@rate_limit(max_calls=10, period=60)
def change_password():
    """Own password change. Always needs the current password (the temporary one when forced)."""
    user = db.session.get(User, int(get_jwt_identity()))
    data = request.get_json(silent=True) or {}
    current, new = data.get('current_password'), data.get('new_password')
    if not isinstance(current, str) or not isinstance(new, str) or not current or not new:
        return jsonify({"error": "Current and new password are required."}), 400
    if user.locked_until and user.locked_until > datetime.utcnow():
        return jsonify({"error": "Account locked", "message": "Too many failed attempts. Contact your system administrator."}), 423
    if not check_password_hash(user.password_hash, current):
        # same safeguard as sign-in: repeated wrong current passwords lock the account
        user.login_attempts = (user.login_attempts or 0) + 1
        if user.login_attempts >= 3:
            user.locked_until = datetime.utcnow() + timedelta(minutes=15)
        db.session.commit()
        return jsonify({"error": "Current password is incorrect."}), 400
    err = password_policy_error(new, user)
    if err:
        return jsonify({"error": err}), 400
    if check_password_hash(user.password_hash, new):
        return jsonify({"error": "The new password must be different from the current one."}), 400
    user.password_hash = generate_password_hash(new)
    user.must_change_password = False
    user.login_attempts = 0
    user.locked_until = None
    user.password_changed_at = datetime.utcnow()
    user.token_version = int(user.token_version or 0) + 1         # every other session ends
    db.session.commit()
    access_token, refresh_token = issue_tokens(user)              # this session continues
    return jsonify({"message": "Password changed.", "access_token": access_token,
                    "refresh_token": refresh_token, "must_change_password": False}), 200


@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "Not found"}), 404
    return jsonify({
        "id": user.id,
        "username": user.username,
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role,
        "xp": user.xp,
        "level": user.level,
        "must_change_password": bool(user.must_change_password)
    }), 200

# this is for refreshing the login token so people don't get logged out mid-session
@app.route('/api/auth/refresh', methods=['POST'])
def refresh():
    data = request.get_json()
    if not data or 'refresh_token' not in data:
        return jsonify({'error': 'Refresh token required'}), 400
    try:
        decoded = decode_token(data['refresh_token'])
        # only a real refresh token is accepted here — an access token
        # (or anything else signed with our key) must not mint new tokens
        if decoded.get('type') != 'refresh':
            return jsonify({'error': 'Invalid refresh token'}), 401
        user_id = int(decoded['sub'])
        user = db.session.get(User, user_id)
        if not user or not user.is_active:
            return jsonify({'error': 'Invalid refresh token'}), 401
        if int(decoded.get('tv', 0)) != int(user.token_version or 0):
            return jsonify({'error': 'Invalid refresh token'}), 401      # password changed since
        return jsonify({'access_token': create_access_token(
            identity=str(user_id), additional_claims={'tv': int(user.token_version or 0)})})
    except Exception:
        # expired, malformed, bad signature, non-numeric sub, etc.
        return jsonify({'error': 'Invalid refresh token'}), 401

# ===== PROBLEM ROUTES =====
@app.route('/api/problems', methods=['POST'])
@jwt_required()
def create_problem():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    data = request.get_json()

    # Validation
    required = ['title','description','difficulty','xp_reward','test_cases']
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields"}), 400
    if data['difficulty'] not in ['Easy','Medium','Hard']:
        return jsonify({"error": "Invalid difficulty"}), 400
    if not isinstance(data['test_cases'], list) or len(data['test_cases']) == 0:
        return jsonify({"error": "At least one test case required"}), 400
    for i, tc in enumerate(data['test_cases']):
        if 'input' not in tc or 'expected' not in tc:
            return jsonify({"error": f"Test case {i+1} invalid"}), 400

    # xp has to match the difficulty picked
    max_xp = MAX_XP_BY_DIFFICULTY

    # make sure the subject picked is actually valid
    subject_id = data.get('subject_id')
    if not subject_id:
        return jsonify({"error": "Course subject is required"}), 400

    # Verify instructor is assigned to teach this subject in at least one block
    if not is_instructor_assigned(user_id, subject_id):
        return jsonify({"error": "You are not assigned to teach this subject"}), 403
    if subject_out_of_scope(Subject.query.get(subject_id)):
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    # a quest belongs to a specific class code, never the whole subject --
    # empty used to silently mean "every section of this subject", which
    # is exactly the behavior that let old quests leak into new class
    # codes. it's required now.
    visible_to_sections = data.get('visible_to_sections') or []
    if not visible_to_sections:
        return jsonify({"error": "Select at least one class code this quest should be visible to"}), 400

    if data['xp_reward'] > max_xp[data['difficulty']]:
        return jsonify({
            "error": f"XP reward exceeds maximum for {data['difficulty']} difficulty. Maximum: {max_xp[data['difficulty']]}"
        }), 400

    # Handle starter_code: if string, parse as JSON; if dict, use as-is
    starter_code = data.get('starter_code', {})
    if isinstance(starter_code, str):
        try:
            starter_code = json.loads(starter_code)
        except:
            starter_code = {}

    # Parse due_date if provided (invalid values are rejected, not dropped)
    due_date, due_err = parse_due_date(data.get('due_date'))
    if due_err:
        return jsonify({"error": "invalid_due_date", "message": due_err}), 400

    p = Problem(
        subject_id=subject_id,  # links this quest to a subject
        title=data['title'],
        description=data['description'],
        category=data.get('category','General'),
        difficulty=data['difficulty'],
        xp_reward=data['xp_reward'],
        test_cases=data['test_cases'],
        starter_code=starter_code,
        is_published=data.get('is_published', False),
        created_by=user.id,
        due_date=due_date,
        # PRO FEATURES
        problem_type=data.get('problem_type', 'coding'),
        languages=data.get('languages', ['python']),
        is_event_quest=data.get('is_event_quest', False),
        visible_to_sections=visible_to_sections,
        hints=data.get('hints', []),
        tags=data.get('tags', []),
        prerequisites=data.get('prerequisites', []),
        estimated_time=data.get('estimated_time'),
        partial_credit=data.get('partial_credit', 100),
        auto_grade=data.get('auto_grade', True),
        plagiarism_threshold=data.get('plagiarism_threshold', 0.85)
    )

    db.session.add(p)
    db.session.commit()

    return jsonify({"message": "Problem created", "problem_id": p.id}), 201

@app.route('/api/problems', methods=['GET'])
@jwt_required()  # needs auth so we can filter by student
def get_problems():
    """Get published problems with filtering for block visibility & problem type"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    # block_id param ignored — blocks removed
    subject_id = request.args.get('subject_id', type=int)
    problem_type = request.args.get('type')

    query = Problem.query.filter_by(is_published=True)

    if subject_id:
        query = query.filter_by(subject_id=subject_id)

    if problem_type:
        query = query.filter_by(problem_type=problem_type)

    problems = query.all()
    filtered = []

    if user.role in ('instructor', 'administrator'):
        for p in problems:
            if user.role == 'administrator' or p.created_by == user_id:
                filtered.append(p)
    else:
        # Student path — get enrolled sections
        enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
        student_section_ids = [e.section_id for e in enrollments]
        if not student_section_ids:
            return jsonify([]), 200

        # a quest belongs to a specific class code, never the whole
        # subject -- this used to fall back to "any subject match" which
        # is why students could see quests uploaded to a different
        # (sometimes already-deleted) class code under the same subject
        for p in problems:
            if p.visible_to_sections and any(
                sid in p.visible_to_sections for sid in student_section_ids
            ):
                filtered.append(p)

    result = []
    for p in filtered:
        # Parse starter_code if stored as string
        starter = p.starter_code
        if isinstance(starter, str):
            try:
                starter = json.loads(starter)
            except:
                starter = {}

        # Get instructor name
        instructor_name = "System"
        if p.created_by:
            instructor = User.query.get(p.created_by)
            if instructor:
                instructor_name = instructor.username

        section_names = []
        if p.visible_to_sections:
            sections = SubjectSection.query.filter(SubjectSection.id.in_(p.visible_to_sections)).all()
            section_names = [s.section_no for s in sections]

        result.append({
            "id": p.id,
            "title": p.title,
            "description": p.description,
            "difficulty": p.difficulty,
            "xp_reward": p.xp_reward,
            "problem_type": p.problem_type,
            "is_event_quest": p.is_event_quest,
            "languages": p.languages or ['python'],
            "hints": serialize_hints_for_viewer(p, user),
            "tags": p.tags or [],
            "starter_code": starter,
            "test_cases": sanitize_test_cases_for_student(p.test_cases),
            "estimated_time": p.estimated_time,
            "partial_credit": p.partial_credit,
            "auto_grade": p.auto_grade,
            "due_date": p.due_date.isoformat() if p.due_date else None,
            "instructor_name": instructor_name,
            "section_names": section_names,
            "created_at": p.created_at.isoformat()
        })

    return jsonify(result), 200

@app.route('/api/problems/<int:problem_id>', methods=['GET'])
@jwt_required()
def get_problem_detail(problem_id):
    """Get single problem details (for student code editor)"""
    viewer = db.session.get(User, int(get_jwt_identity()))
    problem = Problem.query.get_or_404(problem_id)
    if not problem.is_published or not user_can_access_problem(viewer, problem, historical=True):
        return deny_problem_access()

    # Parse starter_code
    starter = problem.starter_code
    if isinstance(starter, str):
        try:
            starter = json.loads(starter)
        except:
            starter = {}

    # Get instructor name
    instructor_name = "System"
    if problem.created_by:
        instructor = User.query.get(problem.created_by)
        if instructor:
            instructor_name = instructor.username

    section_names = []
    if problem.visible_to_sections:
        sections = SubjectSection.query.filter(SubjectSection.id.in_(problem.visible_to_sections)).all()
        section_names = [s.section_no for s in sections]

    return jsonify({
        "id": problem.id,
        "title": problem.title,
        "description": problem.description,
        "difficulty": problem.difficulty,
        "xp_reward": problem.xp_reward,
        "problem_type": problem.problem_type,
        "is_event_quest": problem.is_event_quest,
        "languages": problem.languages or ['python'],
        "hints": serialize_hints_for_viewer(problem, viewer),
        "starter_code": starter,
        "test_cases": sanitize_test_cases_for_student(problem.test_cases),
        "estimated_time": problem.estimated_time,
        "due_date": problem.due_date.isoformat() if problem.due_date else None,
        "instructor_name": instructor_name,
        "section_names": section_names
    }), 200

@app.route('/api/problems/<int:problem_id>', methods=['PUT'])
@jwt_required()
def update_problem(problem_id):
    """Update an existing problem (instructors/admins only)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    problem = Problem.query.get_or_404(problem_id)

    # Verify ownership
    if problem.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your problem"}), 403

    data = request.get_json()

    # ===== VALIDATION (same as create) =====
    new_due_date, due_err = parse_due_date(data.get('due_date'))
    if due_err:
        return jsonify({"error": "invalid_due_date", "message": due_err}), 400
    required = ['title', 'description', 'difficulty', 'xp_reward', 'test_cases']
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields"}), 400

    if data['difficulty'] not in ['Easy', 'Medium', 'Hard']:
        return jsonify({"error": "Invalid difficulty"}), 400

    if not isinstance(data['test_cases'], list) or len(data['test_cases']) == 0:
        return jsonify({"error": "At least one test case required"}), 400

    # XP Validation
    max_xp = MAX_XP_BY_DIFFICULTY
    if data['xp_reward'] > max_xp[data['difficulty']]:
        return jsonify({
            "error": f"XP reward exceeds maximum for {data['difficulty']} difficulty"
        }), 400

    # Subject validation
    subject_id = data.get('subject_id')
    if not subject_id:
        return jsonify({"error": "Course subject is required"}), 400

    if not is_instructor_assigned(user_id, subject_id):
        return jsonify({"error": "You are not assigned to teach this subject"}), 403
    if subject_id != problem.subject_id and subject_out_of_scope(Subject.query.get(subject_id)):
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    visible_to_sections = data.get('visible_to_sections', problem.visible_to_sections) or []
    if not visible_to_sections:
        return jsonify({"error": "Select at least one class code this quest should be visible to"}), 400

    # ===== UPDATE FIELDS =====
    problem.title = data['title']
    problem.description = data['description']
    problem.difficulty = data['difficulty']
    problem.xp_reward = data['xp_reward']
    problem.category = data.get('category', problem.category)
    problem.test_cases = data['test_cases']
    problem.is_published = data.get('is_published', problem.is_published)
    problem.subject_id = subject_id

    # PRO FEATURES
    problem.problem_type = data.get('problem_type', problem.problem_type)
    problem.languages = data.get('languages', problem.languages)
    problem.is_event_quest = data.get('is_event_quest', problem.is_event_quest)
    problem.visible_to_sections = visible_to_sections
    problem.hints = data.get('hints', problem.hints)
    problem.tags = data.get('tags', problem.tags)
    problem.prerequisites = data.get('prerequisites', problem.prerequisites)
    problem.estimated_time = data.get('estimated_time', problem.estimated_time)
    problem.partial_credit = data.get('partial_credit', problem.partial_credit)
    problem.auto_grade = data.get('auto_grade', problem.auto_grade)
    problem.plagiarism_threshold = data.get('plagiarism_threshold', problem.plagiarism_threshold)

    # due_date was validated before any field was changed; an absent/empty value leaves the stored one as is
    if new_due_date is not None:
        problem.due_date = new_due_date

    # Handle starter_code
    starter_code = data.get('starter_code')
    if starter_code:
        if isinstance(starter_code, str):
            try:
                starter_code = json.loads(starter_code)
            except:
                pass
        problem.starter_code = starter_code

    db.session.commit()

    return jsonify({
        "message": "Problem updated successfully",
        "problem_id": problem.id
    }), 200

# ===== PROBLEM DELETE ENDPOINT =====
@app.route('/api/problems/<int:problem_id>', methods=['DELETE'])
@jwt_required()
def delete_problem(problem_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    problem = Problem.query.get_or_404(problem_id)

    if problem.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your problem"}), 403

    # Clean up related submissions
    Submission.query.filter_by(problem_id=problem_id).delete()

    db.session.delete(problem)
    db.session.commit()

    return jsonify({"message": "Problem deleted"}), 200

# ===== LESSON ROUTES =====
@app.route('/api/lessons', methods=['POST'])
@jwt_required()
def create_lesson():
    """Create a new lesson (instructors only)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    data = request.get_json()

    # Validation -- section_id is now required: a module belongs to one
    # specific class code, never the whole subject (see get_lessons /
    # get_student_lessons for why that matters)
    required = ['title', 'description', 'week_number', 'subject_id', 'section_id']
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields (a module needs a specific class code)"}), 400

    section = SubjectSection.query.get(data['section_id'])
    if not section:
        return jsonify({"error": "Class code not found"}), 404

    # Verify instructor is assigned to this subject
    if not is_instructor_assigned(user_id, section.subject_id):
        return jsonify({"error": "You are not assigned to teach this subject"}), 403
    if subject_out_of_scope(Subject.query.get(section.subject_id)):
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    # Create lesson -- subject_id always derived from the section so the
    # two can never disagree
    lesson = Lesson(
        title=data['title'],
        description=data.get('description', ''),
        week_number=data['week_number'],
        subject_id=section.subject_id,
        section_id=section.id,
        created_by=user_id,
        is_published=data.get('is_published', False)
    )

    db.session.add(lesson)
    db.session.commit()

    return jsonify({
        "message": "Lesson created",
        "lesson_id": lesson.id
    }), 201

@app.route('/api/lessons/<int:lesson_id>/files', methods=['POST'])
@jwt_required()
def upload_lesson_file(lesson_id):
    """Upload a file to a lesson (instructors only)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    lesson = Lesson.query.get_or_404(lesson_id)

    # Verify ownership
    if lesson.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your lesson"}), 403

    # Check if file was uploaded
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # Validate file type
    allowed_types = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'zip']
    file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if file_ext not in allowed_types:
        return jsonify({"error": f"File type .{file_ext} not allowed"}), 400

    # Validate file size (16MB max)
    if file.content_length and file.content_length > 16 * 1024 * 1024:
        return jsonify({"error": "File too large (max 16MB)"}), 400

    # Generate secure filename
    import uuid, os
    secure_name = f"{uuid.uuid4().hex}.{file_ext}"

    # Create uploads folder if not exists
    rel_dir = 'uploads/lessons/' + str(lesson_id)
    os.makedirs(os.path.join(UPLOAD_ROOT, 'lessons', str(lesson_id)), exist_ok=True)

    # Save file (the database keeps the relative path with forward slashes)
    file_path = rel_dir + '/' + secure_name
    file.save(upload_abs_path(file_path))

    # Create database record
    lesson_file = LessonFile(
        lesson_id=lesson_id,
        filename=secure_name,
        original_filename=file.filename,
        file_type=file_ext,
        file_size=file.content_length or 0,
        storage_path=file_path
    )

    db.session.add(lesson_file)
    db.session.commit()

    return jsonify({
        "message": "File uploaded",
        "file_id": lesson_file.id,
        "filename": file.filename
    }), 201

@app.route('/api/lessons/<int:lesson_id>', methods=['PUT'])
@jwt_required()
def update_lesson(lesson_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    lesson = Lesson.query.get_or_404(lesson_id)
    if lesson.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your lesson"}), 403

    data = request.get_json()
    if 'title'        in data: lesson.title        = data['title'].strip()
    if 'description'  in data: lesson.description  = data['description'].strip()
    if 'week_number'  in data: lesson.week_number  = int(data['week_number'])
    if 'is_published' in data: lesson.is_published = bool(data['is_published'])

    db.session.commit()
    return jsonify({"message": "Lesson updated"}), 200


@app.route('/api/lessons/<int:lesson_id>', methods=['DELETE'])
@jwt_required()
def delete_lesson(lesson_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    lesson = Lesson.query.get_or_404(lesson_id)
    if lesson.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your lesson"}), 403

    # delete physical files from disk first
    import os
    files = LessonFile.query.filter_by(lesson_id=lesson_id).all()
    for f in files:
        ap = upload_abs_path(f.storage_path)
        if ap and os.path.exists(ap):
            try:
                os.remove(ap)
            except OSError:
                pass  # file already gone, no big deal
        db.session.delete(f)

    db.session.delete(lesson)
    db.session.commit()
    return jsonify({"message": "Lesson deleted"}), 200


@app.route('/api/lessons/<int:lesson_id>/files/<int:file_id>', methods=['DELETE'])
@jwt_required()
def delete_lesson_file(lesson_id, file_id):
    # this is for deleting one file from a module without wiping the whole thing
    import os
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    lesson = Lesson.query.get_or_404(lesson_id)
    if lesson.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your lesson"}), 403

    f = LessonFile.query.get_or_404(file_id)
    if f.lesson_id != lesson_id:
        return jsonify({"error": "File not found"}), 404

    ap = upload_abs_path(f.storage_path)
    if ap and os.path.exists(ap):
        try:
            os.remove(ap)
        except OSError:
            pass  # file already gone, no big deal

    db.session.delete(f)
    db.session.commit()
    return jsonify({"message": "File deleted"}), 200


@app.route('/api/lessons/<int:lesson_id>/files/<int:file_id>/download', methods=['GET'])
@jwt_required()
def download_lesson_file(lesson_id, file_id):
    # this url is shared by both sides — instructors download from
    # CourseMaterials.jsx, students download from StudentLessons.jsx.
    # used to be 2 separate functions both sitting on this same url.
    # flask just runs whichever one it finds first, so the instructor
    # check always ran first and every student got blocked with a 403,
    # even though the student logic further down the file was fine —
    # it just never got a turn. merged them into one function that
    # checks the role instead. if downloads ever break again for
    # students, start here.
    import os
    from flask import send_file

    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "Unauthorized"}), 401

    lesson = Lesson.query.get_or_404(lesson_id)
    f = LessonFile.query.get_or_404(file_id)
    if f.lesson_id != lesson_id:
        return jsonify({"error": "File not found"}), 404

    if is_instructor_or_admin(user):
        # instructor has to own the lesson. admins can grab anything.
        if lesson.created_by != user_id and user.role != 'administrator':
            return jsonify({"error": "Not your lesson"}), 403
    else:
        # student has to be enrolled in a section under this subject
        enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
        section_ids = [e.section_id for e in enrollments]
        if not section_ids:
            return jsonify({"error": "Not enrolled"}), 403

        # the lesson belongs to one class code and must be published
        if not lesson.is_published or lesson.section_id not in section_ids:
            return jsonify({"error": "Access denied"}), 403

    # storage_path is relative; it is resolved against the uploads folder (never the launch directory)
    abs_path = upload_abs_path(f.storage_path)
    if not abs_path or not os.path.exists(abs_path):
        return jsonify({"error": "File not found on disk"}), 404

    return send_file(abs_path, as_attachment=True, download_name=f.original_filename)

@app.route('/api/lessons', methods=['GET'])
@jwt_required()
def get_lessons():
    """Get lessons created by this instructor, optionally scoped to one class code"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    class_id = request.args.get('class_id', type=int)

    query = Lesson.query.filter_by(created_by=user_id)
    if class_id:
        query = query.filter_by(section_id=class_id)
    lessons = query.all()

    result = []
    for lesson in lessons:
        # Get files for this lesson
        files = LessonFile.query.filter_by(lesson_id=lesson.id).all()

        result.append({
            "id": lesson.id,
            "title": lesson.title,
            "description": lesson.description,
            "week_number": lesson.week_number,
            "subject_id": lesson.subject_id,
            "section_id": lesson.section_id,
            "is_published": lesson.is_published,
            "created_at": lesson.created_at.isoformat(),
            "files": [{
                "id": f.id,
                "filename": f.original_filename,
                "file_size": f.file_size or 0,
                "file_type": f.file_type
            } for f in files]
        })

    return jsonify(result), 200

@app.route('/api/student/lessons', methods=['GET'])
@jwt_required()
def get_student_lessons():
    """Get lessons for one specific class code the student is enrolled in.

    Modules belong to a single class code, not the whole subject -- a
    student in section 29115 must never see a module uploaded for 29116,
    even though both are "Introduction to Computing Lab"."""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    section_id = request.args.get('section_id', type=int)
    if not section_id:
        return jsonify([]), 200

    enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
    section_ids = [e.section_id for e in enrollments]
    if section_id not in section_ids:
        return jsonify([]), 200

    lessons = Lesson.query.filter(
        Lesson.is_published == True,
        Lesson.section_id == section_id
    ).order_by(Lesson.week_number, Lesson.created_at).all()

    result = []
    for lesson in lessons:
        # Get files for this lesson
        files = LessonFile.query.filter_by(lesson_id=lesson.id).all()

        result.append({
            "id": lesson.id,
            "title": lesson.title,
            "description": lesson.description,
            "week_number": lesson.week_number,
            "created_at": lesson.created_at.isoformat(),
            "files": [{
                "id": f.id,
                "filename": f.original_filename,
                "file_type": f.file_type
            } for f in files]
        })

    return jsonify(result), 200

# ===== SUBMISSION ROUTES =====
@app.route('/api/problems/<int:problem_id>/hints/revealed', methods=['GET'])
@jwt_required()
def get_revealed_hints(problem_id):
    # tells the student-side editor which hints it already revealed for
    # this problem, so reopening or refreshing the page shows the right
    # hints as still-unblurred instead of resetting to "nothing revealed"
    user_id = int(get_jwt_identity())
    prob = db.session.get(Problem, problem_id)
    if not prob or not user_can_access_problem(db.session.get(User, user_id), prob, historical=True):
        return deny_problem_access()
    revealed = HintReveal.query.filter_by(user_id=user_id, problem_id=problem_id).all()
    hints = (prob.hints if prob else None) or []
    # "texts" lets the editor show already-revealed hints after a refresh,
    # since the text is no longer shipped with the problem for locked hints
    texts = {
        str(r.hint_index): hints[r.hint_index].get('text', '')
        for r in revealed
        if 0 <= r.hint_index < len(hints) and isinstance(hints[r.hint_index], dict)
    }
    return jsonify({"revealed": [r.hint_index for r in revealed], "texts": texts}), 200


@app.route('/api/problems/<int:problem_id>/hints/<int:hint_index>/reveal', methods=['POST'])
@jwt_required()
def reveal_hint(problem_id, hint_index):
    # saves a hint reveal the moment a student clicks it, so the penalty
    # applies at submission time based on our own records — refreshing
    # the page or editing the request afterward can't undo it
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    prob = Problem.query.get_or_404(problem_id)
    if not user_can_access_problem(user, prob):
        return deny_problem_access()
    if not prob.hints or not (0 <= hint_index < len(prob.hints)):
        return jsonify({"error": "Invalid hint index"}), 400

    existing = HintReveal.query.filter_by(
        user_id=user_id, problem_id=problem_id, hint_index=hint_index
    ).first()
    if not existing:
        db.session.add(HintReveal(
            user_id=user_id, problem_id=problem_id, hint_index=hint_index
        ))
        db.session.commit()

    hint = prob.hints[hint_index] if isinstance(prob.hints[hint_index], dict) else {}
    return jsonify({
        "revealed":   True,
        "xp_penalty": hint.get('xp_penalty', 0),
        "text":       hint.get('text', ''),
    }), 200


# A graded submission is reserved BEFORE the code runs and written AFTER it
# finishes, so no database transaction is open while Docker works and no
# half-finished row ever shows up in scores, analytics or plagiarism scans.
#
#   submission_slots   one row per (student, problem), UNIQUE in the database
#     pending -> done     the result (submission row + XP) was written
#     pending -> failed   the code runner broke; the attempt is NOT consumed
#
# Only a legitimate assessed result (wrong answer, compile error, a student's
# own timeout, ...) consumes the single graded attempt. A slot left "pending"
# by a crash becomes claimable again after PENDING_SLOT_STALE_SECONDS.
PENDING_SLOT_STALE_SECONDS = 15 * 60


class SubmissionConflict(Exception):
    """The student already has a graded submission, or one is being graded right now."""
    def __init__(self, message, existing=None):
        super().__init__(message)
        self.message = message
        self.existing = existing


def claim_submission_slot(user_id, problem_id):
    """
    Reserve the one graded attempt (short transaction, committed before running).
    Raises SubmissionConflict if it is taken. The UNIQUE key makes two
    simultaneous requests safe: only one INSERT (or one UPDATE of a failed or
    stale slot) can succeed.
    """
    # a legitimately graded submission from before slots existed
    prior = Submission.query.filter_by(user_id=user_id, problem_id=problem_id).first()
    if prior:
        raise SubmissionConflict("You have already submitted this problem. Use Run to test your code.", prior)

    now = datetime.utcnow()
    token = str(_uuid.uuid4())
    stale_before = now - timedelta(seconds=PENDING_SLOT_STALE_SECONDS)
    slot = SubmissionSlot.query.filter_by(user_id=user_id, problem_id=problem_id).first()
    if slot is None:
        db.session.add(SubmissionSlot(user_id=user_id, problem_id=problem_id,
                                      status='pending', claimed_at=now, owner_token=token))
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            raise SubmissionConflict("Your submission for this problem is already being processed.")
        return token
    if slot.status == 'done':
        raise SubmissionConflict("You have already submitted this problem. Use Run to test your code.")
    # 'failed' (runner broke last time) or a 'pending' slot abandoned by a crash:
    # take it over with a single conditional UPDATE so only one request wins
    won = SubmissionSlot.query.filter(
        SubmissionSlot.id == slot.id,
        db.or_(SubmissionSlot.status == 'failed',
               db.and_(SubmissionSlot.status == 'pending', SubmissionSlot.claimed_at < stale_before)),
    ).update({'status': 'pending', 'claimed_at': now, 'finished_at': None, 'owner_token': token},
      synchronize_session=False)
    db.session.commit()
    if won != 1:
        raise SubmissionConflict("Your submission for this problem is already being processed.")
    return token


def release_submission_slot(user_id, problem_id, error_text, token=None):
    """The runner failed: free the attempt so the student can try again."""
    try:
        q = SubmissionSlot.query.filter_by(user_id=user_id, problem_id=problem_id, status='pending')
        if token is not None:
            q = q.filter_by(owner_token=token)       # only the current owner may release
        q.update(
            {'status': 'failed', 'finished_at': datetime.utcnow(), 'error_msg': (error_text or '')[:500]},
            synchronize_session=False)
        db.session.commit()
    except Exception:
        db.session.rollback()
        logger.exception("could not release submission slot (user=%s problem=%s); it will expire on its own",
                         user_id, problem_id)


@app.route('/api/submissions', methods=['POST'])
@jwt_required()
@rate_limit(max_calls=10, period=60)
def create_submission():
    """Submit code for grading: one graded attempt per problem, partial credit and floor XP."""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    data = request.get_json() or {}
    if not all(k in data for k in ['problem_id', 'code', 'language']):
        return jsonify({"error": "Missing fields"}), 400

    prob = Problem.query.get_or_404(data['problem_id'])
    if not prob.is_published or not user_can_access_problem(user, prob):
        # unpublished, or not in one of this student's classes: nothing is claimed or graded
        return deny_problem_access()

    # Deadline enforcement
    if prob.due_date and datetime.utcnow() > prob.due_date:
        return jsonify({
            "error": "Deadline passed",
            "message": f"This quest closed on {prob.due_date.strftime('%B %d, %Y at %I:%M %p UTC')}",
            "due_date": prob.due_date.isoformat()
        }), 403

    # plain values for use after the reservation is committed (ORM objects
    # expire on commit and would otherwise reopen a transaction)
    problem_id = prob.id
    test_cases = list(prob.test_cases or [])
    xp_reward  = prob.xp_reward
    partial_pc = prob.partial_credit or 100
    hints      = list(prob.hints or [])
    code, language = data['code'], data['language']

    try:
        slot_token = claim_submission_slot(user_id, problem_id)
    except SubmissionConflict as c:
        body = {"error": "Already submitted", "message": c.message}
        if c.existing is not None:
            body.update({"submission_id": c.existing.id, "status": c.existing.status, "score": c.existing.score})
        return jsonify(body), 409

    # XP floor table — 10% of xp_reward, minimum guaranteed even on errors
    floor_xp = max(5, int(xp_reward * 0.10))

    # ── run the code (no database transaction is held open here) ──────────
    try:
        results = evaluate_code(code, test_cases, language, raise_on_infra=True)
    except ExecutionInfrastructureError as e:
        logger.error("grading runner failure (user=%s problem=%s): %s", user_id, problem_id, e)
        release_submission_slot(user_id, problem_id, str(e), slot_token)
        return jsonify({
            "error": "The code runner is temporarily unavailable.",
            "message": "Your attempt was not counted. Please try again in a moment.",
            "attempt_consumed": False,
        }), 503
    except Exception as e:
        logger.exception("unexpected grading failure (user=%s problem=%s)", user_id, problem_id)
        release_submission_slot(user_id, problem_id, str(e), slot_token)
        return jsonify({
            "error": "Grading could not be completed.",
            "message": "Your attempt was not counted. Please try again in a moment.",
            "attempt_consumed": False,
        }), 500

    # ── score it ──────────────────────────────────────────────────────────
    total       = len(results)
    passed      = sum(1 for r in results if r['passed'])
    # outcome of the STUDENT'S code, from what the runner reported per test
    has_timeout = any(r.get('kind') == 'timeout' for r in results)
    has_error   = any(r.get('kind') == 'runtime_error' for r in results)   # compile failure / crash
    if total == 0:
        status, score = 'error', 0
    elif passed == total:
        status, score = 'accepted', xp_reward
    elif has_timeout:
        status, score = 'timeout', floor_xp
    elif passed == 0 and has_error:
        status, score = 'error', floor_xp
    elif passed == 0:
        status, score = 'wrong_answer', floor_xp
    else:
        status = 'partial'
        score  = max(floor_xp, int(xp_reward * (passed / total) * (partial_pc / 100.0)))

    # ── write the result and the XP in ONE short transaction ──────────────
    try:
        # each hint's xp_penalty is subtracted once per revealed hint, floored at 0
        hint_penalty = 0
        for r in HintReveal.query.filter_by(user_id=user_id, problem_id=problem_id).all():
            if 0 <= r.hint_index < len(hints):
                hint_penalty += hints[r.hint_index].get('xp_penalty', 0)
        score = max(0, score - hint_penalty)

        # XP only for improvement over an earlier graded result (none exist under
        # the current one-attempt policy, kept for submissions from older versions)
        best_prev = (Submission.query.filter_by(user_id=user_id, problem_id=problem_id)
                     .order_by(Submission.score.desc()).first())
        xp_delta = max(0, score - (best_prev.score if best_prev else 0))

        # Lock order matters on MySQL: take the student's row lock FIRST (the XP update),
        # then insert the submission. Inserting first takes a shared lock on the user row
        # through the foreign key, and two concurrent submissions then deadlock when both
        # try to upgrade it (seen on a real MySQL 9 server in mysql_concurrency_check.py).
        # A deadlock that still happens is retried; the whole write is one transaction.
        for attempt in range(4):
            try:
                if xp_delta > 0:
                    # increments are done by the database, so two submissions for
                    # different problems at the same time cannot overwrite each other
                    User.query.filter_by(id=user_id).update(
                        {User.xp: User.xp + xp_delta}, synchronize_session=False)
                    User.query.filter_by(id=user_id).update(
                        {User.level: 1 + (User.xp // 100)}, synchronize_session=False)
                slot_done = SubmissionSlot.query.filter_by(
                    user_id=user_id, problem_id=problem_id, status='pending', owner_token=slot_token
                ).update({'status': 'done', 'finished_at': datetime.utcnow()}, synchronize_session=False)
                if slot_done != 1:
                    # someone else took over a slot we held too long: do not grade twice
                    db.session.rollback()
                    return jsonify({"error": "Already submitted",
                                    "message": "Your submission for this problem is already being processed."}), 409
                sub = Submission(user_id=user_id, problem_id=problem_id, code=code, language=language,
                                 status=status, score=score, passed_cases=passed, total_cases=total,
                                 result_details=recorded_result_details(results))
                db.session.add(sub)
                db.session.commit()
                break
            except OperationalError as oe:
                db.session.rollback()
                code_no = getattr(getattr(oe, 'orig', None), 'args', [None])[0]
                if code_no in (1213, 1205) and attempt < 3:      # deadlock / lock wait timeout
                    time.sleep(0.05 * (attempt + 1))
                    continue
                raise
    except Exception:
        db.session.rollback()
        logger.exception("could not save the result (user=%s problem=%s)", user_id, problem_id)
        # nothing was written; free the attempt so the student is not penalised
        release_submission_slot(user_id, problem_id, 'result could not be saved', slot_token)
        return jsonify({
            "error": "Your result could not be saved.",
            "message": "Your attempt was not counted. Please try again in a moment.",
            "attempt_consumed": False,
        }), 500

    user = User.query.get(user_id)
    return jsonify({
        "submission_id": sub.id,
        "status":        status,
        "score":         score,
        "passed_cases":  passed,
        "total_cases":   total,
        "xp_earned":     xp_delta,
        "test_results":  results,
        "user_xp":       user.xp,
        "user_level":    user.level,
        "scoring_note": (
            f"All {total} test cases passed. Full XP awarded." if status == 'accepted'
            else f"{passed}/{total} test cases passed. {score} XP awarded." if status == 'partial'
            else f"Participation credit awarded: {score} XP."
        )
    }), 201

@app.route('/api/problems/<int:problem_id>/my-submission', methods=['GET'])
@jwt_required()
def get_my_submission(problem_id):
    """Check if current student has already submitted this problem"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if user.role != 'student':
        return jsonify({"has_submitted": False}), 200

    sub = Submission.query.filter_by(
        user_id=user_id,
        problem_id=problem_id
    ).order_by(Submission.submitted_at.desc()).first()

    if not sub:
        return jsonify({"has_submitted": False}), 200

    return jsonify({
        "has_submitted": True,
        "status": sub.status,
        "score": sub.score,
        "passed_cases": sub.passed_cases,
        "total_cases": sub.total_cases,
        "submitted_at": sub.submitted_at.isoformat(),
        "language": sub.language
    }), 200

@app.route('/api/problems/<int:problem_id>/draft', methods=['GET'])
@jwt_required()
def get_code_draft(problem_id):
    """Fetch this student's in-progress code for a quest, if any was autosaved."""
    user_id = int(get_jwt_identity())
    language = request.args.get('language', 'python')
    prob = db.session.get(Problem, problem_id)
    if not prob or not user_can_access_problem(db.session.get(User, user_id), prob, historical=True):
        return deny_problem_access()

    draft = CodeDraft.query.filter_by(
        user_id=user_id, problem_id=problem_id, language=language
    ).first()

    if not draft:
        return jsonify({"code": None}), 200

    return jsonify({
        "code": draft.code,
        "updated_at": draft.updated_at.isoformat()
    }), 200

@app.route('/api/problems/<int:problem_id>/draft', methods=['PUT'])
@jwt_required()
def save_code_draft(problem_id):
    """Autosave (or manual-save) this student's in-progress code for a quest."""
    user_id = int(get_jwt_identity())
    data = request.get_json() or {}
    language = data.get('language', 'python')
    code = data.get('code', '')
    prob = db.session.get(Problem, problem_id)
    me = db.session.get(User, user_id)
    if not prob or not user_can_access_problem(me, prob):
        return deny_problem_access()
    if not isinstance(code, str) or len(code) > 100_000:
        return jsonify({"error": "Code too large"}), 413
    # once the graded submission exists the editor is read-only: a later autosave
    # must not replace the code that was graded
    if me.role == 'student' and Submission.query.filter_by(user_id=user_id, problem_id=problem_id).first():
        return jsonify({"error": "Already submitted", "message": "This quest has a final graded submission; the draft is locked."}), 409

    draft = CodeDraft.query.filter_by(
        user_id=user_id, problem_id=problem_id, language=language
    ).first()

    if draft:
        draft.code = code
    else:
        draft = CodeDraft(user_id=user_id, problem_id=problem_id, language=language, code=code)
        db.session.add(draft)

    db.session.commit()
    return jsonify({"saved": True}), 200

@app.route('/api/problems/<int:problem_id>/draft', methods=['DELETE'])
@jwt_required()
def clear_code_draft(problem_id):
    """Drop the saved draft for a quest, e.g. after a successful submit or a manual reset."""
    user_id = int(get_jwt_identity())
    language = request.args.get('language', 'python')

    CodeDraft.query.filter_by(
        user_id=user_id, problem_id=problem_id, language=language
    ).delete()
    db.session.commit()

    return jsonify({"deleted": True}), 200

@app.route('/api/problems/<int:problem_id>/run', methods=['POST'])
@jwt_required()
@rate_limit(max_calls=20, period=60)
def run_problem_code(problem_id):
    """Students run code against test cases without submitting (no XP, no lock)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    data = request.get_json()
    if not all(k in data for k in ['code', 'language']):
        return jsonify({"error": "Missing code or language"}), 400

    prob = Problem.query.get_or_404(problem_id)
    if not prob.is_published or not user_can_access_problem(user, prob):
        return deny_problem_access()

    try:
        results = evaluate_code(data['code'], prob.test_cases, data['language'])
        passed = sum(1 for r in results if r['passed'])
        total = len(results)

        return jsonify({
            "message": "Run mode — no submission recorded",
            "test_results": results,
            "passed": passed,
            "total": total,
            "is_run_mode": True,
            "success_rate": round((passed / total * 100), 1) if total > 0 else 0
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/problems/<int:problem_id>/test', methods=['POST'])
@jwt_required()
def test_problem_code(problem_id):
    """Instructors can test code without submitting (no XP, no submission recorded)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Instructors and admins only"}), 403

    data = request.get_json()
    if not all(k in data for k in ['code', 'language']):
        return jsonify({"error": "Missing code or language"}), 400

    prob = Problem.query.get_or_404(problem_id)
    if not prob.is_published or not user_can_access_problem(user, prob):
        return deny_problem_access()

    # Run the code against test cases
    try:
        results = evaluate_code(data['code'], prob.test_cases, data['language'])

        passed = sum(1 for r in results if r['passed'])
        total = len(results)

        return jsonify({
            "message": "Test mode - no submission recorded",
            "test_results": results,
            "passed": passed,
            "total": total,
            "success_rate": round((passed/total*100), 1) if total > 0 else 0
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/student/submissions', methods=['GET'])
@jwt_required()
def get_student_submissions():
    user_id = int(get_jwt_identity())
    page = request.args.get('page', 1, type=int)
    limit = min(request.args.get('limit', 15, type=int), 50)
    # optional Hero Sheet filter: only submissions for quests belonging to
    # this one subject, instead of every subject the student is enrolled in
    subject_id = request.args.get('subject_id', type=int)

    base_query = Submission.query.filter_by(user_id=user_id)
    if subject_id:
        base_query = base_query.join(Problem).filter(Problem.subject_id == subject_id)

    total = base_query.count()
    subs = base_query\
        .order_by(Submission.submitted_at.desc())\
        .limit(limit).offset((page-1)*limit).all()

    # one query for every problem this page needs, instead of querying
    # per row per field — this page used to run up to 4 database queries
    # per submission just to get its title and difficulty
    problem_ids = list(set(s.problem_id for s in subs))
    problems_by_id = {p.id: p for p in Problem.query.filter(Problem.id.in_(problem_ids)).all()}

    return jsonify({
        "submissions": [{
            "id": s.id,
            "problem_id": s.problem_id,
            "problem_title": problems_by_id[s.problem_id].title if s.problem_id in problems_by_id else "Unknown",
            "difficulty": problems_by_id[s.problem_id].difficulty if s.problem_id in problems_by_id else None,
            "status": s.status,
            "score": s.score,
            "language": s.language,
            "submitted_at": s.submitted_at.isoformat()
        } for s in subs],
        "total": total,
        "page": page,
        "pages": max(1, (total + limit - 1) // limit)
    }), 200

def calculate_streak(subs):
    # counts consecutive days (counting back from the newest submission)
    # that a student has submitted something. shared by 2 places:
    # /api/student/stats (the flame icon) and /api/student/achievements
    # (streak-type badges) — so both always show the same real number.
    # achievements used to fake this as xp // 100 instead of checking
    # real dates. moved the real logic here so nothing can fake it again.
    if not subs:
        return 0
    sorted_subs = sorted(subs, key=lambda x: x.submitted_at, reverse=True)
    last_date = sorted_subs[0].submitted_at.date()
    streak = 1
    for i in range(1, len(sorted_subs)):
        curr_date = sorted_subs[i].submitted_at.date()
        if (last_date - curr_date).days == 1:
            streak += 1
            last_date = curr_date
        elif (last_date - curr_date).days > 1:
            break
    return min(streak, 30)  # cap it so it never shows a silly huge number

@app.route('/api/student/stats', methods=['GET'])
@jwt_required()
def get_student_stats():
    """Get student's gamification stats for dashboard.

    By default this is account-wide (every subject mixed together), which
    is the original behavior and still what `user.xp` / `user.level`
    directly store. Passing ?subject_id=<id> instead scopes everything to
    quests belonging to that one subject -- XP/level in that case can't
    just read user.xp (that column has no per-subject breakdown), so it's
    recomputed the same way real XP is ever awarded: the best score the
    student ever got on each problem, summed up (see the xp_delta logic
    in submit_solution). Achievement-bonus XP is NOT included in the
    per-subject number, since badges themselves aren't tied to one
    subject -- only real quest scores are.
    """
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    subject_id = request.args.get('subject_id', type=int)

    if subject_id:
        subs = Submission.query.join(Problem)\
            .filter(Submission.user_id == user.id, Problem.subject_id == subject_id).all()
        accepted = len([s for s in subs if s.status == 'accepted'])
        streak = calculate_streak(subs)

        best_by_problem = {}
        for s in subs:
            if s.problem_id not in best_by_problem or s.score > best_by_problem[s.problem_id]:
                best_by_problem[s.problem_id] = s.score
        subject_xp = sum(best_by_problem.values())

        return jsonify({
            "total_xp": subject_xp,
            "level": 1 + (subject_xp // 100),
            "total_submissions": len(subs),
            "accepted_submissions": accepted,
            "success_rate": round((accepted/len(subs)*100), 1) if subs else 0.0,
            "streak": streak,
            "last_submission": subs[0].submitted_at.isoformat() if subs else None,
            "scope": "subject"
        }), 200

    subs = Submission.query.filter_by(user_id=user.id).all()
    accepted = len([s for s in subs if s.status == 'accepted'])
    streak = calculate_streak(subs)

    return jsonify({
        "total_xp": user.xp,
        "level": user.level,
        "total_submissions": len(subs),
        "accepted_submissions": accepted,
        "success_rate": round((accepted/len(subs)*100), 1) if subs else 0.0,
        "streak": streak,
        "last_submission": subs[0].submitted_at.isoformat() if subs else None,
        "scope": "global"
    }), 200


# ===== ACHIEVEMENT AWARDING =====
# What the code below can really measure. This is the ONLY source of `attainable`: a definition whose
# requirement_type is not listed for its category cannot be earned today (nothing computes its progress).
# Do not extend a list without also adding the progress calculation in the matching route.
STUDENT_EARNABLE_TYPES = frozenset({'quest_count', 'streak', 'python_count', 'java_count',
                                    'csharp_count', 'hard_count', 'debug_count'})
INSTRUCTOR_EARNABLE_TYPES = frozenset({'lesson_count', 'problem_count', 'blocks_taught',
                                       'subjects_taught', 'students_taught', 'file_count', 'student_quest'})
EARNABLE_TYPES = {'student': STUDENT_EARNABLE_TYPES, 'instructor': INSTRUCTOR_EARNABLE_TYPES}
AWARD_MAX_ATTEMPTS = 4                       # 1 try + 3 retries, only for deadlock / lock-wait errors
_RETRYABLE_DB_CODES = (1213, 1205)           # MySQL/MariaDB: deadlock, lock wait timeout


class AwardRetryExhausted(Exception):
    """A recognised lock conflict persisted through every attempt. Nothing was written."""


def achievement_attainable(category, requirement_type):
    return requirement_type in EARNABLE_TYPES.get(category or '', frozenset())


def _utc_iso(dt):
    """Stored times are naive UTC. Send an explicit 'Z': a bare '2026-10-22T16:30:00' is read by browsers as
    LOCAL time (a day early for Asia/Manila after 16:00 UTC). Whole seconds, matching the DATETIME column."""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt.replace(microsecond=0).isoformat() + 'Z'


def _award_attempt(user_id, candidates):
    """ONE attempt, inside the caller's transaction (caller commits or rolls back).
    candidates = [(achievement_id, xp_reward, progress)] - plain values, so a rollback/retry rebuilds
    everything from the database and nothing depends on stale ORM state.

    Lock order (the same as create_submission, which takes the users row first via its UPDATE):
      1. the users row  (SELECT ... FOR UPDATE)  - serialises every XP writer for this user
      2. this user's user_achievements rows (locking read)
      3. INSERT missing awards -> UPDATE users.xp -> UPDATE users.level
    The re-read in step 2 is a LOCKING read on purpose: under REPEATABLE READ a plain read would use the
    snapshot opened earlier in the request and miss awards another request committed meanwhile.
    Returns the set of achievement ids this attempt inserted."""
    user = User.query.filter_by(id=user_id).with_for_update().populate_existing().first()
    if user is None:
        raise LookupError("user vanished")
    have = {r[0] for r in db.session.query(UserAchievement.achievement_id)
            .filter_by(user_id=user_id).with_for_update().all()}
    created, gain = set(), 0
    for ach_id, reward, progress in candidates:
        if ach_id in have or ach_id in created:
            continue
        db.session.add(UserAchievement(user_id=user_id, achievement_id=ach_id, progress=progress))
        created.add(ach_id)
        gain += int(reward or 0)
    db.session.flush()
    if gain > 0:
        # database-side arithmetic (never "user.xp += n" from an object that may be stale)
        User.query.filter_by(id=user_id).update({User.xp: User.xp + gain}, synchronize_session=False)
        # level follows the resulting XP in the same transaction (same rule create_submission uses).
        # A zero-reward award writes no users row at all; unrelated historical level drift is not repaired here.
        User.query.filter_by(id=user_id).update({User.level: 1 + (User.xp // 100)}, synchronize_session=False)
    return created


def award_achievements(user_id, candidates, sleep=None):
    """Award rows + XP + level commit together or not at all. Retries only recognised lock conflicts (whole
    transaction rolled back and rebuilt each time, bounded). Anything else is rolled back and re-raised."""
    if not candidates:
        return set()
    for attempt in range(AWARD_MAX_ATTEMPTS):
        try:
            created = _award_attempt(user_id, candidates)
            db.session.commit()
            return created
        except OperationalError as oe:
            db.session.rollback()
            code_no = getattr(getattr(oe, 'orig', None), 'args', [None])[0]
            if code_no in _RETRYABLE_DB_CODES:
                if attempt < AWARD_MAX_ATTEMPTS - 1:
                    (sleep or time.sleep)(0.05 * (attempt + 1))
                    continue
                raise AwardRetryExhausted() from oe
            raise
        except BaseException:
            db.session.rollback()
            raise
    raise AwardRetryExhausted()


def _canonical_awards(user_id):
    """{achievement_id: (earned_at, row_id)} from the durable rows. A historical duplicate pair is reported
    as ONE earned achievement: the earliest RECORDED time (rows with no time never beat one that has it),
    lowest id on ties. Originals are not touched and this does not claim to explain past XP."""
    best = {}
    for ua in UserAchievement.query.filter_by(user_id=user_id).order_by(UserAchievement.id).all():
        key = (ua.earned_at is None, ua.earned_at or datetime.max, ua.id)
        if ua.achievement_id not in best or key < best[ua.achievement_id][0]:
            best[ua.achievement_id] = (key, ua.earned_at)
    return {aid: v[1] for aid, v in best.items()}


def serve_achievements(user_id, rows):
    """rows = [(Achievement, current_progress_or_None, attainable)]. Awards what is newly met (one shared path
    for every role), then describes the COMMITTED state. just_earned is true only for rows this request
    inserted and committed. Returns a Flask response."""
    plain = [(a.id, a.xp_reward, a.requirement_value, a.requirement_type, a.category, a.name,
              a.description, a.icon, p, ok) for a, p, ok in rows]
    earned_before = _canonical_awards(user_id)
    candidates = [(i, reward, prog) for i, reward, need, rt, cat, nm, ds, ic, prog, ok in plain
                  if ok and prog is not None and i not in earned_before and prog >= need]
    try:
        created = award_achievements(user_id, candidates)
    except AwardRetryExhausted:
        resp = jsonify({"error": "award_temporarily_unavailable", "retryable": True,
                        "message": "Your achievements could not be updated right now. Nothing was changed; please try again."})
        resp.status_code = 503
        resp.headers['Retry-After'] = '1'
        return resp
    except Exception:
        logger.exception("achievement award failed (user=%s); rolled back", user_id)
        return jsonify({"error": "award_failed", "retryable": False,
                        "message": "Your achievements could not be updated. Nothing was changed."}), 500
    db.session.expire_all()          # describe what the database now holds (incl. a concurrent winner's award)
    earned = _canonical_awards(user_id)
    out = []
    for i, reward, need, rt, cat, nm, ds, ic, prog, ok in plain:
        out.append({
            "id": i, "name": nm, "description": ds, "icon": ic,
            "category": cat, "requirement_type": rt,
            "xp_reward": reward,
            "is_earned": i in earned,
            "attainable": bool(ok),
            "just_earned": i in created,
            "progress": min(prog or 0, need),
            "max_progress": need,
            "requirement_value": need,
            "earned_at": _utc_iso(earned.get(i)),
        })
    return jsonify(out), 200


@app.route('/api/student/achievements', methods=['GET'])
@jwt_required()
def get_student_achievements():
    """Get all student achievements with progress"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    # Calculate current user stats for progress tracking
    total_quests = Submission.query.filter_by(user_id=user_id, status='accepted').count()
    python_quests = Submission.query.filter_by(user_id=user_id, status='accepted', language='python').count()
    java_quests = Submission.query.filter_by(user_id=user_id, status='accepted', language='java').count()
    csharp_quests = Submission.query.filter_by(user_id=user_id, status='accepted', language='csharp').count()
    hard_quests = Submission.query.filter_by(user_id=user_id, status='accepted').join(Problem).filter(Problem.difficulty == 'Hard').count()
    debug_quests = Submission.query.filter_by(user_id=user_id, status='accepted').join(Problem).filter(Problem.problem_type == 'debugging').count()

    # need EVERY submission here (not just accepted ones) to work out
    # the real day-streak below — same rule /api/student/stats uses
    all_subs = Submission.query.filter_by(user_id=user_id).all()

    rows = []
    for ach in Achievement.query.filter_by(category='student').order_by(Achievement.id).all():
        current_progress = None          # None = nothing measures this type: it can never be earned
        if ach.requirement_type == 'quest_count':
            current_progress = total_quests
        elif ach.requirement_type == 'streak':
            current_progress = calculate_streak(all_subs)
        elif ach.requirement_type == 'python_count':
            current_progress = python_quests
        elif ach.requirement_type == 'java_count':
            current_progress = java_quests
        elif ach.requirement_type == 'csharp_count':
            current_progress = csharp_quests
        elif ach.requirement_type == 'hard_count':
            current_progress = hard_quests
        elif ach.requirement_type == 'debug_count':
            current_progress = debug_quests
        # a new type needs BOTH a branch here and an entry in STUDENT_EARNABLE_TYPES
        rows.append((ach, current_progress, ach.requirement_type in STUDENT_EARNABLE_TYPES))

    # Known limitation: this GET still performs awarding (kept for compatibility)
    return serve_achievements(user_id, rows)

@app.route('/api/instructor/achievements', methods=['GET'])
@jwt_required()
def get_instructor_achievements():
    """Get all instructor achievements with progress"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if user.role not in ['instructor', 'administrator']:
        return jsonify({"error": "Instructors only"}), 403

    # Calculate instructor stats
    lessons_created = Lesson.query.filter_by(created_by=user_id).count()
    problems_created = Problem.query.filter_by(created_by=user_id).count()

    # Get blocks this instructor teaches
    assignments = TeacherAssignment.query.filter_by(instructor_id=user_id).all()
    sections_taught = len(set(a.section_id for a in assignments if a.section_id))
    subjects_taught = len(set(a.subject_id for a in assignments))

    # Count students taught via sections → blocks
    section_ids_list = [a.section_id for a in assignments if a.section_id]
    students_taught = 0
    if section_ids_list:
        if section_ids_list:
            students_taught = db.session.query(IrregularEnrollment.student_id).filter(
                IrregularEnrollment.section_id.in_(section_ids_list)
            ).distinct().count()

    # Count files uploaded to lessons
    files_uploaded = db.session.query(LessonFile.id).join(Lesson).filter(
        Lesson.created_by == user_id
    ).count()

    rows = []
    for ach in Achievement.query.filter_by(category='instructor').order_by(Achievement.id).all():
        current_progress = None          # None = nothing measures this type: it can never be earned
        if ach.requirement_type == 'lesson_count':
            current_progress = lessons_created
        elif ach.requirement_type == 'problem_count':
            current_progress = problems_created
        elif ach.requirement_type == 'blocks_taught':
            current_progress = sections_taught
        elif ach.requirement_type == 'subjects_taught':
            current_progress = subjects_taught
        elif ach.requirement_type == 'students_taught':
            current_progress = students_taught
        elif ach.requirement_type == 'file_count':
            current_progress = files_uploaded
        elif ach.requirement_type == 'student_quest':
            # Count students who completed at least one quest in instructor's sections
            current_progress = 0
            if section_ids_list:
                current_progress = db.session.query(Submission.user_id).join(Problem).filter(
                    Problem.created_by == user_id,
                    Submission.status == 'accepted'
                ).distinct().count()
        # a new type needs BOTH a branch here and an entry in INSTRUCTOR_EARNABLE_TYPES
        rows.append((ach, current_progress, ach.requirement_type in INSTRUCTOR_EARNABLE_TYPES))

    return serve_achievements(user_id, rows)

# ===== STUDENT BLOCK/SUBJECT ROUTES =====
@app.route('/api/student/subjects', methods=['GET'])
@jwt_required()
def get_student_subjects():
    user_id = int(get_jwt_identity())

    enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
    section_ids = [e.section_id for e in enrollments]

    if not section_ids:
        return jsonify([]), 200

    seen_subjects = {}
    for section in SubjectSection.query.filter(SubjectSection.id.in_(section_ids)).all():
        subject = Subject.query.get(section.subject_id)
        if not subject:
            continue
        assignment = TeacherAssignment.query.filter_by(
            subject_id=subject.id, section_id=section.id
        ).first()
        instructor = User.query.get(assignment.instructor_id) if assignment else None

        if subject.id not in seen_subjects:
            seen_subjects[subject.id] = {
                "id": subject.id,
                "name": subject.name,
                "subject_code": subject.subject_code,
                "section_id": section.id,
                "section_no": section.section_no,   # Class Code
                "semester": section.semester,
                "instructor": (instructor.full_name or instructor.username) if instructor else "TBA"
            }

    return jsonify(list(seen_subjects.values())), 200

@app.route('/api/student/open-quests', methods=['GET'])
@jwt_required()
def get_student_open_quests():
    # every quest across all of a student's enrolled subjects that they
    # have not yet submitted. running code doesn't count — only a real
    # Submit removes a quest from this list, since that's the point where
    # it locks and can't be attempted again. grouped by subject so the
    # Bounty Board can show a clear section break per subject.
    user_id = int(get_jwt_identity())

    enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
    section_ids = [e.section_id for e in enrollments]
    if not section_ids:
        return jsonify([]), 200

    submitted_ids = {
        s.problem_id for s in Submission.query.filter_by(user_id=user_id).all()
    }

    groups = {}
    for section in SubjectSection.query.filter(SubjectSection.id.in_(section_ids)).all():
        subject = Subject.query.get(section.subject_id)
        if not subject:
            continue
        assignment = TeacherAssignment.query.filter_by(
            subject_id=subject.id, section_id=section.id
        ).first()
        instructor = User.query.get(assignment.instructor_id) if assignment else None

        problems = Problem.query.filter_by(subject_id=subject.id, is_published=True).all()

        open_quests = []
        for p in problems:
            if p.id in submitted_ids:
                continue
            if p.visible_to_sections and section.id not in p.visible_to_sections:
                continue
            open_quests.append({
                "id": p.id,
                "title": p.title,
                "difficulty": p.difficulty,
                "xp_reward": p.xp_reward,
                "problem_type": p.problem_type,
                "is_event_quest": p.is_event_quest,
                "languages": p.languages or ['python'],
            })

        if not open_quests:
            continue

        if subject.id not in groups:
            groups[subject.id] = {
                "subject_id": subject.id,
                "subject_name": subject.name,
                "section_id": section.id,
                "section_no": section.section_no,
                "semester": section.semester,
                "instructor": (instructor.full_name or instructor.username) if instructor else "TBA",
                "quests": []
            }
        groups[subject.id]["quests"].extend(open_quests)

    return jsonify(list(groups.values())), 200


@app.route('/api/student/submissions/by-section', methods=['GET'])
@jwt_required()
def get_submissions_by_section():
    user_id = int(get_jwt_identity())
    section_id = request.args.get('section_id', type=int)

    if not section_id:
        return jsonify({"error": "section_id required"}), 400

    enrollment = IrregularEnrollment.query.filter_by(
        student_id=user_id, section_id=section_id
    ).first()
    if not enrollment:
        return jsonify({"error": "Not enrolled in this class code"}), 403

    section = SubjectSection.query.get(section_id)
    if not section:
        return jsonify({"submissions": []}), 200

    problems_for_subject = Problem.query.filter_by(
        subject_id=section.subject_id, is_published=True
    ).all()
    problem_ids = [p.id for p in problems_for_subject]
    # reuses the list already fetched above instead of querying again
    # per row — this page used to run 2 extra queries per submission
    problems_by_id = {p.id: p for p in problems_for_subject}

    if not problem_ids:
        return jsonify({"submissions": []}), 200

    subs = Submission.query.filter(
        Submission.user_id == user_id,
        Submission.problem_id.in_(problem_ids)
    ).order_by(Submission.submitted_at.desc()).all()

    return jsonify({
        "submissions": [{
            "id": s.id,
            "problem_id": s.problem_id,
            "problem_title": problems_by_id[s.problem_id].title if s.problem_id in problems_by_id else "Unknown",
            "difficulty": problems_by_id[s.problem_id].difficulty if s.problem_id in problems_by_id else None,
            "status": s.status,
            "score": s.score,
            "language": s.language,
            "submitted_at": s.submitted_at.isoformat()
        } for s in subs]
    }), 200

# ===== LEADERBOARD =====
@app.route('/api/leaderboard', methods=['GET'])
@jwt_required()
def get_leaderboard():
    # block_id param ignored — blocks removed

    section_id = request.args.get('section_id', type=int)
    if section_id:
        student_rows = IrregularEnrollment.query.filter_by(section_id=section_id).all()
        student_ids = [s.student_id for s in student_rows]
        if student_ids:
            students = User.query.filter(
                User.id.in_(student_ids),
                User.role == 'student'
            ).order_by(User.xp.desc()).limit(20).all()
        else:
            students = []
    else:
        # Global leaderboard
        students = User.query.filter_by(role='student').order_by(User.xp.desc()).limit(20).all()

    return jsonify([{
        "id": s.id,
        "rank": i+1,
        "username": s.username,
        "full_name": s.full_name or s.username,
        "xp": s.xp,
        "level": s.level
    } for i, s in enumerate(students)]), 200

# ===== INSTRUCTOR ROUTES =====
@app.route('/api/instructor/problems', methods=['GET'])
@jwt_required()
def get_instructor_problems():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    problems = Problem.query.filter_by(created_by=user.id).all()
    return jsonify([{
        "id": p.id,
        "title": p.title,
        "difficulty": p.difficulty,
        "is_published": p.is_published,
        "xp_reward": p.xp_reward,
        "problem_type": p.problem_type,
        "is_event_quest": p.is_event_quest,
        "languages": p.languages or ['python'],
        "tags": p.tags or [],
        "visible_to_sections": p.visible_to_sections or [],
        "due_date": p.due_date.isoformat() if p.due_date else None,
        "created_at": p.created_at.isoformat()
    } for p in problems]), 200

@app.route('/api/instructor/classes/<int:class_id>/problems', methods=['GET'])
@jwt_required()
def get_class_problems(class_id):
    """Problems scoped to a specific block — only shows problems visible to that block."""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    if user.role != 'administrator':
        assignment = TeacherAssignment.query.filter_by(
            instructor_id=user_id
        ).first()
        if not assignment:
            return jsonify({"error": "Not assigned to any section"}), 403

    section = SubjectSection.query.get(class_id)
    if not section:
        return jsonify({"error": "Class not found"}), 404

    problems = Problem.query.filter_by(created_by=user_id).all()

    result = []
    for p in problems:
        # strict: a quest shows up on this class page only if this exact
        # class code is in its visible_to_sections list. no more
        # subject-wide fallback for an empty list -- every quest is
        # required to pick its section(s) at creation now.
        if not p.visible_to_sections or class_id not in p.visible_to_sections:
            continue

        result.append({
            "id": p.id,
            "title": p.title,
            "difficulty": p.difficulty,
            "is_published": p.is_published,
            "xp_reward": p.xp_reward,
            "problem_type": p.problem_type,
            "languages": p.languages or ['python'],
            "tags": p.tags or [],
            "visible_to_sections": p.visible_to_sections or [],
            "due_date": p.due_date.isoformat() if p.due_date else None,
            "created_at": p.created_at.isoformat()
        })

    return jsonify(result), 200

@app.route('/api/instructor/problems/<int:problem_id>', methods=['GET'])
@jwt_required()
def get_instructor_problem_detail(problem_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    problem = Problem.query.get_or_404(problem_id)
    if problem.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your problem"}), 403

    # Parse starter_code
    starter = problem.starter_code
    if isinstance(starter, str):
        try:
            starter = json.loads(starter)
        except:
            starter = {}

    return jsonify({
        "id": problem.id,
        "title": problem.title,
        "description": problem.description,
        "difficulty": problem.difficulty,
        "category": problem.category,
        "xp_reward": problem.xp_reward,
        "test_cases": problem.test_cases,
        "starter_code": starter,
        "is_published": problem.is_published,
        "problem_type": problem.problem_type,
        "languages": problem.languages,
        "is_event_quest": problem.is_event_quest,
        "visible_to_sections": problem.visible_to_sections,
        "hints": problem.hints,
        "tags": problem.tags,
        "prerequisites": problem.prerequisites,
        "estimated_time": problem.estimated_time,
        "partial_credit": problem.partial_credit,
        "auto_grade": problem.auto_grade,
        "plagiarism_threshold": problem.plagiarism_threshold,
        "due_date": problem.due_date.isoformat() if problem.due_date else None,
        # the edit form needs this to pre-select (and lock) the subject the
        # quest already belongs to — without it, editing always falls back
        # to the blank "Select a subject you teach" state
        "subject_id": problem.subject_id
    }), 200

@app.route('/api/instructor/classes', methods=['GET'])
@jwt_required()
def get_instructor_classes():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    # Get assigned sections from TeacherAssignment table
    assignments = TeacherAssignment.query.filter_by(instructor_id=user_id).all()
    section_ids = list(set(a.section_id for a in assignments if a.section_id is not None))

    if not section_ids:
        return jsonify([]), 200

    sections = SubjectSection.query.filter(SubjectSection.id.in_(section_ids)).all()
    result = []

    for s in sections:
        my_subject_ids = [a.subject_id for a in assignments if a.section_id == s.id]
        subjects = [Subject.query.get(sid).name for sid in my_subject_ids if Subject.query.get(sid)]

        student_count = IrregularEnrollment.query.filter_by(section_id=s.id).count()
        problem_count = Problem.query.filter_by(
            created_by=user_id, is_published=True, subject_id=s.subject_id
        ).count()

        lesson_count = 0
        if my_subject_ids:
            lesson_count = Lesson.query.filter(
                Lesson.subject_id.in_(my_subject_ids)
            ).count()

        announcement_count = Announcement.query.filter_by(class_id=s.id).count()

        result.append({
            "id": s.id,
            "section_no": s.section_no,
            "section_code": s.section_no,
            "name": ', '.join(subjects) if subjects else s.section_no,
            "subjects": subjects,
            "subject_id": s.subject_id,  # needed by the quest-creation class picker
            "semester": s.semester,
            "student_count": student_count,
            "problem_count": problem_count,
            "lesson_count": lesson_count,
            "announcement_count": announcement_count
        })

    return jsonify(result), 200

@app.route('/api/instructor/classes/<int:classId>', methods=['GET'])
@jwt_required()
def get_instructor_class_detail(classId):
    """Get detailed information about a specific section (classId = SubjectSection.id)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    # classId is now a SubjectSection.id
    section = SubjectSection.query.get_or_404(classId)

    # Verify instructor has this section assigned
    assignments = TeacherAssignment.query.filter_by(
        instructor_id=user_id,
        section_id=classId
    ).all()

    if not assignments and user.role != 'administrator':
        return jsonify({"error": "Not authorized to view this class"}), 403

    my_subject_ids = list(set(a.subject_id for a in assignments))
    subjects = [Subject.query.get(sid).name for sid in my_subject_ids if Subject.query.get(sid)]

    student_count = IrregularEnrollment.query.filter_by(section_id=classId).count()

    problem_count = Problem.query.filter_by(
        created_by=user_id, is_published=True, subject_id=section.subject_id
    ).count()

    lesson_count = 0
    if my_subject_ids:
        lesson_count = Lesson.query.filter(
            Lesson.subject_id.in_(my_subject_ids)
        ).count()

    announcement_count = Announcement.query.filter_by(class_id=section.id).count()

    return jsonify({
        "id": section.id,
        "subject_id": section.subject_id,
        "section_no": section.section_no,
        "section_code": section.section_no,
        "name": ', '.join(subjects) if subjects else section.section_no,
        "semester": section.semester or 'Current Semester',
        "subjects": subjects,
        "student_count": student_count,
        "problem_count": problem_count,
        "lesson_count": lesson_count,
        "announcement_count": announcement_count
    }), 200

@app.route('/api/instructor/classes/<int:class_id>/analytics', methods=['GET'])
@jwt_required()
def get_class_analytics(class_id):
    user_id = int(get_jwt_identity())
    user    = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403
    if not instructor_teaches_section(user, class_id):
        return jsonify({"error": "Not your class"}), 403

    enrollments = IrregularEnrollment.query.filter_by(section_id=class_id).all()
    student_ids = [e.student_id for e in enrollments]
    total_students = len(student_ids)

    if not student_ids:
        return jsonify({
            "total_students": 0, "total_submissions": 0,
            "accepted_submissions": 0, "success_rate": 0,
            "top_performers": [], "challenging_problems": [],
            "activity_heatmap": [], "at_risk_students": [], "avg_xp": 0,
        }), 200

    subs           = Submission.query.filter(Submission.user_id.in_(student_ids)).all()
    total_subs     = len(subs)
    accepted_subs  = [s for s in subs if s.status == 'accepted']
    success_rate   = round(len(accepted_subs) / total_subs * 100, 1) if total_subs > 0 else 0

    # top 5 by XP
    top_students = User.query.filter(User.id.in_(student_ids)).order_by(User.xp.desc()).limit(5).all()
    top_performers = [{
        "id": s.id, "username": s.username,
        "full_name": s.full_name or s.username,
        "xp": s.xp, "level": s.level,
        "solved": Submission.query.filter_by(user_id=s.id, status='accepted').count(),
    } for s in top_students]

    all_students = User.query.filter(User.id.in_(student_ids)).all()
    avg_xp = round(sum(s.xp for s in all_students) / total_students, 1) if total_students > 0 else 0

    # most challenging problems — lowest success rate, min 3 attempts
    prob_stats = _dd(lambda: {"total": 0, "accepted": 0, "title": "", "difficulty": ""})
    for s in subs:
        prob = Problem.query.get(s.problem_id)
        if prob:
            prob_stats[s.problem_id]["total"]      += 1
            prob_stats[s.problem_id]["title"]      = prob.title
            prob_stats[s.problem_id]["difficulty"] = prob.difficulty
            if s.status == 'accepted':
                prob_stats[s.problem_id]["accepted"] += 1

    challenging = []
    for pid, stat in prob_stats.items():
        if stat["total"] >= 3:
            rate = round(stat["accepted"] / stat["total"] * 100, 1)
            challenging.append({
                "problem_id": pid, "title": stat["title"],
                "difficulty": stat["difficulty"],
                "success_rate": rate, "attempts": stat["total"],
            })
    challenging.sort(key=lambda x: x["success_rate"])
    challenging = challenging[:5]

    # activity heatmap — submissions grouped by hour
    hour_counts = _dd(int)
    for s in subs:
        hour_counts[s.submitted_at.hour] += 1
    activity_heatmap = [
        {"hour": f"{h}:00", "submissions": hour_counts.get(h, 0)}
        for h in range(0, 24, 4)
    ]

    # at-risk = no submissions in last 14 days
    two_weeks_ago = _dt.utcnow() - _td(days=14)
    recent_user_ids = set(s.user_id for s in subs if s.submitted_at >= two_weeks_ago)
    at_risk = []
    for sid in student_ids:
        s = User.query.get(sid)
        if s and sid not in recent_user_ids:
            at_risk.append({
                "id": s.id, "username": s.username,
                "full_name": s.full_name or s.username,
                "xp": s.xp, "level": s.level,
            })

    return jsonify({
        "total_students":       total_students,
        "total_submissions":    total_subs,
        "accepted_submissions": len(accepted_subs),
        "success_rate":         success_rate,
        "avg_xp":               avg_xp,
        "top_performers":       top_performers,
        "challenging_problems": challenging,
        "activity_heatmap":     activity_heatmap,
        "at_risk_students":     at_risk,
    }), 200


@app.route('/api/instructor/plagiarism/scan', methods=['POST'])
@jwt_required()
def plagiarism_scan():
    user_id = int(get_jwt_identity())
    user    = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    data       = request.get_json()
    problem_id = data.get('problem_id')
    class_id   = data.get('class_id')
    threshold  = int(data.get('threshold', 85)) / 100.0

    if not problem_id:
        return jsonify({"error": "problem_id required"}), 400
    scan_problem = db.session.get(Problem, problem_id)
    if not scan_problem or not user_can_access_problem(user, scan_problem):
        return deny_problem_access()
    if class_id and not instructor_teaches_section(user, class_id):
        return jsonify({"error": "Not your class"}), 403

    query = Submission.query.filter_by(problem_id=problem_id)
    if class_id:
        enrolled    = IrregularEnrollment.query.filter_by(section_id=class_id).all()
        student_ids = [e.student_id for e in enrolled]
        query       = query.filter(Submission.user_id.in_(student_ids))

    all_subs = query.order_by(Submission.submitted_at.desc()).all()
    seen, unique_subs = {}, []
    for s in all_subs:
        if s.user_id not in seen:
            seen[s.user_id] = s
            unique_subs.append(s)

    if len(unique_subs) < 2:
        return jsonify({
            "pairs": [], "total_compared": len(unique_subs),
            "flagged": 0, "threshold": int(threshold * 100)
        }), 200

    def tokenize(code):
        code = _re.sub(r'#[^\n]*',   '', code)
        code = _re.sub(r'//[^\n]*',  '', code)
        code = _re.sub(r'/\*.*?\*/', '', code, flags=_re.DOTALL)
        tokens = _re.findall(r'\b\w+\b', code.lower())
        keywords = {
            'int','string','bool','void','return','if','else','for','while',
            'def','class','import','print','public','private','static','new',
            'this','self','true','false','null','none','and','or','not',
            'in','is','pass','break','continue'
        }
        return [t for t in tokens if t not in keywords]

    def jaccard(code1, code2):
        t1, t2 = set(tokenize(code1)), set(tokenize(code2))
        if not t1 or not t2:
            return 0.0
        return len(t1 & t2) / len(t1 | t2)

    flagged_pairs = []
    for i in range(len(unique_subs)):
        for j in range(i + 1, len(unique_subs)):
            s1, s2 = unique_subs[i], unique_subs[j]
            sim = jaccard(s1.code or '', s2.code or '')
            if sim >= threshold:
                u1 = User.query.get(s1.user_id)
                u2 = User.query.get(s2.user_id)
                flagged_pairs.append({
                    "student1": {
                        "id": s1.user_id, "name": u1.full_name or u1.username,
                        "username": u1.username, "sub_id": s1.id,
                        "status": s1.status, "language": s1.language,
                    },
                    "student2": {
                        "id": s2.user_id, "name": u2.full_name or u2.username,
                        "username": u2.username, "sub_id": s2.id,
                        "status": s2.status, "language": s2.language,
                    },
                    "similarity":    round(sim * 100, 1),
                    "code_preview1": (s1.code or '')[:600],
                    "code_preview2": (s2.code or '')[:600],
                    "ai_verdict":    None,
                })

    flagged_pairs.sort(key=lambda x: x["similarity"], reverse=True)

    # layer 2: gemini flash writes plain-english verdict for each flagged pair
    # gemini flash is free (1500 requests/day), smart enough for code analysis,
    # and needs GEMINI_API_KEY set in your .env file.
    # if the key is missing or the API fails, verdicts just stay None —
    # the similarity scores and code previews still show up fine.
    try:
        from google import genai
        import os
        api_key = os.environ.get('GEMINI_API_KEY')
        if not api_key:
            raise ValueError("GEMINI_API_KEY not set in environment")
        client = genai.Client(api_key=api_key)

        for pair in flagged_pairs[:10]:
            prompt = f"""You are helping a university instructor review potential plagiarism in student code submissions.

Two students submitted very similar code ({pair['similarity']}% similarity score) for the same programming problem.

Student 1 ({pair['student1']['name']}) code preview:
```
{pair['code_preview1']}
```

Student 2 ({pair['student2']['name']}) code preview:
```
{pair['code_preview2']}
```

Write a brief 2-3 sentence verdict for the instructor. Be direct and specific:
- What specific patterns make these similar (same variable names, same structure, same logic)?
- Does this look like one student copied from the other, or could it be coincidental?
- What should the instructor look for when reviewing the full submissions?

Keep it concise and practical. Do not be accusatory — just describe what you observe."""

            response = client.models.generate_content(
                # gemini-1.5-flash-8b is dead -- all 1.5 models were shut down by
                # Google in 2026 and now 404. 2.5 Flash followed the same path
                # later in 2026 ("no longer available to new users") -- Google's
                # own 404 response names the replacement, 3.6 Flash, which is
                # the current free-tier workhorse as of this writing.
                model='gemini-3.6-flash',
                contents=prompt
            )
            pair["ai_verdict"] = response.text
    except Exception as e:
        print(f"Gemini API unavailable for plagiarism verdicts: {e}")

    return jsonify({
        "pairs":          flagged_pairs,
        "total_compared": len(unique_subs),
        "flagged":        len(flagged_pairs),
        "threshold":      int(threshold * 100),
    }), 200

@app.route('/api/instructor/dashboard-stats', methods=['GET'])
@jwt_required()
def get_instructor_dashboard_stats():
    """Get instructor dashboard statistics"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    # Get all sections this instructor teaches (via TeacherAssignment → section_id)
    assignments = TeacherAssignment.query.filter_by(instructor_id=user_id).all()
    section_ids = list(set(a.section_id for a in assignments if a.section_id is not None))

    if not section_ids:
        return jsonify({
            "total_students": 0,
            "total_problems": 0,
            "avg_score": 0,
            "pending_reviews": 0,
            "new_problems_this_week": 0,
            "recent_activity": [],
            "top_performers": []
        }), 200

    # 1. Total students across all sections
    student_rows = db.session.query(IrregularEnrollment.student_id).filter(
        IrregularEnrollment.section_id.in_(section_ids)
    ).distinct().all()
    total_students = len(student_rows)
    student_ids = [s[0] for s in student_rows]

    # 2. Total problems created by this instructor
    total_problems = Problem.query.filter_by(created_by=user_id, is_published=True).count()

    # 3. Average score on submitted work: XP earned / XP available, as a percentage.
    #    Submission.score is the XP awarded (max = that problem's xp_reward), so each
    #    submission is measured against its own problem's xp_reward. Students who have
    #    not submitted are NOT counted as zero; they are simply absent from this figure.
    avg_score = 0
    avg_basis = {"submissions": 0, "students_submitted": 0, "students_enrolled": total_students,
                 "unsubmitted_students_excluded": True}
    if student_ids:
        rows = db.session.query(Submission.user_id, Submission.score, Problem.xp_reward).join(
            Problem, Problem.id == Submission.problem_id
        ).filter(
            Submission.user_id.in_(student_ids),
            Problem.created_by == user_id,
            Problem.is_published == True,
            Problem.xp_reward > 0
        ).all()
        if rows:
            earned = sum(r[1] or 0 for r in rows)
            available = sum(r[2] for r in rows)
            avg_score = round(earned / available * 100)
            avg_basis["submissions"] = len(rows)
            avg_basis["students_submitted"] = len({r[0] for r in rows})

    # 4. Pending reviews (submissions needing manual review)
    pending_reviews = Submission.query.filter(
        Submission.status == 'pending_review'
    ).count() if 'pending_review' in [col.name for col in Submission.__table__.columns] else 0

    # 5. New problems this week
    from datetime import datetime, timedelta
    one_week_ago = datetime.utcnow() - timedelta(days=7)
    new_problems = Problem.query.filter(
        Problem.created_by == user_id,
        Problem.created_at >= one_week_ago
    ).count()

    # 6. Recent activity — support optional class_code (section_no) filter
    filter_section_no = request.args.get('class_code', '').strip()
    filtered_student_ids = student_ids

    if filter_section_no and student_ids:
        target_section = SubjectSection.query.filter_by(section_no=filter_section_no).first()
        if target_section:
            rows = db.session.query(IrregularEnrollment.student_id).filter(
                IrregularEnrollment.section_id == target_section.id,
                IrregularEnrollment.student_id.in_(student_ids)
            ).all()
            filtered_student_ids = [r[0] for r in rows]
        else:
            filtered_student_ids = []

    recent_subs = Submission.query.filter(
        Submission.user_id.in_(filtered_student_ids) if filtered_student_ids else False
    ).order_by(Submission.submitted_at.desc()).limit(10).all()

    recent_activity = []
    for s in recent_subs:
        student_obj = User.query.get(s.user_id)
        problem_obj = Problem.query.get(s.problem_id)
        subject_name = None
        section_no_val = None
        if problem_obj and problem_obj.subject_id:
            subj = Subject.query.get(problem_obj.subject_id)
            if subj:
                subject_name = subj.name
            # Find which of the instructor's sections this student is enrolled in
            # that is also tied to this problem's subject
            enroll = IrregularEnrollment.query.filter(
                IrregularEnrollment.student_id == s.user_id,
                IrregularEnrollment.section_id.in_(section_ids)
            ).first()
            if enroll:
                sec = SubjectSection.query.get(enroll.section_id)
                if sec:
                    section_no_val = sec.section_no
        recent_activity.append({
            "id": s.id,
            "student": (student_obj.full_name or student_obj.username) if student_obj else "Unknown",
            "problem": problem_obj.title if problem_obj else "Unknown",
            "subject": subject_name,
            "section_no": section_no_val,
            "status": s.status,
            "score": s.score,
            "submitted_at": s.submitted_at.isoformat()
        })

    # 7. Top performers (top 5 students by XP)
    if student_ids:
        top_students = User.query.filter(
            User.id.in_(student_ids),
            User.role == 'student'
        ).order_by(User.xp.desc()).limit(5).all()

        top_performers = [{"id": s.id,"username": s.username,"full_name": s.full_name,"xp": s.xp,"level": s.level} for s in top_students]
    else:
        top_performers = []

    # build list of this instructor's assigned sections for the filter dropdown
    assigned_sections = []
    for sid in section_ids:
        sec = SubjectSection.query.get(sid)
        if sec:
            assigned_sections.append({
                "id": sec.id,
                "section_no": sec.section_no
            })

    return jsonify({
        "total_students": total_students,
        "total_problems": total_problems,
        "avg_score": avg_score,
        "avg_score_basis": avg_basis,
        "pending_reviews": pending_reviews,
        "new_problems_this_week": new_problems,
        "recent_activity": recent_activity,
        "top_performers": top_performers,
        "assigned_sections": assigned_sections
    }), 200

@app.route('/api/instructor/problems/<int:problem_id>/submissions', methods=['GET'])
@jwt_required()
def get_problem_submissions(problem_id):
    """Get all submissions for a specific problem (instructor view)"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    problem = Problem.query.get_or_404(problem_id)

    if problem.created_by != user_id and not is_administrator(user):
        return jsonify({"error": "Not your problem"}), 403

    submissions = Submission.query.filter_by(problem_id=problem_id)\
        .order_by(Submission.submitted_at.desc()).all()

    assignments = TeacherAssignment.query.filter_by(
        instructor_id=user_id, subject_id=problem.subject_id
    ).all()
    section_ids = list(set(a.section_id for a in assignments if a.section_id))

    # if this quest is scoped to specific sections, only count those —
    # not every section the instructor teaches for this subject
    if problem.visible_to_sections:
        section_ids = [sid for sid in section_ids if sid in problem.visible_to_sections]

    enrolled_student_ids = []
    if section_ids:
        rows = db.session.query(IrregularEnrollment.student_id).filter(
            IrregularEnrollment.section_id.in_(section_ids)
        ).distinct().all()
        enrolled_student_ids = [r[0] for r in rows]

    sub_map = {}
    for s in submissions:
        if s.user_id not in sub_map:
            sub_map[s.user_id] = s

    result_students = []
    for student_id in enrolled_student_ids:
        student = User.query.get(student_id)
        if not student or student.role != 'student':
            continue
        sub = sub_map.get(student_id)
        result_students.append({
            "id": student.id,
            "username": student.username,
            "full_name": student.full_name or student.username,
            "email": student.email,
            "submitted": sub is not None,
            "score": sub.score if sub else 0,
            "status": sub.status if sub else "Not Submitted",
            "submitted_at": sub.submitted_at.isoformat() if sub else None,
            "submission_id": sub.id if sub else None,
            "language": sub.language if sub else None,
        })

    for student_id, sub in sub_map.items():
        if student_id not in enrolled_student_ids:
            student = User.query.get(student_id)
            if student:
                result_students.append({
                    "id": student.id,
                    "username": student.username,
                    "full_name": student.full_name or student.username,
                    "email": student.email,
                    "submitted": True,
                    "score": sub.score,
                    "status": sub.status,
                    "submitted_at": sub.submitted_at.isoformat(),
                    "submission_id": sub.id,
                    "language": sub.language,
                })

    return jsonify({
        "students": result_students,
        "total": len(result_students),
        "submitted_count": sum(1 for s in result_students if s["submitted"]),
        "problem": {
            "id": problem.id,
            "title": problem.title,
            "difficulty": problem.difficulty,
            "xp_reward": problem.xp_reward
        }
    }), 200

@app.route('/api/instructor/submissions/<int:submission_id>/code', methods=['GET'])
@jwt_required()
def get_submission_code(submission_id):
    """Instructor views a student's submitted code + test results"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    sub = Submission.query.get_or_404(submission_id)
    problem = Problem.query.get_or_404(sub.problem_id)

    # Verify instructor owns this problem OR is administrator
    if problem.created_by != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your problem"}), 403

    student = User.query.get(sub.user_id)

    # Read-only: shows what was stored when the student submitted. Nothing is executed here,
    # no attempt is consumed, no XP is awarded and no record is changed.
    details = sub.result_details if isinstance(sub.result_details, dict) else None
    return jsonify({
        "submission_id": sub.id,
        "student": {
            "id": student.id,
            "username": student.username
        } if student else None,
        "problem": {
            "id": problem.id,
            "title": problem.title,
            "difficulty": problem.difficulty
        },
        "code": sub.code,
        "language": sub.language,
        "status": sub.status,
        "score": sub.score,
        "passed_cases": sub.passed_cases,
        "total_cases": sub.total_cases,
        "error_msg": sub.error_msg,
        "submitted_at": sub.submitted_at.isoformat(),
        # True only when per-test results were recorded with this submission
        "results_recorded": details is not None,
        "execution_mode": (details or {}).get("runner"),
        "test_results": (details or {}).get("tests", []),
        "note": None if details is not None else
                "This submission was saved before per-test results were recorded. Only the stored status, score and "
                "pass counts are available; they were not re-run."
    }), 200

@app.route('/api/instructor/assigned-subjects', methods=['GET'])
@jwt_required()
def get_instructor_assigned_subjects():
    """Get unique subjects this instructor is assigned to teach"""
    user_id = int(get_jwt_identity())

    # Get all teacher assignments for this instructor
    assignments = TeacherAssignment.query.filter_by(instructor_id=user_id).all()

    # Extract unique subject IDs
    subject_ids = list(set(a.subject_id for a in assignments))

    # Fetch subject details
    subjects = Subject.query.filter(Subject.id.in_(subject_ids)).all() if subject_ids else []

    return jsonify([{
        "id": s.id,
        "name": s.name,
        "description": s.description
    } for s in subjects]), 200

@app.route('/api/instructor/sections-by-subject', methods=['GET'])
@jwt_required()
def get_sections_by_subject():
    """Get blocks where instructor teaches a specific subject"""
    user_id = int(get_jwt_identity())
    subject_id = request.args.get('subject_id', type=int)

    if not subject_id:
        return jsonify({"error": "subject_id required"}), 400

    assignments = TeacherAssignment.query.filter_by(
        instructor_id=user_id,
        subject_id=subject_id
    ).all()
    section_ids = [a.section_id for a in assignments if a.section_id]
    sections = SubjectSection.query.filter(SubjectSection.id.in_(section_ids)).all()
    return jsonify([{
        "id": s.id,
        "section_no": s.section_no,
        "schedule": s.schedule or '',
        "semester": s.semester or 'Current'
    } for s in sections]), 200

# ===== ANNOUNCEMENTS =====
@app.route('/api/announcements', methods=['POST'])
@jwt_required()
def create_announcement():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    data = request.get_json()
    if not data.get('title') or not data.get('content'):
        return jsonify({"error": "Title & content required"}), 400

    class_id = data.get('class_id')

    # instructors must post to a specific class they actually teach — a
    # platform-wide announcement from an instructor was never an intended
    # feature, just an accidental gap when the frontend skipped class
    # selection (admins keep the null/global path since nothing here
    # restricts them the way it restricts an instructor's own students)
    if user.role != 'administrator':
        if not class_id:
            return jsonify({"error": "class_id required"}), 400
        section = SubjectSection.query.get(class_id)
        if not section:
            return jsonify({"error": "Class not found"}), 404
        owns = TeacherAssignment.query.filter_by(instructor_id=user.id, section_id=class_id).first()
        if not owns:
            return jsonify({"error": "You don't teach this class"}), 403
    if class_id:
        _sec = SubjectSection.query.get(class_id)
        if _sec and subject_out_of_scope(Subject.query.get(_sec.subject_id)):
            return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    a = Announcement(
        instructor_id=user.id,
        class_id=class_id,
        title=data['title'],
        content=data['content'],
        is_pinned=data.get('is_pinned', False),
        priority=data.get('priority', 'medium')
    )
    db.session.add(a)
    db.session.commit()
    return jsonify({"message": "Announcement created", "announcement_id": a.id}), 201

@app.route('/api/announcements', methods=['GET'])
@jwt_required()
def get_announcements():
    class_id = request.args.get('class_id', type=int)
    if class_id:
        q = Announcement.query.filter_by(class_id=class_id)
    else:
        q = Announcement.query.filter(Announcement.class_id == None)

    return jsonify([{
        "id": a.id,
        "title": a.title,
        "content": a.content,
        "is_pinned": a.is_pinned,
        "priority": a.priority,
        "created_at": a.created_at.isoformat(),
        "instructor": User.query.get(a.instructor_id).username if a.instructor_id else "System"
    } for a in q.order_by(Announcement.is_pinned.desc(), Announcement.created_at.desc()).all()]), 200

@app.route('/api/announcements/<int:announcement_id>', methods=['DELETE'])
@jwt_required()
def delete_announcement(announcement_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    ann = Announcement.query.get_or_404(announcement_id)

    if ann.instructor_id != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your announcement"}), 403

    db.session.delete(ann)
    db.session.commit()
    return jsonify({"message": "Announcement deleted"}), 200


@app.route('/api/announcements/<int:announcement_id>', methods=['PUT'])
@jwt_required()
def update_announcement(announcement_id):
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not is_instructor_or_admin(user):
        return jsonify({"error": "Unauthorized"}), 403

    ann = Announcement.query.get_or_404(announcement_id)

    if ann.instructor_id != user_id and user.role != 'administrator':
        return jsonify({"error": "Not your announcement"}), 403

    data = request.get_json()
    if not data.get('title') or not data.get('content'):
        return jsonify({"error": "Title and content are required"}), 400

    ann.title     = data['title'].strip()
    ann.content   = data['content'].strip()
    ann.priority  = data.get('priority', ann.priority)
    ann.is_pinned = data.get('is_pinned', ann.is_pinned)
    db.session.commit()

    return jsonify({"message": "Announcement updated"}), 200

# this is for the announcements a student actually sees
@app.route('/api/student/announcements', methods=['GET'])
@jwt_required()
def get_student_announcements():
    # every announcement visible to this student — global ones (no class_id
    # set) plus ones posted specifically to any section they're actually
    # enrolled in. uses IrregularEnrollment like every other multi-subject
    # student endpoint (Bounty Board, My Subjects) — a student can be in
    # more than one section, so a single section_id field was never enough.
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if user.role != 'student':
        return jsonify({"error": "Students only"}), 403

    enrollments = IrregularEnrollment.query.filter_by(student_id=user_id).all()
    section_ids = [e.section_id for e in enrollments]

    announcements = Announcement.query.filter(
        db.or_(
            Announcement.class_id == None,
            Announcement.class_id.in_(section_ids)
        )
    ).order_by(Announcement.is_pinned.desc(), Announcement.created_at.desc()).all()

    sections_by_id = {s.id: s for s in SubjectSection.query.filter(SubjectSection.id.in_(section_ids)).all()}
    subjects_by_id = {}
    if sections_by_id:
        subj_ids = list(set(s.subject_id for s in sections_by_id.values()))
        subjects_by_id = {s.id: s for s in Subject.query.filter(Subject.id.in_(subj_ids)).all()}

    result = []
    for a in announcements:
        subject_name = "All Subjects"
        section_no = None
        if a.class_id and a.class_id in sections_by_id:
            section = sections_by_id[a.class_id]
            section_no = section.section_no
            subject = subjects_by_id.get(section.subject_id)
            subject_name = subject.name if subject else "Unknown Subject"

        result.append({
            "id": a.id,
            "title": a.title,
            "content": a.content,
            "is_pinned": a.is_pinned,
            "priority": a.priority,
            "created_at": a.created_at.isoformat(),
            "instructor": User.query.get(a.instructor_id).username if a.instructor_id else "System",
            "class_id": a.class_id,
            # numeric subject id — lets the frontend jump straight into the
            # right subject's tabs when a notification is clicked
            "subject_id": sections_by_id[a.class_id].subject_id if a.class_id in sections_by_id else None,
            "subject_name": subject_name,
            "section_no": section_no
        })
    return jsonify(result), 200

@app.route('/api/admin/dashboard-stats', methods=['GET'])
@admin_required
def admin_dashboard_stats(admin):
    """
    Redesigned dashboard stats endpoint.

    Returns
    -------
    {
        # ── Primary metrics ──────────────────────────────────────────────
        "system_health":       "operational" | "degraded" | "down",
        "active_users_today":  <int>,   # unique users who submitted today
        "enrollment_alerts":   <int>,   # students stuck in inactive sections

        # ── Secondary (compact) metrics ──────────────────────────────────
        "total_students":      <int>,
        "total_instructors":   <int>,
        "total_sections":      <int>,   # active sections only
        "total_enrolled":      <int>,   # sum of current_count across active sections

        # ── Maintenance / misc ───────────────────────────────────────────
        "maintenance_mode":    <bool>,
        "today_logins":        <int>,   # kept for backwards-compat
        "today_submissions":   <int>,   # kept for backwards-compat

        # ── Activity feed ────────────────────────────────────────────────
        "recent_activity":     [ { id, action, details, created_at, admin }, … ]
    }
    """
    from sqlalchemy import func, distinct

    today = datetime.utcnow().date()

    # ── 1. System health ─────────────────────────────────────────────────────
    # Lightweight probe: if we can reach the DB we're operational.
    # You can extend this to ping Docker / sandbox in the future.
    try:
        db.session.execute(text('SELECT 1'))
        db_ok = True
    except Exception:
        db_ok = False

    system_health = 'operational' if db_ok else 'down'

    # ── 2. Active users today ────────────────────────────────────────────────
    # Definition: unique users (any role) who made a submission today.
    # This is more meaningful than "account created today" (the old metric).
    try:
        active_users_today = (
            db.session.query(func.count(distinct(Submission.user_id)))
            .filter(func.date(Submission.submitted_at) == today)
            .scalar() or 0
        )
    except Exception:
        active_users_today = 0

    # ── 3. Enrollment alerts ─────────────────────────────────────────────────
    # Students enrolled in a section that is currently inactive →
    # they exist in the DB but cannot access course content.
    try:
        enrollment_alerts = (
            db.session.query(func.count(distinct(IrregularEnrollment.student_id)))
            .join(SubjectSection, IrregularEnrollment.section_id == SubjectSection.id)
            .filter(SubjectSection.is_active == False)           # noqa: E712
            .scalar() or 0
        )
    except Exception:
        enrollment_alerts = 0

    # ── 4. Totals ─────────────────────────────────────────────────────────────
    total_students    = User.query.filter_by(role='student',    is_active=True).count()
    total_instructors = User.query.filter_by(role='instructor', is_active=True).count()

    # Sections: count only active ones — inactive sections are the problem,
    # not the baseline.
    total_sections = SubjectSection.query.filter_by(is_active=True).count()

    # Total enrolled: sum current_count on active sections.
    # IrregularEnrollment rows are the source of truth; current_count is a
    # denormalised cache that may lag.  We query the real count here.
    try:
        total_enrolled = (
            db.session.query(func.count(IrregularEnrollment.id))
            .join(SubjectSection, IrregularEnrollment.section_id == SubjectSection.id)
            .filter(SubjectSection.is_active == True)            # noqa: E712
            .scalar() or 0
        )
    except Exception:
        # Fallback: sum the denormalised column
        total_enrolled = (
            db.session.query(func.sum(SubjectSection.current_count))
            .filter(SubjectSection.is_active == True)            # noqa: E712
            .scalar() or 0
        )

    # ── 5. Backwards-compat values (old frontend uses these) ─────────────────
    today_logins = (
        db.session.query(func.count(distinct(Submission.user_id)))
        .filter(func.date(Submission.submitted_at) == today)
        .scalar() or 0
    )
    today_submissions = (
        Submission.query
        .filter(func.date(Submission.submitted_at) == today)
        .count()
    )

# ── 5b. Audit log count for today — feeds the Activity Logs sidebar badge ──
    # frontend AdminDashboard.jsx reads dashStats.stats?.today, expects this
    # exact shape. without this the badge is permanently stuck at 0/blank
    # because the field straight up didn't exist before.
    audit_logs_today = (
        AuditLog.query
        .filter(func.date(AuditLog.created_at) == today)
        .count()
    )

    # ── 6. Maintenance mode ───────────────────────────────────────────────────
    maint_row = SystemConfig.query.filter_by(key='maintenance_mode').first()
    maintenance_mode = (maint_row.value == 'true') if maint_row else False

    # If maintenance_mode is ON, reflect that in system_health so the
    # frontend primary card shows the right state.
    if maintenance_mode and system_health == 'operational':
        system_health = 'maintenance'

    # ── 7. Recent activity (last 10 audit log entries) ────────────────────────
    recent_logs = (
        AuditLog.query
        .order_by(AuditLog.created_at.desc())
        .limit(10)
        .all()
    )
    recent_activity = [
        {
            'id':         log.id,
            'action':     log.action,
            'details':    log.details,
            'created_at': log.created_at.isoformat(),
            'admin':      (
                User.query.get(log.admin_id).username
                if log.admin_id else 'System'
            ),
        }
        for log in recent_logs
    ]

    # ── 8. Response ───────────────────────────────────────────────────────────
    return jsonify({
        # Primary metrics
        'system_health':       system_health,
        'active_users_today':  active_users_today,
        'enrollment_alerts':   enrollment_alerts,

        # Secondary metrics
        'total_students':      total_students,
        'total_instructors':   total_instructors,
        'total_sections':      total_sections,
        'total_enrolled':      total_enrolled,

        # Maintenance / misc
        'maintenance_mode':    maintenance_mode,

        # Backwards-compat
        'today_logins':        today_logins,
        'today_submissions':   today_submissions,
        'total_problems':      0,   # kept for compat; fetched lazily by frontend

        # nested under 'stats' on purpose — AdminDashboard.jsx sidebar badge
        # for the Activity Logs tab reads dashStats.stats?.today specifically
        'stats': {
            'today': audit_logs_today,
        },

        # Activity feed
        'recent_activity':     recent_activity,
    }), 200

# ===== ADMIN ROUTES =====
@app.route('/api/admin/overview', methods=['GET'])
@admin_required
def admin_overview(admin):
    return jsonify({
        "total_users": User.query.count(),
        "active_students": User.query.filter_by(role='student', is_active=True).count(),
        "active_instructors": User.query.filter_by(role='instructor', is_active=True).count(),
        "total_submissions": Submission.query.count(),
        "today_submissions": Submission.query.filter(Submission.submitted_at >= datetime.utcnow() - timedelta(days=1)).count(),
        "maintenance_mode": (SystemConfig.query.filter_by(key='maintenance_mode').first() or type('obj', (object,), {'value': 'false'})).value == 'true',
        "server_time": datetime.utcnow().isoformat()
    }), 200

@app.route('/api/admin/policy', methods=['GET'])
@admin_required
def admin_policy(admin):
    """Settings the admin forms need: email domain and whether this admin may create admins."""
    head_exists = bool(HEAD_ADMIN_EMAIL) and User.query.filter(
        db.func.lower(User.email) == HEAD_ADMIN_EMAIL,
        User.role == 'administrator').first() is not None
    return jsonify({
        "allowed_email_domain": ALLOWED_EMAIL_DOMAIN,
        "student_email_domain": STUDENT_EMAIL_DOMAIN,
        "head_admin_configured": bool(HEAD_ADMIN_EMAIL),
        "config_diagnostics": list(CONFIG_DIAGNOSTICS),
        "can_create_admins": is_head_admin(admin),
        # false means nobody can create administrators until that account exists
        "head_admin_account_exists": head_exists,
    }), 200

@app.route('/api/admin/users', methods=['POST'])
@admin_required
def admin_create_user(admin):
    data = request.get_json()
    required = ['username', 'email', 'password', 'role']
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields"}), 400
    if data['role'] not in ['student', 'instructor', 'administrator']:
        return jsonify({"error": "Invalid role"}), 400
    if data['role'] == 'administrator' and not is_head_admin(admin):
        return jsonify({"error": "Only the head administrator can create administrator accounts."}), 403
    pw_err = password_policy_error(data.get('password'))
    if pw_err:
        return jsonify({"error": pw_err}), 400
    role = data['role']
    username = normalize_student_id(data['username']) if role == 'student' else (data['username'] or '').strip()
    if not username:
        return jsonify({"error": "Username is required"}), 400
    if role == 'student':
        # students are identified by ID; the email is a GENERATED identifier, not an inbox
        if not valid_student_id(username):
            return jsonify({"error": "Student ID must not contain spaces or '@'."}), 400
        expected = generated_student_email(username)
        supplied = normalize_email(data.get('email'))
        if supplied and supplied != expected:
            return jsonify({"error": f"Student sign-in emails are generated from the student ID ({expected}); a different address cannot be used."}), 400
        data['email'] = expected
    else:
        if not email_domain_allowed(data['email']):
            hint = f" (@{ALLOWED_EMAIL_DOMAIN})" if ALLOWED_EMAIL_DOMAIN else ""
            return jsonify({"error": f"A valid staff email address{hint} is required."}), 400
        if normalize_email(data['email']).endswith('@' + STUDENT_EMAIL_DOMAIN):
            return jsonify({"error": f"@{STUDENT_EMAIL_DOMAIN} is reserved for generated student identifiers."}), 400
        data['email'] = normalize_email(data['email'])
    if HEAD_ADMIN_EMAIL and normalize_email(data['email']) == HEAD_ADMIN_EMAIL:
        return jsonify({"error": "That email address is reserved for the head administrator."}), 400
    data['username'] = username
    # login accepts a username or an email, so a username equal to someone's
    # email would shadow that person's login
    if '@' in username and User.query.filter(db.func.lower(User.email) == username.lower()).first():
        return jsonify({"error": "Username cannot match another account's email address"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Username already exists"}), 400
    if User.query.filter(db.func.lower(User.email) == data['email']).first():
        return jsonify({"error": "Email already exists"}), 400
    new_user = User(
        username=data['username'],
        email=data['email'],
        password_hash=generate_password_hash(data['password']),
        role=data['role'],
        is_active=True,
        must_change_password=True,          # the admin knows this password: replace at first sign-in
        xp=0, level=1
    )
    db.session.add(new_user)
    db.session.flush()
    if data.get('section_ids') and data['role'] == 'student':
        for sid in data['section_ids']:
            section = SubjectSection.query.get(int(sid))
            if section and subject_out_of_scope(Subject.query.get(section.subject_id)):
                db.session.rollback()
                return jsonify({"error": f"Class code {section.section_no}: {OUT_OF_SCOPE_MSG}"}), 400
            if section:
                existing = IrregularEnrollment.query.filter_by(
                    student_id=new_user.id, section_id=int(sid)
                ).first()
                if not existing:
                    db.session.add(IrregularEnrollment(
                        student_id=new_user.id,
                        section_id=int(sid)
                    ))
    db.session.commit()
    log_admin_action(admin.id, "USER_CREATED",
        f"Created {data['role']} account: {data['username']} ({data['email']})",
        target_id=new_user.id)
    return jsonify({
        "message": "User created successfully",
        "user": {"id": new_user.id, "username": new_user.username,
                 "email": new_user.email, "role": new_user.role}
    }), 201

@app.route('/api/admin/users', methods=['GET'])
@admin_required
def admin_get_users(admin):
    role = request.args.get('role')
    search = request.args.get('search', '').lower()
    status = request.args.get('status')

    q = User.query
    if role and role != 'all': q = q.filter_by(role=role)
    if status == 'active': q = q.filter_by(is_active=True)
    elif status == 'inactive': q = q.filter_by(is_active=False)
    if search: q = q.filter((User.username.ilike(f'%{search}%')) | (User.email.ilike(f'%{search}%')) | (User.full_name.ilike(f'%{search}%')))

    users = q.order_by(User.created_at.desc()).limit(500).all()

    result = []
    for u in users:
        sections_list = []
        section_id, section_name = None, None

        if u.role == 'student':
            enrollments = IrregularEnrollment.query.filter_by(student_id=u.id).all()
            for e in enrollments:
                section = SubjectSection.query.get(e.section_id)
                if section:
                    subject = Subject.query.get(section.subject_id)
                    sections_list.append({
                        "id": section.id,
                        "section_code": section.section_no,
                        "name": section.section_no,
                        "semester": section.semester,
                        "subjects": [subject.name] if subject else []
                    })
            if sections_list:
                section_id = sections_list[0]["id"]
                section_name = sections_list[0]["section_code"]

        elif u.role == 'instructor':
            assignments = TeacherAssignment.query.filter_by(instructor_id=u.id).all()
            seen_sections = set()
            for a in assignments:
                if a.section_id and a.section_id not in seen_sections:
                    seen_sections.add(a.section_id)
                    section = SubjectSection.query.get(a.section_id)
                    subject = Subject.query.get(a.subject_id)
                    if section:
                        sections_list.append({
                            "id": section.id,
                            "section_code": section.section_no,
                            "name": section.section_no,
                            "semester": section.semester,
                            "subjects": [subject.name] if subject else []
                        })
            if sections_list:
                section_id = sections_list[0]["id"]
                section_name = sections_list[0]["section_code"]

        # Check if student has irregular enrollments
        is_irregular = False
        if u.role == 'student' and not sections_list:
            irr_count = IrregularEnrollment.query.filter_by(student_id=u.id).count()
            is_irregular = irr_count > 0

        result.append({
            "id": u.id, "username": u.username, "email": u.email, "role": u.role,
            "full_name": getattr(u, 'full_name', None) or None,
            "xp": u.xp, "level": u.level, "is_active": u.is_active,
            "created_at": u.created_at.isoformat(),
            "section_id": section_id, "section_name": section_name,
            "sections": sections_list,
            "is_irregular": is_irregular,
            "login_attempts": u.login_attempts or 0,
            "locked_until": u.locked_until.isoformat() if u.locked_until else None,
            "is_locked": bool(u.locked_until and u.locked_until > datetime.utcnow())
        })
    return jsonify(result), 200

@app.route('/api/admin/users/<int:user_id>', methods=['PUT'])
@admin_required
def admin_update_user(admin, user_id):
    target = User.query.get_or_404(user_id)
    if target.id == admin.id:
        return jsonify({"error": "Cannot modify own account"}), 400

    data = request.get_json()
    changes = []

    if 'role' in data and data['role'] == 'administrator' and target.role != 'administrator' \
            and not is_head_admin(admin):
        return jsonify({"error": "Only the head administrator can promote users to administrator."}), 403
    if 'role' in data and data['role'] in ['student','instructor','administrator']:
        if target.role != data['role']: changes.append(f"Role: {target.role} -> {data['role']}")
        target.role = data['role']
    if 'is_active' in data:
        if target.is_active != data['is_active']:
            changes.append(f"Status: {'Active' if target.is_active else 'Inactive'} -> {'Active' if data['is_active'] else 'Inactive'}")
        target.is_active = data['is_active']
    if 'xp' in data: target.xp = int(data['xp'])
    if 'level' in data: target.level = int(data['level'])

    # this is for enrolling into multiple sections/classes at once
    if 'section_ids' in data:
        section_ids = data['section_ids']
        if target.role == 'student':
            # sections the student already has are kept as they are; only NEW
            # links to out-of-scope subjects are refused
            already = {e.section_id for e in IrregularEnrollment.query.filter_by(student_id=user_id).all()}
            for sid in (section_ids or []):
                if int(sid) in already:
                    continue
                sec = SubjectSection.query.get(int(sid))
                if sec and subject_out_of_scope(Subject.query.get(sec.subject_id)):
                    db.session.rollback()
                    return jsonify({"error": f"Class code {sec.section_no}: {OUT_OF_SCOPE_MSG}"}), 400
            IrregularEnrollment.query.filter_by(student_id=user_id).delete()
            if section_ids:
                for sid in section_ids:
                    db.session.add(IrregularEnrollment(
                        student_id=user_id,
                        section_id=int(sid)
                    ))
                changes.append(f"Enrolled in {len(section_ids)} class codes")
            else:
                changes.append("Removed from all class codes")
        elif target.role == 'instructor':
            _kept = {a.section_id for a in TeacherAssignment.query.filter_by(instructor_id=user_id).all()}
            for sid in (section_ids or []):
                if int(sid) in _kept:
                    continue
                _sec = SubjectSection.query.get(int(sid))
                if _sec and subject_out_of_scope(Subject.query.get(_sec.subject_id)):
                    db.session.rollback()
                    return jsonify({"error": f"Class code {_sec.section_no}: {OUT_OF_SCOPE_MSG}"}), 400
            # this branch didn't exist before — the modal let you PICK class
            # codes for an instructor, but nothing ever saved it. same
            # "replace everything" pattern as the student branch above:
            # wipe existing assignments for this instructor, then recreate
            # from what was just picked.
            TeacherAssignment.query.filter_by(instructor_id=user_id).delete()
            if section_ids:
                assigned = 0
                conflicts = []  # class codes that belong to someone else
                for sid in section_ids:
                    section = SubjectSection.query.get(int(sid))
                    # a section always has exactly one subject (set when the
                    # section itself was created), so we don't need the
                    # frontend to send subject_id separately — just look it
                    # up here.
                    if section and section.subject_id:
                        # one instructor per class code. we already deleted this instructor's own
                        # rows above, so if a row still exists for this
                        # subject+section, it belongs to a different
                        # instructor. skip it instead of double-booking,
                        # and say so, rather than silently dropping it.
                        taken_by = TeacherAssignment.query.filter_by(
                            subject_id=section.subject_id,
                            section_id=int(sid)
                        ).first()
                        if taken_by:
                            other = User.query.get(taken_by.instructor_id)
                            conflicts.append(f"{section.section_no} (already taught by {other.username if other else 'another instructor'})")
                            continue
                        db.session.add(TeacherAssignment(
                            instructor_id=user_id,
                            subject_id=section.subject_id,
                            section_id=int(sid)
                        ))
                        assigned += 1
                changes.append(f"Assigned to {assigned} class codes")
                if conflicts:
                    changes.append(f"Skipped (already taken): {', '.join(conflicts)}")
            else:
                changes.append("Removed from all class codes")

    db.session.commit()
    log_admin_action(admin.id, "USER_UPDATED", f"Target: {target.username}. Changes: {', '.join(changes) if changes else 'None'}", target_id=user_id)
    return jsonify({"message": "User updated", "changes": changes}), 200

def _cascade_delete_student_data(user_id):
    # removes every row that references this student before the User row
    # itself can be deleted — MySQL blocks deleting a row that's still
    # referenced elsewhere (Submission/UserAchievement/HintReveal all
    # point at users.id with no CASCADE set). shared by the single-user
    # delete and the bulk-delete-all-students endpoints so both stay
    # correct together instead of quietly drifting apart later.
    HintReveal.query.filter_by(user_id=user_id).delete()
    UserAchievement.query.filter_by(user_id=user_id).delete()
    CodeDraft.query.filter_by(user_id=user_id).delete()

    # PlagiarismReport rows point at submissions.id (not nullable, no
    # cascade). Any submission that was ever run through the Instructor's
    # Plagiarism Check — even just once — leaves a report row behind, and
    # MySQL refuses to delete a submission that's still referenced. Those
    # have to go before the submissions themselves.
    submission_ids = [
        row[0] for row in
        db.session.query(Submission.id).filter_by(user_id=user_id).all()
    ]
    if submission_ids:
        PlagiarismReport.query.filter(
            db.or_(
                PlagiarismReport.submission_a_id.in_(submission_ids),
                PlagiarismReport.submission_b_id.in_(submission_ids),
            )
        ).delete(synchronize_session=False)

    Submission.query.filter_by(user_id=user_id).delete()

    # Release the student's seat in each section along with the enrollment
    # row, so current_count doesn't stay inflated after they're gone.
    for enr in IrregularEnrollment.query.filter_by(student_id=user_id).all():
        section = SubjectSection.query.get(enr.section_id)
        if section and section.current_count:
            section.current_count = max(0, section.current_count - 1)
        db.session.delete(enr)

    TeacherAssignment.query.filter_by(instructor_id=user_id).delete()

@app.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
@admin_required
def admin_delete_user(admin, user_id):
    if user_id == admin.id:
        return jsonify({"error": "Cannot delete own account"}), 400
    target = User.query.get_or_404(user_id)

    _cascade_delete_student_data(user_id)
    db.session.delete(target)
    db.session.commit()

    log_admin_action(admin.id, "USER_DELETED", f"Deleted user {target.username} (ID: {user_id})")
    return jsonify({"message": "User deleted"}), 200

@app.route('/api/admin/students/bulk-delete', methods=['DELETE'])
@admin_required
def admin_bulk_delete_students(admin):
    # deletes EVERY student account — used to clear out accumulated test
    # data before a real demo/defense. only ever touches role='student',
    # never instructors or admins, so the account running this stays safe
    # and instructor/subject/class-code setup survives intact.
    students = User.query.filter_by(role='student').all()
    count = len(students)

    for student in students:
        _cascade_delete_student_data(student.id)
        db.session.delete(student)

    db.session.commit()

    log_admin_action(admin.id, "BULK_STUDENTS_DELETED", f"Deleted all {count} student accounts.")
    return jsonify({"message": f"Deleted {count} student accounts", "count": count}), 200

@app.route('/api/admin/users/<int:user_id>/reset-password', methods=['POST'])
@admin_required
def admin_reset_password(admin, user_id):
    """
    Authorized recovery that does not depend on any inbox: the admin either types a
    temporary password or asks for a generated one (returned ONCE in this response,
    never logged). The student must replace it at next sign-in; old sessions end.
    """
    target = User.query.get_or_404(user_id)
    data = request.get_json(silent=True) or {}
    generated = False
    new_pw = data.get('new_password')
    if not new_pw and data.get('generate'):
        new_pw, generated = _generate_secure_password(), True
    if not new_pw:
        return jsonify({"error": "New password required"}), 400
    err = password_policy_error(new_pw, target)
    if err:
        return jsonify({"error": err}), 400
    target.password_hash = generate_password_hash(new_pw)
    target.must_change_password = True
    target.token_version = int(target.token_version or 0) + 1
    target.password_changed_at = datetime.utcnow()
    target.login_attempts = 0
    target.locked_until = None
    db.session.commit()
    log_admin_action(admin.id, "PASSWORD_RESET", f"Reset password for {target.username} (change required at next sign-in)")
    body = {"message": "Password reset. The user must choose a new password at next sign-in."}
    if generated:
        body["temporary_password"] = new_pw
    return jsonify(body), 200

@app.route('/api/admin/users/<int:user_id>/unlock', methods=['POST'])
@admin_required
def admin_unlock_user(admin, user_id):
    target = User.query.get_or_404(user_id)
    target.login_attempts = 0
    target.locked_until = None
    db.session.commit()
    log_admin_action(admin.id, "USER_UNLOCKED", f"Unlocked account for {target.username}")
    return jsonify({"message": f"Account {target.username} has been unlocked."}), 200

@app.route('/api/admin/users/<int:user_id>/email', methods=['PUT'])
@admin_required
def admin_update_email(admin, user_id):
    return jsonify({"error": "Institutional email addresses are permanent and cannot be changed."}), 403

@app.route('/api/admin/config', methods=['GET'])
@admin_required
def admin_get_config(admin):
    configs = {c.key: c.value for c in SystemConfig.query.all()}
    defaults = {
        # General
        'system_name': 'Forge.dev',
        'institution_name': '',
        'timezone': 'Asia/Manila',
        # Security
        'maintenance_mode': 'false',
        'min_password_length': '8',
        'session_timeout': '60',
        'jwt_expiration_hours': '24',
        # Execution
        'execution_timeout': '5',
        'enabled_languages': 'python,java,csharp',
        'memory_limit_mb': '256',
        # Gamification
        'xp_multiplier': '1.0',
        'easy_xp_max': '100',
        'medium_xp_max': '250',
        'hard_xp_max': '500',
        # Plagiarism
        'plagiarism_threshold': '0.85',
        'plagiarism_auto_flag': 'true',
    }
    for k, v in defaults.items():
        configs.setdefault(k, v)
    return jsonify(configs), 200

# Only maintenance_mode is read by the running system. The other keys used to be
# stored here but nothing ever consumed them, so saving them looked like it
# changed behaviour when it did not. They are rejected now; the real, fixed
# values are shown read-only by /api/admin/effective-settings.
ADJUSTABLE_CONFIG_KEYS = {'maintenance_mode'}


@app.route('/api/admin/config', methods=['PUT'])
@admin_required
def admin_update_config(admin):
    data = request.get_json() or {}
    not_adjustable = [k for k in data.keys() if k not in ADJUSTABLE_CONFIG_KEYS]
    if not_adjustable:
        return jsonify({
            "error": f"These settings are fixed in the application and cannot be changed here: {', '.join(not_adjustable)}"
        }), 400
    changes = []
    for k, v in data.items():
        existing = SystemConfig.query.filter_by(key=k).first()
        old_val = existing.value if existing else "N/A"
        if existing:
            existing.value = str(v)
        else:
            db.session.add(SystemConfig(key=k, value=str(v)))
        changes.append(f"{k}: {old_val} -> {v}")
    db.session.commit()
    log_admin_action(admin.id, "CONFIG_UPDATED", f"Changes: {', '.join(changes)}")
    return jsonify({"message": "Config updated", "changes": changes}), 200


@app.route('/api/admin/effective-settings', methods=['GET'])
@admin_required
def admin_effective_settings(admin):
    """Read-only view of the limits the running system really uses (nothing here is editable)."""
    from routes.sandbox import LANGUAGE_TIMEOUTS, MEM_LIMITS, LIMITS
    return jsonify({
        "execution": {
            "per_language": {
                lang: {"timeout_seconds": LANGUAGE_TIMEOUTS[lang],
                       "memory_mb": MEM_LIMITS[lang] // (1024 * 1024)}
                for lang in LANGUAGE_TIMEOUTS
            },
            "cpu_cores": LIMITS['cpu_quota'] / LIMITS['cpu_period'],
            "max_processes": LIMITS['pids_limit'],
            "max_code_characters": LIMITS['code_max_chars'],
            "max_output_bytes": LIMITS['output_bytes'],
            "network": "disabled",
        },
        "xp": {
            "max_xp_by_difficulty": MAX_XP_BY_DIFFICULTY,
            "level_rule": "level = 1 + total XP // 100",
            "failed_attempt_minimum": "10% of the problem's XP (at least 5)",
            "hint_penalty": "set per hint by the instructor",
        },
        "authentication": {"access_token_minutes": 15, "refresh_token_days": 7},
        "plagiarism": {
            "threshold": "chosen per problem (default 0.85) and per scan (default 85%)",
            "scan_trigger": "manual, started by an instructor or administrator",
            "ai_verdict_configured": bool(os.environ.get('GEMINI_API_KEY')),
        },
    }), 200

@app.route('/api/admin/audit-logs', methods=['GET'])
@admin_required
def admin_get_logs(admin):
    """
    Enhanced audit-log endpoint.

    Query params
    ────────────
    search     : str   – free-text search across action, details, ip_address
    action     : str   – comma-separated list of action names, OR a single name
                         (e.g. "USER_DELETED,SUBJECT_DELETED"  or  "USER_CREATED")
    date_from  : str   – ISO date  (YYYY-MM-DD), inclusive
    date_to    : str   – ISO date  (YYYY-MM-DD), inclusive
    sort       : str   – "asc" | "desc"  (default: desc)
    page       : int   – 1-based page number
    limit      : int   – rows per page, max 200

    Response
    ────────
    {
        "logs":  [ { id, admin, action, details, ip, created_at } … ],
        "total": <int>,
        "page":  <int>,
        "pages": <int>,
        "stats": {
            "total":             <int>,   # all-time log count
            "today":             <int>,   # logs created today (UTC)
            "unique_users":      <int>,   # distinct admin accounts that have logged an action
            "critical_total":    <int>,   # all-time count of critical-tier actions
            "last_activity":     <str>,   # ISO timestamp of most recent log
            "most_active_admin": <str|null>  # username of admin with most logs ever
        }
    }
    """
    from sqlalchemy import func

    # ── 1. Parse query params ─────────────────────────────────────────────
    search       = request.args.get('search', '').strip()
    action_param = request.args.get('action', '').strip()
    date_from    = request.args.get('date_from', '').strip()
    date_to      = request.args.get('date_to',   '').strip()
    sort_dir     = request.args.get('sort', 'desc').strip().lower()
    page         = request.args.get('page',  1, type=int)
    limit        = min(request.args.get('limit', 20, type=int), 200)

    # ── 2. Build base query ────────────────────────────────────────────────
    q = AuditLog.query

    # Action filter: comma-separated multi-select OR legacy single value
    if action_param and action_param.lower() != 'all':
        actions = [a.strip() for a in action_param.split(',') if a.strip()]
        if len(actions) == 1:
            q = q.filter(AuditLog.action == actions[0])
        elif len(actions) > 1:
            q = q.filter(AuditLog.action.in_(actions))

    # Date range filter
    if date_from:
        try:
            dt_from = datetime.strptime(date_from, '%Y-%m-%d')
            q = q.filter(AuditLog.created_at >= dt_from)
        except ValueError:
            pass  # malformed date — ignore

    if date_to:
        try:
            # Include the full end day (up to 23:59:59)
            dt_to = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
            q = q.filter(AuditLog.created_at < dt_to)
        except ValueError:
            pass

    # Free-text search
    if search:
        like = f'%{search}%'
        q = q.filter(
            (AuditLog.action.ilike(like))     |
            (AuditLog.details.ilike(like))    |
            (AuditLog.ip_address.ilike(like))
        )

    # ── 3. Sort ────────────────────────────────────────────────────────────
    if sort_dir == 'asc':
        q = q.order_by(AuditLog.created_at.asc())
    else:
        q = q.order_by(AuditLog.created_at.desc())

    # ── 4. Paginate ────────────────────────────────────────────────────────
    total    = q.count()
    logs     = q.offset((page - 1) * limit).limit(limit).all()
    pages    = max(1, (total + limit - 1) // limit)

    # ── 5. Stats ───────────────────────────────────────────────────────────
    today_date  = datetime.utcnow().date()
    today_count = AuditLog.query.filter(
        func.date(AuditLog.created_at) == today_date
    ).count()

    unique_admins = db.session.query(AuditLog.admin_id).distinct().count()

    last_log = AuditLog.query.order_by(AuditLog.created_at.desc()).first()

    # Critical-tier actions (destructive / high-impact)
    CRITICAL_ACTIONS = [
        'USER_DELETED', 'SUBJECT_DELETED', 'SECTION_DELETED',
        'DATABASE_BACKUP',
    ]
    critical_total = AuditLog.query.filter(
        AuditLog.action.in_(CRITICAL_ACTIONS)
    ).count()

    # Most active admin (by total log count, all time)
    most_active_row = (
        db.session.query(AuditLog.admin_id, func.count(AuditLog.id).label('cnt'))
        .group_by(AuditLog.admin_id)
        .order_by(func.count(AuditLog.id).desc())
        .first()
    )
    most_active_admin = None
    if most_active_row:
        u = User.query.get(most_active_row.admin_id)
        most_active_admin = u.username if u else None

    stats = {
        'total':             AuditLog.query.count(),
        'today':             today_count,
        'unique_users':      unique_admins,   # kept for legacy; means unique admins
        'critical_total':    critical_total,
        'last_activity':     last_log.created_at.isoformat() if last_log else None,
        'most_active_admin': most_active_admin,
    }

    # ── 6. Serialise ───────────────────────────────────────────────────────
    def _admin_name(admin_id):
        u = User.query.get(admin_id)
        return u.username if u else 'System'

    serialised = [
        {
            'id':         l.id,
            'admin':      _admin_name(l.admin_id),
            'action':     l.action,
            'details':    l.details,
            'ip':         l.ip_address,
            'created_at': l.created_at.isoformat(),
        }
        for l in logs
    ]

    return jsonify({
        'logs':  serialised,
        'total': total,
        'page':  page,
        'pages': pages,
        'stats': stats,
    }), 200

# ============================================================================
# paste this into app.py, near admin_get_logs (same area, they share logic)
#
# why this exists: the old "Export CSV" button on Activity Logs was calling
# /api/admin/reports, which only ever exported SUBMISSIONS data (student
# quiz scores) — there was never an endpoint that actually exports audit
# log rows. clicking "Export Logs" silently gave you the wrong file. this
# is the real one.
#
# reuses the same filter params as GET /api/admin/audit-logs (search,
# action, date_from, date_to) so "export what i'm currently looking at"
# actually works — no pagination limit here though, exports everything
# that matches the filter, not just the current page.
# ============================================================================

@app.route('/api/admin/audit-logs/export', methods=['GET'])
@admin_required
def admin_export_audit_logs(admin):
    search       = request.args.get('search', '').strip()
    action_param = request.args.get('action', '').strip()
    date_from    = request.args.get('date_from', '').strip()
    date_to      = request.args.get('date_to', '').strip()

    q = AuditLog.query

    if action_param and action_param.lower() != 'all':
        actions = [a.strip() for a in action_param.split(',') if a.strip()]
        if len(actions) == 1:
            q = q.filter(AuditLog.action == actions[0])
        elif len(actions) > 1:
            q = q.filter(AuditLog.action.in_(actions))

    if date_from:
        try:
            q = q.filter(AuditLog.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
        except ValueError:
            pass

    if date_to:
        try:
            dt_to = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
            q = q.filter(AuditLog.created_at < dt_to)
        except ValueError:
            pass

    if search:
        like = f'%{search}%'
        q = q.filter(
            (AuditLog.action.ilike(like))  |
            (AuditLog.details.ilike(like)) |
            (AuditLog.ip_address.ilike(like))
        )

    logs = q.order_by(AuditLog.created_at.desc()).all()

    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(["ID", "Admin", "Action", "Details", "IP Address", "Timestamp"])
    for log in logs:
        admin_user = User.query.get(log.admin_id)
        cw.writerow([
            log.id,
            admin_user.username if admin_user else 'System',
            log.action,
            log.details,
            log.ip_address,
            log.created_at.isoformat(),
        ])

    return app.response_class(
        si.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=audit_logs_export.csv"}
    )

@app.route('/api/admin/reports', methods=['GET'])
@admin_required
def admin_generate_report(admin):
    fmt = request.args.get('format', 'csv')
    start = request.args.get('start')
    end = request.args.get('end')

    q = Submission.query
    if start: q = q.filter(Submission.submitted_at >= datetime.fromisoformat(start))
    if end: q = q.filter(Submission.submitted_at <= datetime.fromisoformat(end))
    subs = q.all()

    if fmt == 'csv':
        si = StringIO()
        cw = csv.writer(si)
        cw.writerow(["Submission ID", "User", "Problem", "Language", "Status", "Score", "Timestamp"])
        for s in subs:
            u = User.query.get(s.user_id)
            p = Problem.query.get(s.problem_id)
            cw.writerow([s.id, u.username if u else "Unknown", p.title if p else "Unknown", s.language, s.status, s.score, s.submitted_at.isoformat()])
        return app.response_class(si.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=submissions_report.csv"})

    return jsonify({"error": "Unsupported format"}), 400

@app.route('/api/admin/users/bulk-upload-csv', methods=['POST'])
@admin_required
def admin_bulk_upload_csv(admin):
    return jsonify({"error": "This endpoint is deprecated. Use /api/admin/enrollment/bulk-upload instead."}), 410


def build_backup_sql(tables_to_export, who_label):
    """SQL text (bytes) for the given tables. Used by the admin endpoint and by backup_full.py."""
    import io
    def _sql_literal(val):
        import json as _json
        if val is None:
            return 'NULL'
        if isinstance(val, bool):
            return '1' if val else '0'
        if isinstance(val, (int, float)):
            return str(val)
        if isinstance(val, datetime):
            return "'" + val.strftime('%Y-%m-%d %H:%M:%S.%f') + "'"
        if isinstance(val, (dict, list)):
            val = _json.dumps(val, ensure_ascii=False)
        elif isinstance(val, (bytes, bytearray)):
            return "0x" + bytes(val).hex() if val else "''"
        else:
            val = str(val)
        # MySQL string literal: backslashes first, then quotes, control characters
        val = (val.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")
                  .replace("\r", "\\r").replace("\x00", "\\0"))
        return "'" + val + "'"

    # ── Build SQL dump ────────────────────────────────────────────────
    buf = io.StringIO()
    ts  = datetime.utcnow().isoformat()

    buf.write(f"-- Forge.dev Database Backup\n")
    buf.write(f"-- Generated : {ts} UTC\n")
    buf.write(f"-- Tables    : {', '.join(t.name for t in tables_to_export)}\n")
    buf.write(f"-- Requested by: {who_label}\n")
    buf.write("-- Contains password hashes and personal data: store securely.\n")
    buf.write("-- Uploaded lesson files are NOT inside this SQL file; back up the uploads folder separately.\n\n")
    buf.write("SET FOREIGN_KEY_CHECKS=0;\n\n")

    for table in tables_to_export:
        try:
            rows = db.session.execute(table.select()).fetchall()
            if not rows:
                buf.write(f"-- Table `{table.name}` is empty\n\n")
                continue
            columns = [c.name for c in table.columns]
            buf.write(f"-- ── {table.name} ({len(rows)} rows) ──\n")
            buf.write(f"TRUNCATE TABLE `{table.name}`;\n")
            col_list = ', '.join(f'`{c}`' for c in columns)
            for row in rows:
                val_list = ', '.join(_sql_literal(row._mapping[c]) for c in columns)
                buf.write(f"INSERT INTO `{table.name}` ({col_list}) VALUES ({val_list});\n")
            buf.write("\n")
        except Exception as e:
            buf.write(f"-- ERROR exporting {table.name}: {e}\n\n")

    buf.write("SET FOREIGN_KEY_CHECKS=1;\n")
    buf.write(f"-- End of backup\n")

    return buf.getvalue().encode('utf-8')


@app.route('/api/admin/backup', methods=['POST'])
@admin_required
def admin_backup_database(admin):
    """
    Trigger a database backup and return it as a downloadable SQL file.

    POST body (JSON, optional):
        { "tables": "all" }           ← full backup
        { "tables": ["users", ...] }  ← selective backup

    The route generates SQL INSERT statements from the live database and
    returns them as an attachment.  For production you would shell out
    to mysqldump and stream the result; this pure-Python implementation
    works without mysqldump and avoids extra OS dependencies.
    """
    import io

    data = request.get_json(silent=True) or {}
    tables_param = data.get('tables', 'all')

    # ── Resolve which tables to export ────────────────────────────────
    # Every table the application defines is included (the old list left out enrollments,
    # lessons, files, achievements earned, drafts, submission slots ... so a restore lost them).
    all_tables = list(db.metadata.sorted_tables)          # parents before children
    if tables_param == 'all' or not isinstance(tables_param, list):
        tables_to_export = all_tables
    else:
        wanted = set(tables_param)
        tables_to_export = [t for t in all_tables if t.name in wanted]

    sql_bytes = build_backup_sql(tables_to_export, f"{admin.username} (ID {admin.id})")

    # ── Log the action ────────────────────────────────────────────────
    log_admin_action(
        admin.id,
        'DATABASE_BACKUP',
        f"Backup generated: {len(tables_to_export)} tables, {len(sql_bytes)//1024} KB",
    )

    filename = f"forge_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.sql"

    return app.response_class(
        sql_bytes,
        mimetype='application/sql',
        headers={
            'Content-Disposition': f'attachment; filename="{filename}"',
            'Content-Length': str(len(sql_bytes)),
        }
    )


@app.route('/api/admin/subjects', methods=['POST'])
@admin_required
def admin_create_subject(admin):
    """Create a new subject with full university metadata."""
    data = request.get_json()

    # ── Basic validation ───────────────────────────────────────────────
    if not data or not data.get('name', '').strip():
        return jsonify({"error": "Subject name is required"}), 400

    name = data['name'].strip()
    if len(name) > 200:
        return jsonify({"error": "Subject name must be 200 characters or fewer"}), 400

    # ── subject_code: alphanumeric + hyphens only, no regex needed ────
    subject_code = data.get('subject_code', '').strip().upper() or None
    if subject_code:
        if len(subject_code) > 20:
            return jsonify({"error": "Subject code must be 20 characters or fewer"}), 400
        allowed_chars = set('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_')
        if not all(ch in allowed_chars for ch in subject_code):
            return jsonify({"error": "Subject code may only contain letters, digits, hyphens, and underscores"}), 400

    # ── units ─────────────────────────────────────────────────────────
    units = data.get('units')
    if units is not None:
        try:
            units = int(units)
            if units < 1 or units > 12:
                return jsonify({"error": "Units must be between 1 and 12"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "Units must be a valid integer"}), 400

    # ── year_level ────────────────────────────────────────────────────
    year_level = data.get('year_level')
    if year_level is not None:
        try:
            year_level = int(year_level)
            if year_level < 1 or year_level > 6:
                return jsonify({"error": "Year level must be between 1 and 6"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "Year level must be a valid integer"}), 400
    # Forge.dev covers first-year curriculum subjects only. This is the
    # SUBJECT's curriculum year, not a classification of the students taking it.
    if year_level is None:
        year_level = FIRST_YEAR_CURRICULUM
    elif year_level != FIRST_YEAR_CURRICULUM:
        return jsonify({"error": "Only first-year curriculum subjects are supported."}), 400

    # ── subject_type ──────────────────────────────────────────────────
    allowed_types = {'lab', 'lecture_lab', 'elective'}
    subject_type = data.get('subject_type', 'lab')
    if subject_type not in allowed_types:
        return jsonify({"error": f"subject_type must be one of: {', '.join(sorted(allowed_types))}. Note: 'lecture' type is no longer accepted for new subjects."}), 400

    # ── department ────────────────────────────────────────────────────
    department = data.get('department', '').strip() or None
    if department and len(department) > 100:
        return jsonify({"error": "Department must be 100 characters or fewer"}), 400

    # ── Duplicate check ───────────────────────────────────────────────
    existing = Subject.query.filter_by(name=name).first()
    if existing:
        return jsonify({"error": "A subject with this name already exists"}), 409

    # ── Persist ───────────────────────────────────────────────────────
    subject = Subject(
        name=name,
        description=data.get('description', '').strip() or None,
        subject_code=subject_code,
        units=units,
        department=department,
        year_level=year_level,
        subject_type=subject_type,
    )
    db.session.add(subject)
    db.session.commit()

    log_admin_action(
        admin.id,
        "SUBJECT_CREATED",
        f"Created subject: {subject.name}"
        + (f" [{subject.subject_code}]" if subject.subject_code else ""),
        target_id=subject.id,
    )

    return jsonify({
        "message": "Subject created successfully",
        "subject": {
            "id":           subject.id,
            "name":         subject.name,
            "description":  subject.description,
            "subject_code": subject.subject_code,
            "units":        subject.units,
            "department":   subject.department,
            "year_level":   subject.year_level,
            "subject_type": subject.subject_type,
        }
    }), 201

@app.route('/api/admin/subjects', methods=['GET'])
@admin_required
def admin_get_subjects(admin):
    """Get all unique subjects (for admin assignment forms)"""
    try:
        # Get all subjects
        subjects = Subject.query.all()

        # Remove duplicates in Python (keep first occurrence of each name)
        seen_names = set()
        unique_subjects = []
        for s in subjects:
            if s.name not in seen_names:
                seen_names.add(s.name)
                unique_subjects.append(s)

        return jsonify([{
            "id":           s.id,
            "name":         s.name,
            "description":  s.description,
            "subject_code": s.subject_code,
            "units":        s.units,
            "department":   s.department,
            "year_level":   s.year_level,
            "subject_type": s.subject_type,
        } for s in unique_subjects]), 200
    except Exception as e:
        print(f"Error fetching subjects: {e}")
        return jsonify({"error": "Failed to fetch subjects"}), 500


@app.route('/api/admin/subjects/<int:subject_id>', methods=['DELETE'])
@admin_required
def admin_delete_subject(admin, subject_id):
    """
    Delete a subject.
    Cascades through junction tables before removing the subject row so
    that no FK constraint fires:
      1. TeacherAssignment rows that reference this subject
      2. block_subjects junction rows
      3. SubjectSection rows (and their IrregularEnrollment children)
      4. Problems that reference this subject (subject_id set to NULL)
    """
    subject = Subject.query.get_or_404(subject_id)
    subject_name = subject.name  # capture before deletion

    # 1. Remove teacher assignments for this subject
    TeacherAssignment.query.filter_by(subject_id=subject_id).delete()

    # 2. (block_subjects removed — no longer needed)

    # 3. Remove every SubjectSection that belongs to this subject,
    #    but first remove the IrregularEnrollment rows that point to them
    sections = SubjectSection.query.filter_by(subject_id=subject_id).all()
    for sec in sections:
        IrregularEnrollment.query.filter_by(section_id=sec.id).delete()
        db.session.delete(sec)

    # 4. Nullify subject_id on Problems (keeps the problems, just unlinks them)
    Problem.query.filter_by(subject_id=subject_id).update(
        {'subject_id': None}, synchronize_session=False
    )

    # 5. Also remove any Lesson rows linked to this subject
    Lesson.query.filter_by(subject_id=subject_id).delete()

    # 6. Finally delete the subject itself
    db.session.delete(subject)
    db.session.commit()

    log_admin_action(
        admin.id, "SUBJECT_DELETED",
        f"Deleted subject: {subject_name} (ID {subject_id}) — "
        f"cascade-removed teacher assignments, block links, and sections.",
        target_id=subject_id,
    )

    return jsonify({"message": "Subject deleted successfully"}), 200

@app.route('/api/admin/subjects/<int:subject_id>', methods=['PUT'])
@admin_required
def admin_update_subject(admin, subject_id):
    """Update an existing subject"""
    subject = Subject.query.get_or_404(subject_id)
    data = request.get_json()
    changes = []

    # ── name ──────────────────────────────────────────────────────────
    if 'name' in data:
        name = data['name'].strip()
        if not name:
            return jsonify({"error": "Subject name cannot be empty"}), 400
        if len(name) > 200:
            return jsonify({"error": "Subject name must be 200 characters or fewer"}), 400
        if name != subject.name:
            existing = Subject.query.filter(Subject.name == name, Subject.id != subject_id).first()
            if existing:
                return jsonify({"error": "A subject with this name already exists"}), 409
            changes.append(f"name: {subject.name} → {name}")
            subject.name = name

    # ── subject_code ──────────────────────────────────────────────────
    if 'subject_code' in data:
        code = data['subject_code'].strip().upper() if data['subject_code'] else None
        if code:
            if len(code) > 20:
                return jsonify({"error": "Subject code must be 20 characters or fewer"}), 400
            allowed_chars = set('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_')
            if not all(ch in allowed_chars for ch in code):
                return jsonify({"error": "Subject code may only contain letters, digits, hyphens, and underscores"}), 400
            duplicate = Subject.query.filter(Subject.subject_code == code, Subject.id != subject_id).first()
            if duplicate:
                return jsonify({"error": f"Subject code '{code}' is already in use"}), 409
        changes.append(f"subject_code → {code}")
        subject.subject_code = code

    # ── internal_subject_no ───────────────────────────────────────────
    if 'internal_subject_no' in data:
        subject.internal_subject_no = data['internal_subject_no'].strip() or None
        changes.append("internal_subject_no updated")

    # ── description ───────────────────────────────────────────────────
    if 'description' in data:
        subject.description = data['description'].strip() or None
        changes.append("description updated")

    # ── units ─────────────────────────────────────────────────────────
    if 'units' in data:
        units = data['units']
        if units is not None:
            try:
                units = int(units)
                if units < 1 or units > 12:
                    return jsonify({"error": "Units must be between 1 and 12"}), 400
            except (ValueError, TypeError):
                return jsonify({"error": "Units must be a valid integer"}), 400
        subject.units = units
        changes.append(f"units → {units}")

    # ── year_level ────────────────────────────────────────────────────
    if 'year_level' in data:
        year_level = data['year_level']
        if year_level is not None:
            try:
                year_level = int(year_level)
                if year_level < 1 or year_level > 6:
                    return jsonify({"error": "Year level must be between 1 and 6"}), 400
            except (ValueError, TypeError):
                return jsonify({"error": "Year level must be a valid integer"}), 400
        # The curriculum year of an existing subject is never changed through
        # this endpoint: legacy rows stay as they are until the official
        # curriculum is confirmed. Sending the current value back is fine.
        if year_level != subject.year_level:
            return jsonify({"error": "The curriculum year of an existing subject cannot be changed here."}), 400

    # ── subject_type ──────────────────────────────────────────────────
    if 'subject_type' in data:
        allowed_types = {'lab', 'lecture_lab', 'elective'}
        if data['subject_type'] not in allowed_types:
            return jsonify({"error": f"subject_type must be one of: {', '.join(sorted(allowed_types))}. Note: 'lecture' type is no longer accepted."}), 400
        subject.subject_type = data['subject_type']
        changes.append(f"subject_type → {data['subject_type']}")

    # ── department ────────────────────────────────────────────────────
    if 'department' in data:
        dept = data['department'].strip() or None
        if dept and len(dept) > 100:
            return jsonify({"error": "Department must be 100 characters or fewer"}), 400
        subject.department = dept
        changes.append(f"department → {dept}")

    db.session.commit()

    log_admin_action(
        admin.id,
        "SUBJECT_UPDATED",
        f"Updated subject: {subject.name} — {', '.join(changes) if changes else 'no changes'}",
        target_id=subject_id,
    )

    return jsonify({
        "message": "Subject updated successfully",
        "subject": {
            "id":                  subject.id,
            "name":                subject.name,
            "description":         subject.description,
            "subject_code":        subject.subject_code,
            "internal_subject_no": subject.internal_subject_no,
            "units":               subject.units,
            "department":          subject.department,
            "year_level":          subject.year_level,
            "subject_type":        subject.subject_type,
        }
    }), 200

# ===== ADMIN BLOCK ROUTES =====
@app.route('/api/admin/sections-list', methods=['GET'])
@admin_required
def admin_get_sections_list(admin):
    """Get all sections as the primary organizational unit (replaces blocks)"""
    sections = SubjectSection.query.filter_by(is_active=True).all()
    result = []
    for s in sections:
        subject = Subject.query.get(s.subject_id)
        student_count = IrregularEnrollment.query.filter_by(section_id=s.id).count()

        # Get instructor for this section
        assignment = TeacherAssignment.query.filter_by(section_id=s.id).first()
        instructor = User.query.get(assignment.instructor_id) if assignment else None

        result.append({
            "id": s.id,
            "section_no": s.section_no,
            "section_code": s.section_no,  # alias for frontend compat
            "name": s.section_no,
            "subject_id": s.subject_id,
            "subject_name": subject.name if subject else None,
            "subject_code": subject.subject_code if subject else None,
            "schedule": s.schedule,
            "room": s.room,
            "semester": s.semester,
            "academic_year": s.academic_year,
            "student_count": student_count,
            "capacity": s.capacity,
            "instructor": (instructor.full_name or instructor.username) if instructor else None,
            "is_active": s.is_active,
            "created_at": s.created_at.isoformat()
        })
    return jsonify(result), 200

@app.route('/api/admin/sections/<int:section_id>/students', methods=['GET'])
@jwt_required()
def get_section_students(section_id):
    token_user_id = int(get_jwt_identity())
    token_user = User.query.get(token_user_id)
    if not is_instructor_or_admin(token_user):
        return jsonify({"error": "Unauthorized"}), 403

    enrollments = IrregularEnrollment.query.filter_by(section_id=section_id).all()
    student_ids = [e.student_id for e in enrollments]

    students = User.query.filter(
        User.id.in_(student_ids),
        User.role == 'student'
    ).all() if student_ids else []

    return jsonify([{
        "id": s.id,
        "username": s.username,
        "full_name": s.full_name or s.username,
        "email": s.email,
        "xp": s.xp,
        "level": s.level,
        "is_active": s.is_active
    } for s in students]), 200

@app.route('/api/admin/instructor-assignments', methods=['POST'])
@admin_required
def admin_create_instructor_assignment(admin):
    """Admin assigns an instructor to teach a subject in a section (class code)"""
    data = request.get_json()

    required = ['instructor_id', 'subject_id', 'section_id']
    if not all(k in data for k in required):
        return jsonify({"error": "Missing required fields: instructor_id, subject_id, section_id"}), 400

    instructor_id = data['instructor_id']
    subject_id    = data['subject_id']
    section_id    = data['section_id']

    instructor = User.query.get(instructor_id)
    if not instructor or instructor.role != 'instructor':
        return jsonify({"error": "Invalid instructor ID"}), 400

    subject = Subject.query.get(subject_id)
    if not subject:
        return jsonify({"error": "Invalid subject ID"}), 400
    if subject_out_of_scope(subject):
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    section = SubjectSection.query.get(section_id)
    if not section:
        return jsonify({"error": "Invalid section_id — Class Code not found"}), 400

    existing = TeacherAssignment.query.filter_by(
        instructor_id=instructor_id,
        subject_id=subject_id,
        section_id=section_id
    ).first()
    if existing:
        return jsonify({"error": "Assignment already exists"}), 409

    # one instructor per class code. the check above
    # only caught the exact same instructor being assigned twice; this is
    # the actual rule: this subject+section combo can only ever have ONE
    # instructor. if someone else is already on it, the admin has to
    # unassign them first — no silent double-booking.
    taken_by = TeacherAssignment.query.filter_by(
        subject_id=subject_id,
        section_id=section_id
    ).first()
    if taken_by:
        current_instructor = User.query.get(taken_by.instructor_id)
        current_name = current_instructor.username if current_instructor else 'another instructor'
        return jsonify({
            "error": f"This class code already has an instructor ({current_name}). "
                     f"Remove them first before assigning someone new."
        }), 409

    assignment = TeacherAssignment(
        instructor_id=instructor_id,
        subject_id=subject_id,
        section_id=section_id
    )
    db.session.add(assignment)
    db.session.commit()

    section_label = section.section_no  # section is already fetched above
    log_admin_action(admin.id, "INSTRUCTOR_ASSIGNED",
        f"Instructor {instructor.username} assigned to teach {subject.name} in section {section_label}")

    return jsonify({
        "message": "Instructor assigned successfully",
        "assignment": {
            "id": assignment.id,
            "instructor": instructor.username,
            "subject": subject.name,
            "section": section_label
        }
    }), 201

@app.route('/api/admin/instructor-assignments/<int:assignment_id>', methods=['PUT'])
@admin_required
def admin_update_instructor_assignment(admin, assignment_id):
    """Update an instructor assignment"""
    assignment = TeacherAssignment.query.get_or_404(assignment_id)
    data = request.get_json()

    if not all(k in data for k in ['instructor_id', 'subject_id', 'section_id']):
        return jsonify({"error": "Missing required fields: instructor_id, subject_id, section_id"}), 400

    instructor_id = data['instructor_id']
    subject_id    = data['subject_id']
    section_id    = data['section_id']

    duplicate = TeacherAssignment.query.filter(
        TeacherAssignment.instructor_id == instructor_id,
        TeacherAssignment.subject_id == subject_id,
        TeacherAssignment.section_id == section_id,
        TeacherAssignment.id != assignment_id
    ).first()
    if duplicate:
        return jsonify({"error": "This assignment already exists"}), 409

    # same one-instructor-per-class-code rule as the create route.
    # excluding this assignment's own id — editing an assignment shouldn't
    # conflict with itself.
    taken_by = TeacherAssignment.query.filter(
        TeacherAssignment.subject_id == subject_id,
        TeacherAssignment.section_id == section_id,
        TeacherAssignment.id != assignment_id
    ).first()
    if taken_by:
        current_instructor = User.query.get(taken_by.instructor_id)
        current_name = current_instructor.username if current_instructor else 'another instructor'
        return jsonify({
            "error": f"This class code already has an instructor ({current_name}). "
                     f"Remove them first before assigning someone new."
        }), 409

    instructor = User.query.get(instructor_id)
    if not instructor or instructor.role != 'instructor':
        return jsonify({"error": "Invalid instructor ID"}), 400

    subject = Subject.query.get(subject_id)
    if not subject:
        return jsonify({"error": "Invalid subject ID"}), 400
    unchanged_target = (subject_id == assignment.subject_id and section_id == assignment.section_id)
    if subject_out_of_scope(subject) and not unchanged_target:
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    section = SubjectSection.query.get(section_id)
    if not section:
        return jsonify({"error": "Invalid section_id — Class Code not found"}), 400

    old_instructor = User.query.get(assignment.instructor_id)
    old_subject = Subject.query.get(assignment.subject_id)
    old_section = SubjectSection.query.get(assignment.section_id) if assignment.section_id else None
    old_section_label = old_section.section_no if old_section else 'No Section'

    assignment.instructor_id = instructor_id
    assignment.subject_id = subject_id
    assignment.section_id = section_id
    db.session.commit()

    new_section = SubjectSection.query.get(section_id) if section_id else None
    new_section_label = new_section.section_no if new_section else 'No Section'

    log_admin_action(admin.id, "INSTRUCTOR_ASSIGNMENT_UPDATED",
        f"Updated: {old_instructor.username} teaching {old_subject.name} in {old_section_label} → "
        f"{instructor.username} teaching {subject.name} in {new_section_label}")

    return jsonify({
        "message": "Assignment updated successfully",
        "assignment": {
            "id": assignment.id,
            "instructor": instructor.username,
            "subject": subject.name,
            "section": new_section_label
        }
    }), 200


@app.route('/api/admin/instructor-assignments', methods=['GET'])
@admin_required
def admin_get_instructor_assignments(admin):
    """Get all instructor assignments (with optional filters)"""
    instructor_id = request.args.get('instructor_id', type=int)
    subject_id = request.args.get('subject_id', type=int)
    section_id = request.args.get('section_id', type=int)

    query = TeacherAssignment.query

    if instructor_id:
        query = query.filter_by(instructor_id=instructor_id)
    if subject_id:
        query = query.filter_by(subject_id=subject_id)
    if section_id:
        query = query.filter_by(section_id=section_id)

    assignments = query.all()

    result = []
    for a in assignments:
        result.append({
            "id": a.id,
            "instructor": {
                "id": a.instructor.id,
                "username": a.instructor.username
            } if a.instructor else None,
            "subject": {
                "id": a.subject.id,
                "name": a.subject.name
            } if a.subject else None,
            "section": {
                "id": a.section.id,
                "section_no": a.section.section_no,
                "schedule": a.section.schedule,
                "room": a.section.room,
            } if a.section else None,
        })

    return jsonify(result), 200

@app.route('/api/admin/instructor-assignments/<int:assignment_id>', methods=['DELETE'])
@admin_required
def admin_delete_instructor_assignment(admin, assignment_id):
    """Remove an instructor assignment"""
    assignment = TeacherAssignment.query.get_or_404(assignment_id)

    # Get details for logging before deletion
    instructor = User.query.get(assignment.instructor_id)
    subject = Subject.query.get(assignment.subject_id)
    section = SubjectSection.query.get(assignment.section_id) if assignment.section_id else None
    section_label = section.section_no if section else 'No Section'

    db.session.delete(assignment)
    db.session.commit()

    log_admin_action(admin.id, "INSTRUCTOR_UNASSIGNED",
        f"Removed assignment: {instructor.username} teaching {subject.name} in section {section_label}")

    return jsonify({"message": "Assignment removed"}), 200

# ── Seed IT subjects (one-time, administrator only) ──────────────────────
@app.route('/api/admin/seed-subjects', methods=['POST'])
@admin_required
def admin_seed_subjects(admin):
    result = seed_it_subjects()
    log_admin_action(
        admin.id, 'SUBJECTS_SEEDED',
        f"Seeded {result['seeded']} IT subjects, {result['skipped']} already existed, "
        f"{result['out_of_scope']} not seeded (not first-year curriculum)."
    )
    return jsonify({
        "message": f"Seeded {result['seeded']} subjects. {result['skipped']} already existed.",
        "details": result
    }), 200

# ============================================================
# PASTE THIS BLOCK INTO app.py
#
# Add these imports at the top of app.py if not already present:
#   import unicodedata, re, base64, secrets, string, csv, io
#   (all are stdlib — no pip installs needed)
#
# Add these two SQLAlchemy models anywhere in the MODELS section:
#
#   class SubjectSection(db.Model):
#       __tablename__ = 'subject_sections'
#       id            = db.Column(db.Integer, primary_key=True)
#       section_no    = db.Column(db.String(20),  nullable=False)
#       subject_id    = db.Column(db.Integer,     db.ForeignKey('subjects.id'), nullable=False)
#       block_id      = db.Column(db.Integer,     db.ForeignKey('blocks.id'),   nullable=True)
#       schedule      = db.Column(db.String(100), nullable=True)
#       room          = db.Column(db.String(50),  nullable=True)
#       capacity      = db.Column(db.Integer,     nullable=False, default=40)
#       current_count = db.Column(db.Integer,     nullable=False, default=0)
#       semester      = db.Column(db.String(50),  nullable=True)
#       academic_year = db.Column(db.String(9),   nullable=True)
#       is_active     = db.Column(db.Boolean,     nullable=False, default=True)
#       created_at    = db.Column(db.DateTime,    default=datetime.utcnow)
#
#   class IrregularEnrollment(db.Model):
#       __tablename__ = 'irregular_enrollments'
#       id          = db.Column(db.Integer, primary_key=True)
#       student_id  = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
#       section_id  = db.Column(db.Integer, db.ForeignKey('subject_sections.id'), nullable=False)
#       enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
#       __table_args__ = (
#           db.UniqueConstraint('student_id', 'section_id', name='unique_irregular_enrollment'),
#       )
#
# ============================================================


# ── Email-generation helpers ────────────────────────────────────────────

_SUFFIXES = frozenset({"jr", "sr", "i", "ii", "iii", "iv", "v"})


def _clean_name_part(token: str) -> str:
    """
    Normalise one name token for email use:
      - NFD decompose  →  strip combining accents  (ñ→n, é→e)
      - lowercase
      - remove every non-alpha character
        (hyphens, apostrophes, spaces already split out)
    """
    nfd = unicodedata.normalize("NFD", token)
    ascii_only = nfd.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z]", "", ascii_only.lower())


def _build_email_local(firstname: str, middlename: str, lastname: str) -> str:
    """
    Build the local part of the institutional email address.
    Rules (from spec):
      - Full first name (can be compound, e.g. "Paul Christian Caleb")
      - Full middle name (not just initial); skip if blank
      - Full last name; hyphens removed by _clean_name_part
      - Skip suffix tokens (Jr., I., etc.)
    Returns dot-joined parts, e.g. "paul.christian.caleb.rejano"
    """
    parts = []

    for token in firstname.strip().split():
        clean = token.rstrip(".")
        if clean.lower() not in _SUFFIXES:
            slug = _clean_name_part(token)
            if slug:
                parts.append(slug)

    if middlename and middlename.strip():
        for token in middlename.strip().split():
            clean = token.rstrip(".")
            if clean.lower() not in _SUFFIXES:
                slug = _clean_name_part(token)
                if slug:
                    parts.append(slug)

    for token in lastname.strip().split():
        clean = token.rstrip(".")
        if clean.lower() not in _SUFFIXES:
            slug = _clean_name_part(token)
            if slug:
                parts.append(slug)

    return ".".join(parts)


def _generate_enrollment_email(
    firstname: str,
    middlename: str,
    lastname: str,
    suffix: str,
    student_id_raw: str,
    existing_emails: set,
) -> str:
    """
    Return a unique institutional email (ALLOWED_EMAIL_DOMAIN).
    Duplicate → append numeric part of student_id, e.g. paul.rejano.202400100
    """
    local = _build_email_local(firstname, middlename, lastname)
    email = f"{local}@{ALLOWED_EMAIL_DOMAIN}"

    if email not in existing_emails:
        return email

    # Collision — append digits from student_id
    id_digits = re.sub(r"[^0-9]", "", student_id_raw)
    email = f"{local}.{id_digits}@{ALLOWED_EMAIL_DOMAIN}"
    return email  # caller adds to set


def _generate_secure_password(length: int = 12) -> str:
    """
    Cryptographically secure 12-char password.
    Guarantees at least one uppercase, one digit, one symbol.
    """
    pool = string.ascii_letters + string.digits + "!@#$%&*"
    while True:
        pwd = "".join(secrets.choice(pool) for _ in range(length))
        if (
            any(c.isupper() for c in pwd)
            and any(c.islower() for c in pwd)
            and any(c.isdigit() for c in pwd)
            and any(c in "!@#$%&*" for c in pwd)
        ):
            return pwd


# ── Route ───────────────────────────────────────────────────────────────

@app.route("/api/admin/enrollment/bulk-upload", methods=["POST"])
@admin_required
def admin_bulk_enrollment_upload(admin):
    """
    Master enrollment CSV upload — handles regular AND irregular students
    in a single file.

    CSV columns (header row required, order does NOT matter):
        student_id, firstname, middlename, lastname, suffix,
        student_type, section_no
    (middlename and suffix are optional. Extra columns, including a legacy
    year_level column from older files, are accepted and ignored.)

    Regular row example (one section — their fixed cohort's class code):
        2024-00001,Juan,Santos,Dela Cruz,,regular,29022

    Irregular row example (one row per section — same student_id repeats):
        2024-00100,Pedro,Jose,Reyes,,irregular,29144

    Returns JSON:
    {
        "summary":        { total_rows, created, enrolled, skipped, errors },
        "results":        [ { row, student_id, status, reason? } … ],
        "credential_csv": "<base64-encoded CSV>",
        "errors":         [ "human-readable error string" … ]
    }

    HTTP 200 on full success, 207 if any row had errors.
    """
    # ── 1. File validation ────────────────────────────────────────────────
    if "file" not in request.files:
        return jsonify({"error": "No file provided — send field name 'file'"}), 400

    f = request.files["file"]
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only .csv files are accepted"}), 400

    raw = f.read(5 * 1024 * 1024 + 1)
    if len(raw) > 5 * 1024 * 1024:
        return jsonify({"error": "File exceeds 5 MB limit"}), 413

    try:
        text   = raw.decode("utf-8-sig")          # handles Excel BOM
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
    except Exception as exc:
        return jsonify({"error": f"CSV parse error: {exc}"}), 400

    if not rows:
        return jsonify({"error": "CSV file is empty"}), 400
    if len(rows) > 2000:
        return jsonify({"error": "Maximum 2000 rows per upload"}), 400

    # Normalise header names (strip whitespace, lowercase)
    rows = [{k.strip().lower(): (v or "").strip() for k, v in row.items() if k is not None} for row in rows]

    # block_code and subject_code used to be required here, but neither
    # is ever actually read anywhere in this function — a class code
    # (section_no) already knows its own subject internally, so specifying
    # it again here was always redundant. requiring 2 columns that do
    # nothing just confused anyone building the CSV.
    # middlename/suffix are optional (read with .get() below), and so is any
    # legacy year_level column: it is never required and its value is ignored.
    required_cols = {
        "student_id", "firstname", "lastname", "student_type", "section_no",
    }
    missing_cols = required_cols - set(rows[0].keys())
    if missing_cols:
        return jsonify({
            "error":   "Missing CSV columns",
            "missing": sorted(missing_cols),
        }), 400

    # ── 2. Pre-load lookup caches (avoids N+1 queries) ────────────────────
    # blocks removed — no longer used

    # subject_sections: section_no (str) → SubjectSection object
    sections_by_no: dict = {
        str(s.section_no).strip(): s
        for s in SubjectSection.query.filter_by(is_active=True).all()
    }
    # class codes that belong to out-of-scope subjects: found, but not enrollable
    out_of_scope_nos = {
        no for no, s in sections_by_no.items()
        if subject_out_of_scope(Subject.query.get(s.subject_id))
    }

    # existing emails in DB (for duplicate-email guard)
    existing_emails: set = {
        (row[0] or '').strip().lower() for row in db.session.query(User.email).all()
    }

    # existing usernames (username = student_id without hyphens, e.g. "2024-00001")
    existing_usernames: set = {
        row[0] for row in db.session.query(User.username).all()
    }

    # student_id string → User (already-created users, re-populated per flush)
    users_by_sid: dict = {
        u.username: u
        for u in User.query.filter_by(role="student").all()
    }

    # ── 3. Group rows by student_id for deduplication ─────────────────────
    # irregular students can have multiple rows (one per section)
    regular_rows:   list  = []
    irregular_dict: dict  = {}   # sid → [row, …]

    row_errors: list = []   # human-readable strings for the response

    for idx, row in enumerate(rows, start=2):
        stype = row.get("student_type", "").strip().lower()
        sid   = row.get("student_id", "").strip()

        if not sid:
            row_errors.append(f"Row {idx}: student_id is empty — skipped")
            continue
        if stype == "regular":
            regular_rows.append((idx, row))
        elif stype == "irregular":
            irregular_dict.setdefault(sid, []).append((idx, row))
        else:
            row_errors.append(
                f"Row {idx} (student_id={sid}): unknown student_type '{stype}' — skipped"
            )

    # ── 4. Processing helpers ─────────────────────────────────────────────

    results:         list = []
    credential_list: list = []   # dicts for the output CSV
    created_count   = 0
    enrolled_count  = 0
    skipped_count   = 0

    def _get_or_create_user(idx, row) -> "tuple[User|None, str|None, bool]":
        """
        Return (user, plain_password, is_new).
        plain_password is None when the user already existed.
        Flushes the new user to DB so its .id is available immediately.
        """
        nonlocal created_count, existing_emails, existing_usernames

        sid = row["student_id"].strip()

        # --- already in DB from a previous upload -----------------------
        if sid in users_by_sid:
            return users_by_sid[sid], None, False

        # --- basic field validation ------------------------------------
        fn = row.get("firstname",  "").strip()
        ln = row.get("lastname",   "").strip()
        mn = row.get("middlename", "").strip()
        sx = row.get("suffix",     "").strip()

        if not fn or not ln:
            row_errors.append(f"Row {idx} (student_id={sid}): firstname/lastname missing — skipped")
            return None, None, False

        # --- username = student_id (matches existing CSV convention) ---
        if sid in existing_usernames:
            # user exists but wasn't in our cache — refresh & return
            user = User.query.filter_by(username=sid).first()
            if user:
                users_by_sid[sid] = user
                return user, None, False
            # shouldn't happen, but guard
            row_errors.append(f"Row {idx} (student_id={sid}): username conflict — skipped")
            return None, None, False

        # --- generated sign-in identifier: <student_id>@STUDENT_EMAIL_DOMAIN ---
        if not valid_student_id(sid):
            row_errors.append(f"Row {idx} (student_id={sid}): student ID must not contain spaces or '@' — skipped")
            return None, None, False
        email = generated_student_email(sid)
        if email in existing_emails:
            row_errors.append(
                f"Row {idx} (student_id={sid}): identifier '{email}' already belongs to another account — skipped"
            )
            return None, None, False

        # --- create user -----------------------------------------------
        plain_pwd = _generate_secure_password()

        full_name = " ".join(filter(None, [fn, mn, ln, sx]))

        new_user = User(
            username      = sid,
            email         = email,
            password_hash = generate_password_hash(plain_pwd),
            must_change_password = True,
            role          = "student",
            full_name     = full_name,
            is_active     = True,
            xp            = 0,
            level         = 1,
            created_at    = datetime.utcnow(),
        )
        db.session.add(new_user)
        db.session.flush()   # populates new_user.id without committing

        # Update in-memory caches so subsequent rows see this user
        existing_emails.add(email)
        existing_usernames.add(sid)
        users_by_sid[sid] = new_user

        created_count += 1
        credential_list.append({
            "student_id":       sid,
            "full_name":        full_name,
            "email":            email,
            "temp_password":    plain_pwd,
            "student_type":     row.get("student_type", "").strip().lower(),
            "class_codes": "",   # filled in by caller
        })

        return new_user, plain_pwd, True

    # ── 5. Process REGULAR students ───────────────────────────────────────
    for idx, row in regular_rows:
        sid        = row["student_id"].strip()
        section_no = row.get("section_no", "").strip()

        if not section_no:
            skipped_count += 1
            results.append({"row": idx, "student_id": sid, "status": "error",
                             "reason": "section_no missing"})
            row_errors.append(f"Row {idx} (student_id={sid}): section_no is empty — skipped")
            continue

        if section_no in out_of_scope_nos:
            skipped_count += 1
            results.append({"row": idx, "student_id": sid, "status": "error",
                             "reason": f"section '{section_no}' belongs to a subject outside the first-year scope"})
            row_errors.append(f"Row {idx} (student_id={sid}): section '{section_no}' is outside the supported first-year subjects — skipped")
            continue
        section = sections_by_no.get(section_no)
        if not section:
            skipped_count += 1
            results.append({"row": idx, "student_id": sid, "status": "error",
                             "reason": f"section '{section_no}' not found"})
            row_errors.append(f"Row {idx} (student_id={sid}): section '{section_no}' not found — skipped")
            continue

        user, plain_pwd, is_new = _get_or_create_user(idx, row)
        if user is None:
            skipped_count += 1
            continue

        already = IrregularEnrollment.query.filter_by(
            student_id=user.id, section_id=section.id
        ).first()
        if already:
            skipped_count += 1
            results.append({"row": idx, "student_id": sid, "status": "skipped",
                             "reason": "already enrolled"})
            continue

        db.session.add(IrregularEnrollment(
            student_id=user.id,
            section_id=section.id,
            enrolled_at=datetime.utcnow(),
        ))
        section.current_count = (section.current_count or 0) + 1
        enrolled_count += 1

        if is_new:
            credential_list[-1]["class_codes"] = section_no

        results.append({"row": idx, "student_id": sid,
                         "status": "created" if is_new else "enrolled",
                         "section": section_no})

    # ── 6. Process IRREGULAR students ─────────────────────────────────────
    # Irregular students are assigned to specific CLASS CODES (section_no, e.g., "29144").
    # Each row for an irregular student maps to one SubjectSection.section_no in the DB.
    # A single irregular student can have multiple rows — one per class code they attend.
    for sid, sid_rows in irregular_dict.items():
        # Use the FIRST row to create / fetch the user
        first_idx, first_row = sid_rows[0]
        user, plain_pwd, is_new = _get_or_create_user(first_idx, first_row)

        if user is None:
            skipped_count += len(sid_rows)
            continue

        sections_enrolled = []

        for idx, row in sid_rows:
            section_no = row["section_no"].strip()

            if not section_no:
                skipped_count += 1
                results.append({"row": idx, "student_id": sid, "status": "error",
                                 "reason": "section_no (Class Code, e.g. 29144) missing for irregular student"})
                row_errors.append(
                    f"Row {idx} (student_id={sid}): section_no (Class Code, e.g. 29144) is empty — skipped"
                )
                continue

            if section_no in out_of_scope_nos:
                skipped_count += 1
                results.append({"row": idx, "student_id": sid, "status": "error",
                                 "reason": f"section '{section_no}' belongs to a subject outside the first-year scope"})
                row_errors.append(f"Row {idx} (student_id={sid}): section '{section_no}' is outside the supported first-year subjects — skipped")
                continue
            section = sections_by_no.get(section_no)
            if not section:
                skipped_count += 1
                results.append({"row": idx, "student_id": sid, "status": "error",
                                 "reason": f"section '{section_no}' not found or inactive"})
                row_errors.append(
                    f"Row {idx} (student_id={sid}): section '{section_no}' not found — skipped"
                )
                continue

            # Idempotency — skip if already enrolled in this section
            already = IrregularEnrollment.query.filter_by(
                student_id = user.id,
                section_id = section.id,
            ).first()
            if already:
                skipped_count += 1
                results.append({"row": idx, "student_id": sid, "status": "skipped",
                                 "reason": f"already enrolled in section {section_no}"})
                continue

            enrollment = IrregularEnrollment(
                student_id  = user.id,
                section_id  = section.id,
                enrolled_at = datetime.utcnow(),
            )
            db.session.add(enrollment)

            # Bump section's current_count
            section.current_count = (section.current_count or 0) + 1

            enrolled_count    += 1
            sections_enrolled.append(section_no)

            results.append({
                "row":        idx,
                "student_id": sid,
                "status":     "created" if (is_new and idx == first_idx) else "enrolled",
                "section":    section_no,
            })

        # Patch credential list entry with section list
        if is_new and sections_enrolled:
            credential_list[-1]["class_codes"] = ";".join(sections_enrolled)

    # ── 7. Commit everything ───────────────────────────────────────────────
    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        return jsonify({
            "error":  "Database commit failed — all changes rolled back",
            "detail": str(exc),
        }), 500

    # ── 8. Build base64 credential CSV ────────────────────────────────────
    cred_buf = io.StringIO()
    cred_writer = csv.writer(cred_buf)
    cred_writer.writerow([
        "student_id", "full_name", "email",
        "temporary_password", "student_type",
        "class_codes", "must_change_password",
    ])
    for c in credential_list:
        cred_writer.writerow([
            c["student_id"],
            c["full_name"],
            c["email"],
            c["temp_password"],
            c["student_type"],
            c["class_codes"],
            "YES",
        ])
    cred_b64 = base64.b64encode(
        cred_buf.getvalue().encode("utf-8")
    ).decode("utf-8")

    # ── 9. Audit log ──────────────────────────────────────────────────────
    log_admin_action(
        admin.id,
        "BULK_ENROLLMENT_UPLOAD",
        (
            f"Enrollment upload: {len(rows)} rows processed — "
            f"{created_count} accounts created, "
            f"{enrolled_count} enrollments added, "
            f"{skipped_count} skipped, "
            f"{len(row_errors)} errors."
        ),
    )

    # ── 10. Response ──────────────────────────────────────────────────────
    error_count = len(row_errors)
    return jsonify({
        "summary": {
            "total_rows": len(rows),
            "created":    created_count,
            "enrolled":   enrolled_count,
            "skipped":    skipped_count,
            "errors":     error_count,
        },
        "results":        results,
        "errors":         row_errors,
        "credential_csv": cred_b64,
    }), (207 if error_count else 200)


# ── Bulk CSV user upload ────────────────────────────────────────────────
@app.route('/api/admin/users/bulk-upload', methods=['POST'])
@admin_required
def admin_bulk_upload_users(admin):
    """
    Accepts a CSV file and bulk-creates student or instructor accounts.

    Form fields:
        role_type : 'student' or 'instructor'
        file      : the CSV file

    Student CSV columns  : student_id, firstname, lastname
    (a legacy year_level column is accepted and ignored)
    Instructor CSV columns: employee_id, firstname, lastname, department

    Returns a summary + base64-encoded credential CSV for download.
    """
    import secrets, string, base64

    role_type = request.form.get('role_type', 'student')
    if role_type not in ('student', 'instructor'):
        return jsonify({"error": "role_type must be 'student' or 'instructor'"}), 400

    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files['file']
    if not file.filename.lower().endswith('.csv'):
        return jsonify({"error": "Only .csv files are accepted"}), 400

    raw = file.read(5 * 1024 * 1024)
    if len(raw) >= 5 * 1024 * 1024:
        return jsonify({"error": "File exceeds 5 MB limit"}), 413

    # Parse CSV
    try:
        text   = raw.decode('utf-8-sig')   # handle Excel BOM
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
    except Exception as e:
        return jsonify({"error": f"CSV parse error: {str(e)}"}), 400

    if not rows:
        return jsonify({"error": "CSV file is empty"}), 400
    if len(rows) > 1500:
        return jsonify({"error": "Maximum 1500 rows per upload"}), 400

    # Validate required columns
    headers = {k.strip().lower() for k in rows[0].keys()}
    required = (
        {'student_id', 'firstname', 'lastname'}
        if role_type == 'student'
        else {'employee_id', 'firstname', 'lastname', 'department'}
    )
    missing = required - headers
    if missing:
        return jsonify({"error": "Missing columns", "missing": sorted(missing)}), 400

    def _gen_password():
        chars = (
            secrets.choice(string.ascii_uppercase) +
            secrets.choice(string.ascii_uppercase) +
            secrets.choice(string.digits) +
            secrets.choice(string.digits) +
            secrets.choice('!@#$%') +
            ''.join(secrets.choice(string.ascii_lowercase) for _ in range(6))
        )
        lst = list(chars)
        secrets.SystemRandom().shuffle(lst)
        return ''.join(lst)

    results, created_users, errors = [], [], []

    try:
        for row_num, row in enumerate(rows, start=2):
            row = {k.strip().lower(): v.strip() for k, v in row.items()}

            row_errors = []
            fn = row.get('firstname', '')
            ln = row.get('lastname', '')
            if not fn or len(fn) > 50:
                row_errors.append('firstname missing or too long')
            if not ln or len(ln) > 50:
                row_errors.append('lastname missing or too long')

            if role_type == 'student':
                sid = row.get('student_id', '')
                if not sid or not sid.isdigit() or not (7 <= len(sid) <= 10):
                    row_errors.append('student_id must be 7–10 digits')
            else:
                eid = row.get('employee_id', '')
                if not eid or len(eid) > 20:
                    row_errors.append('employee_id missing or too long')

            if row_errors:
                errors.append({'row': row_num, 'errors': row_errors})
                results.append({'row': row_num, 'status': 'error', 'errors': row_errors})
                continue

            # Build email and username
            if role_type == 'student':
                email    = generated_student_email(row['student_id'])
                username = row['student_id']
            else:
                # staff addresses are never invented: an explicit, valid email is required
                email = normalize_email(row.get('email'))
                if not email_domain_allowed(email) or email.endswith('@' + STUDENT_EMAIL_DOMAIN):
                    msg = ['email column must hold a valid staff email address']
                    errors.append({'row': row_num, 'errors': msg})
                    results.append({'row': row_num, 'status': 'error', 'errors': msg})
                    continue
                username = row.get('employee_id', email.split('@')[0])

            if (HEAD_ADMIN_EMAIL and email.lower() == HEAD_ADMIN_EMAIL) or User.query.filter(db.func.lower(User.email) == email.lower()).first():
                results.append({
                    'row': row_num, 'status': 'skipped',
                    'reason': 'email_exists', 'email': email
                })
                continue

            temp_pwd = _gen_password()
            new_user = User(
                username      = username,
                email         = email,
                password_hash = generate_password_hash(temp_pwd),
                must_change_password = True,
                role          = 'instructor' if role_type == 'instructor' else 'student',
                is_active     = True,
                xp            = 0,
                level         = 1
            )
            db.session.add(new_user)
            db.session.flush()

            created_users.append({
                'row':           row_num,
                'username':      username,
                'email':         email,
                'temp_password': temp_pwd,
                'status':        'created'
            })
            results.append({'row': row_num, 'status': 'created', 'email': email})

        db.session.commit()

    except Exception as e:
        db.session.rollback()
        return jsonify({
            "error":   "Transaction rolled back",
            "detail":  str(e),
            "results": results
        }), 500

    # Build credential CSV for download (base64 encoded)
    cred_buf    = io.StringIO()
    cred_writer = csv.writer(cred_buf)
    id_col      = 'student_id' if role_type == 'student' else 'employee_id'
    cred_writer.writerow([id_col, 'email', 'temporary_password', 'must_change_password'])
    for u in created_users:
        cred_writer.writerow([u['username'], u['email'], u['temp_password'], 'YES'])
    cred_b64 = base64.b64encode(
        cred_buf.getvalue().encode('utf-8')
    ).decode('utf-8')

    log_admin_action(
        admin.id, 'BULK_USER_UPLOAD',
        f"Bulk upload ({role_type}): {len(created_users)} created, "
        f"{len(errors)} errors out of {len(rows)} rows."
    )

    status_code = 207 if errors else 200
    return jsonify({
        "summary": {
            "total_rows": len(rows),
            "created":    len(created_users),
            "skipped":    len(results) - len(created_users) - len(errors),
            "errors":     len(errors),
        },
        "results":        results,
        "credential_csv": cred_b64
    }), status_code


# ===== ADMIN SECTIONS ROUTES =====

@app.route('/api/admin/sections', methods=['GET'])
@admin_required
def admin_get_sections(admin):
    """Get all subject sections with enrollment counts and related info"""
    subject_id = request.args.get('subject_id', type=int)
    # block_id param ignored — blocks removed
    semester = request.args.get('semester', '')
    active_only = request.args.get('active_only', 'false').lower() == 'true'

    q = SubjectSection.query
    if subject_id:
        q = q.filter_by(subject_id=subject_id)
    # block_id filter removed
    if semester:
        q = q.filter_by(semester=semester)
    if active_only:
        q = q.filter_by(is_active=True)

    sections = q.order_by(SubjectSection.section_no).all()

    result = []
    for s in sections:
        subject = Subject.query.get(s.subject_id)
        enrolled = IrregularEnrollment.query.filter_by(section_id=s.id).count()

        result.append({
            "id":            s.id,
            "section_no":    s.section_no,
            "subject_id":    s.subject_id,
            "subject_name":  subject.name if subject else None,
            "subject_code":  subject.subject_code if subject else None,
            "schedule":      s.schedule,
            "room":          s.room,
            "capacity":      s.capacity,
            "current_count": enrolled,
            "semester":      s.semester,
            "academic_year": s.academic_year,
            "is_active":     s.is_active,
            "created_at":    s.created_at.isoformat(),
        })

    return jsonify(result), 200


@app.route('/api/admin/sections', methods=['POST'])
@admin_required
def admin_create_section(admin):
    """Create a new subject section"""
    data = request.get_json()

    required = ['section_no', 'subject_id']
    if not all(k in data for k in required):
        return jsonify({"error": "section_no and subject_id are required"}), 400

    section_no = str(data['section_no']).strip()
    if not section_no:
        return jsonify({"error": "section_no cannot be empty"}), 400

    subject = Subject.query.get(data['subject_id'])
    if not subject:
        return jsonify({"error": "Subject not found"}), 404
    if subject_out_of_scope(subject):
        return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    # Check global uniqueness (matches DB constraint)
    existing = SubjectSection.query.filter_by(section_no=section_no).first()
    if existing:
        return jsonify({"error": f"Section number '{section_no}' is already in use university-wide"}), 409

    capacity = data.get('capacity', 40)
    try:
        capacity = int(capacity)
        if capacity < 1 or capacity > 200:
            return jsonify({"error": "Capacity must be between 1 and 200"}), 400
    except (ValueError, TypeError):
        return jsonify({"error": "Capacity must be an integer"}), 400

    section = SubjectSection(
        section_no    = section_no,
        subject_id    = data['subject_id'],
        schedule      = data.get('schedule', '').strip() or None,
        room          = data.get('room', '').strip() or None,
        capacity      = capacity,
        current_count = 0,
        semester      = data.get('semester', '').strip() or None,
        academic_year = data.get('academic_year', '').strip() or None,
        is_active     = data.get('is_active', True),
    )
    db.session.add(section)
    db.session.commit()

    log_admin_action(admin.id, "SECTION_CREATED",
        f"Created section {section_no} for {subject.name}", target_id=section.id)

    return jsonify({
        "message":    "Section created successfully",
        "section_id": section.id,
        "section_no": section.section_no,
    }), 201


@app.route('/api/admin/sections/<int:section_id>', methods=['PUT'])
@admin_required
def admin_update_section(admin, section_id):
    """Update a subject section"""
    section = SubjectSection.query.get_or_404(section_id)
    data = request.get_json()
    changes = []

    # checked before anything is modified, so a refusal leaves no partial change:
    # a section may not be moved INTO, or reactivated under, an unapproved subject
    if 'subject_id' in data and data['subject_id'] != section.subject_id:
        if subject_out_of_scope(Subject.query.get(data['subject_id'])):
            return jsonify({"error": OUT_OF_SCOPE_MSG}), 400
    if data.get('is_active') and not section.is_active:
        if subject_out_of_scope(Subject.query.get(data.get('subject_id', section.subject_id))):
            return jsonify({"error": OUT_OF_SCOPE_MSG}), 400

    if 'section_no' in data:
        new_no = str(data['section_no']).strip()
        if new_no != section.section_no:
            changes.append(f"section_no: {section.section_no} → {new_no}")
            section.section_no = new_no

    if 'subject_id' in data:
        subject = Subject.query.get(data['subject_id'])
        if not subject:
            return jsonify({"error": "Subject not found"}), 404
        if data['subject_id'] != section.subject_id:
            changes.append(f"subject_id: {section.subject_id} → {data['subject_id']}")
            section.subject_id = data['subject_id']

    # block_id removed

    if 'schedule' in data:
        section.schedule = data['schedule'].strip() or None
        changes.append("schedule updated")

    if 'room' in data:
        section.room = data['room'].strip() or None
        changes.append("room updated")

    if 'capacity' in data:
        try:
            cap = int(data['capacity'])
            if cap < 1 or cap > 200:
                return jsonify({"error": "Capacity must be between 1 and 200"}), 400
            section.capacity = cap
            changes.append(f"capacity → {cap}")
        except (ValueError, TypeError):
            return jsonify({"error": "Capacity must be an integer"}), 400

    if 'semester' in data:
        section.semester = data['semester']
    if 'academic_year' in data:
        section.academic_year = data['academic_year']
    if 'is_active' in data:
        section.is_active = bool(data['is_active'])
        changes.append(f"is_active → {section.is_active}")

    db.session.commit()
    log_admin_action(admin.id, "SECTION_UPDATED",
        f"Updated section {section.section_no}: {', '.join(changes) or 'no changes'}",
        target_id=section_id)

    return jsonify({"message": "Section updated", "changes": changes}), 200


def _cascade_delete_section_content(section_id):
    """
    A module, quest or announcement belongs to one specific class code now
    (see get_lessons/get_class_problems/get_student_announcements) -- so
    deleting that class code must take its content with it, or the content
    just sits there orphaned forever, invisible but never cleaned up.

    - Lessons: deleted outright (their LessonFile rows cascade via the
      model's own relationship).
    - Problems: this section is removed from visible_to_sections; if that
      was the only section it was visible to, the quest (and its
      Submissions/HintReveals) is deleted too. A quest still shared with
      another section survives, just narrower.
    - Announcements: deleted outright (class_id is a straight section id,
      never shared across sections).

    Returns a small summary dict for the audit log / API response.
    """
    lessons = Lesson.query.filter_by(section_id=section_id).all()
    lessons_deleted = len(lessons)
    for lesson in lessons:
        db.session.delete(lesson)

    problems_deleted = 0
    problems = Problem.query.filter(Problem.visible_to_sections.isnot(None)).all()
    for p in problems:
        if section_id not in (p.visible_to_sections or []):
            continue
        remaining = [sid for sid in p.visible_to_sections if sid != section_id]
        if remaining:
            p.visible_to_sections = remaining
        else:
            Submission.query.filter_by(problem_id=p.id).delete()
            HintReveal.query.filter_by(problem_id=p.id).delete()
            db.session.delete(p)
            problems_deleted += 1

    announcements_deleted = Announcement.query.filter_by(class_id=section_id).delete()

    return {
        "lessons_deleted": lessons_deleted,
        "problems_deleted": problems_deleted,
        "announcements_deleted": announcements_deleted,
    }


@app.route('/api/admin/sections/<int:section_id>', methods=['DELETE'])
@admin_required
def admin_delete_section(admin, section_id):
    """Delete a section (only if no irregular enrollments exist)"""
    section = SubjectSection.query.get_or_404(section_id)

    enrolled = IrregularEnrollment.query.filter_by(section_id=section_id).count()
    if enrolled > 0:
        return jsonify({
            "error": f"Cannot delete — {enrolled} student(s) are enrolled in this section. Unenroll them first."
        }), 400

    assigned_instructors = TeacherAssignment.query.filter_by(section_id=section_id).count()
    if assigned_instructors > 0:
        return jsonify({
            "error": f"Cannot delete — {assigned_instructors} instructor assignment(s) reference this section. Remove those assignments first."
        }), 400

    section_no = section.section_no
    content = _cascade_delete_section_content(section_id)
    db.session.delete(section)
    db.session.commit()

    log_admin_action(admin.id, "SECTION_DELETED",
        f"Deleted section {section_no} (also removed {content['lessons_deleted']} module(s), "
        f"{content['problems_deleted']} quest(s), {content['announcements_deleted']} announcement(s))",
        target_id=section_id)
    return jsonify({"message": "Section deleted", **content}), 200


@app.route('/api/admin/sections/bulk-delete', methods=['DELETE'])
@admin_required
def admin_bulk_delete_sections(admin):
    """
    Deletes every EMPTY class code (section) in one action — for clearing
    out accumulated test data (duplicate uploads, old test runs) before a
    real demo/defense. Mirrors the single-section delete's safety rules:
    a section with enrolled students OR an instructor assignment is left
    alone and reported back as skipped, never force-deleted.
    """
    sections = SubjectSection.query.all()
    deleted = 0
    skipped = []

    for s in sections:
        enrolled = IrregularEnrollment.query.filter_by(section_id=s.id).count()
        if enrolled > 0:
            skipped.append({
                "section_no": s.section_no,
                "reason": f"{enrolled} student(s) enrolled",
            })
            continue
        # No students in this class code — safe to clear it out entirely,
        # including any leftover instructor assignment. Unlike enrollment
        # data, reassigning an instructor is a 2-click fix, so it doesn't
        # need to block a test-data reset the way real enrollment does.
        TeacherAssignment.query.filter_by(section_id=s.id).delete()
        _cascade_delete_section_content(s.id)
        db.session.delete(s)
        deleted += 1

    db.session.commit()
    log_admin_action(admin.id, "BULK_SECTIONS_DELETED",
        f"Deleted {deleted} empty class code(s), skipped {len(skipped)} with active enrollment/assignments.")

    return jsonify({
        "message": f"Deleted {deleted} class code(s)",
        "deleted": deleted,
        "skipped": skipped,
    }), 200


@app.route('/api/admin/sections/<int:section_id>/enrollments', methods=['GET'])
@admin_required
def admin_get_section_enrollments(admin, section_id):
    """Get all students enrolled in a specific section"""
    section = SubjectSection.query.get_or_404(section_id)

    enrollments = IrregularEnrollment.query.filter_by(section_id=section_id).all()
    students = []
    for e in enrollments:
        student = User.query.get(e.student_id)
        if student:
            students.append({
                "enrollment_id": e.id,
                "student_id":    student.id,
                "username":      student.username,
                "full_name":     student.full_name or student.username,
                "email":         student.email,
                "enrolled_at":   e.enrolled_at.isoformat(),
            })

    subject = Subject.query.get(section.subject_id)
    return jsonify({
        "section": {
            "id":         section.id,
            "section_no": section.section_no,
            "subject":    subject.name if subject else None,
            "schedule":   section.schedule,
            "room":       section.room,
            "capacity":   section.capacity,
        },
        "enrolled_count": len(students),
        "students":       students,
    }), 200


@app.route('/api/admin/sections/bulk-upload', methods=['POST'])
@admin_required
def admin_bulk_upload_sections(admin):
    """
    Bulk create sections from CSV.

    CSV columns:
        section_no, subject_code, schedule, room,
        capacity, semester, academic_year
    """
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400

    f = request.files['file']
    if not f.filename.lower().endswith('.csv'):
        return jsonify({"error": "Only .csv files accepted"}), 400

    raw = f.read(5 * 1024 * 1024 + 1)
    if len(raw) > 5 * 1024 * 1024:
        return jsonify({"error": "File exceeds 5 MB"}), 413

    try:
        text   = raw.decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
    except Exception as e:
        return jsonify({"error": f"CSV parse error: {e}"}), 400

    if not rows:
        return jsonify({"error": "CSV is empty"}), 400

    rows = [{k.strip().lower(): (v or '').strip() for k, v in row.items()} for row in rows]

    required_cols = {'section_no', 'subject_code'}
    missing = required_cols - set(rows[0].keys())
    if missing:
        return jsonify({"error": "Missing columns", "missing": sorted(missing)}), 400

    subjects_by_code = {s.subject_code.upper(): s for s in Subject.query.filter(Subject.subject_code != None).all()}
    blocks_by_code   = {}  # blocks removed

    results = []
    created = 0
    skipped = 0
    errors  = 0

    for idx, row in enumerate(rows, start=2):
        section_no   = row.get('section_no', '').strip()
        subject_code = row.get('subject_code', '').strip().upper()

        if not section_no or not subject_code:
            errors += 1
            results.append({"row": idx, "status": "error", "reason": "section_no and subject_code required"})
            continue

        subject = subjects_by_code.get(subject_code)
        if not subject:
            errors += 1
            results.append({"row": idx, "status": "error", "reason": f"subject_code '{subject_code}' not found"})
            continue
        if subject_out_of_scope(subject):
            errors += 1
            results.append({"row": idx, "status": "error", "reason": f"subject '{subject_code}' is outside the supported first-year curriculum"})
            continue

        block = None

        semester      = row.get('semester', '').strip() or None
        academic_year = row.get('academic_year', '').strip() or None

        # section number has to be unique across everything
        existing = SubjectSection.query.filter_by(section_no=section_no).first()
        if existing:
            existing_subject = Subject.query.get(existing.subject_id)
            subject_label = existing_subject.subject_code if existing_subject else f"subject_id={existing.subject_id}"
            skipped += 1
            results.append({
                "row": idx,
                "status": "skipped",
                "reason": f"section_no '{section_no}' already assigned to {subject_label}"
            })
            continue

        try:
            capacity = int(row.get('capacity', 40))
        except ValueError:
            capacity = 40

        section = SubjectSection(
            section_no    = section_no,
            subject_id    = subject.id,
            schedule      = row.get('schedule', '').strip() or None,
            room          = row.get('room', '').strip() or None,
            capacity      = max(1, min(200, capacity)),
            current_count = 0,
            semester      = semester,
            academic_year = academic_year,
            is_active     = True,
        )
        db.session.add(section)
        created += 1
        results.append({"row": idx, "status": "created", "section_no": section_no, "subject": subject.name})

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Commit failed", "detail": str(e)}), 500

    log_admin_action(admin.id, "SECTIONS_BULK_UPLOAD",
        f"Sections CSV: {created} created, {skipped} skipped, {errors} errors from {len(rows)} rows.")

    return jsonify({
        "summary": {"total_rows": len(rows), "created": created, "skipped": skipped, "errors": errors},
        "results": results,
    }), (207 if errors else 200)

# ===== UTILITY & INIT =====
@app.route('/api/health')
def health():
    return jsonify({"status": "running", "version": "1.0", "execution_mode": EXECUTION_MODE,
                    "schema_up_to_date": SCHEMA_STATE.get("up_to_date")}), 200

def apply_schema_and_seed():
    """
    Create missing tables, add missing columns, seed default rows.
    This WRITES to the database, so it never runs on import by default. It runs only when
    you ask for it: `python manage_schema.py upgrade` (prints the target and asks to confirm),
    or FORGE_AUTO_SCHEMA=1 (for throwaway test/demo databases and the test suite).
    """
    with app.app_context():
        # this has to run FIRST, before literally anything else in this block —
        # everything below (seeding achievements, the teacher_assignments
        # migrations, the problems table column check) queries or ALTERs tables
        # that only exist after this line runs. used to be called down at the
        # bottom of this same block instead, which only "worked" because
        # whoever ran this locally already had the tables from a previous run.
        # on a brand new empty database it broke immediately — the achievement
        # seed-check below has no try/except, so it just crashed on startup.
        db.create_all()

            # ===== SEED ACHIEVEMENTS =====
        if not Achievement.query.first():
            achievements_data = [
                # --- STUDENT BADGES (12) ---
                {"name": "First Steps", "desc": "Complete your first quest", "icon": "🎯", "xp": 10, "type": "quest_count", "val": 1, "cat": "student"},
                {"name": "Quest Master", "desc": "Complete 10 quests", "icon": "⚔️", "xp": 50, "type": "quest_count", "val": 10, "cat": "student"},
                {"name": "Week Warrior", "desc": "Maintain a 7-day streak", "icon": "🔥", "xp": 20, "type": "streak", "val": 7, "cat": "student"},
                {"name": "Python Novice", "desc": "Solve 5 Python quests", "icon": "🐍", "xp": 15, "type": "python_count", "val": 5, "cat": "student"},
                {"name": "Java Apprentice", "desc": "Solve 5 Java quests", "icon": "☕", "xp": 15, "type": "java_count", "val": 5, "cat": "student"},
                {"name": "C# Wizard", "desc": "Solve 5 C# quests", "icon": "🔷", "xp": 15, "type": "csharp_count", "val": 5, "cat": "student"},
                {"name": "Hard Coder", "desc": "Complete 5 Hard quests", "icon": "💀", "xp": 40, "type": "hard_count", "val": 5, "cat": "student"},
                {"name": "Debug Master", "desc": "Complete 5 Debugging quests", "icon": "🐛", "xp": 30, "type": "debug_count", "val": 5, "cat": "student"},
                {"name": "Marathon Coder", "desc": "Maintain a 30-day streak", "icon": "🏃", "xp": 100, "type": "streak", "val": 30, "cat": "student"},
                {"name": "Perfect Score", "desc": "Get 100% on a Hard quest", "icon": "💯", "xp": 25, "type": "perfect_hard", "val": 1, "cat": "student"},
                {"name": "Sandbox Wizard", "desc": "Run code in Sandbox 10 times", "icon": "🧪", "xp": 20, "type": "sandbox_runs", "val": 10, "cat": "student"},
                {"name": "Leaderboard Champ", "desc": "Reach Top 10 on Leaderboard", "icon": "", "xp": 50, "type": "leaderboard", "val": 10, "cat": "student"},

                # --- INSTRUCTOR BADGES (15) ---
                {"name": "First Module", "desc": "Create your first module", "icon": "📖", "xp": 25, "type": "lesson_count", "val": 1, "cat": "instructor"},
                {"name": "Activity Architect", "desc": "Create 10 activities", "icon": "🧩", "xp": 60, "type": "problem_count", "val": 10, "cat": "instructor"},
                {"name": "Class Starter", "desc": "Have a student complete a quest", "icon": "🚀", "xp": 20, "type": "student_quest", "val": 1, "cat": "instructor"},
                {"name": "Engagement Booster", "desc": "80%+ students attempt a quest", "icon": "📈", "xp": 40, "type": "engagement", "val": 80, "cat": "instructor"},
                {"name": "Curriculum Builder", "desc": "Create lessons for 3 weeks", "icon": "🗂️", "xp": 50, "type": "lesson_weeks", "val": 3, "cat": "instructor"},
                {"name": "Resource Curator", "desc": "Attach files to 10 lessons", "icon": "📎", "xp": 30, "type": "file_count", "val": 10, "cat": "instructor"},
                {"name": "Multimedia Master", "desc": "Add videos to 5 lessons", "icon": "🎬", "xp": 25, "type": "video_count", "val": 5, "cat": "instructor"},
                {"name": "Clear Explainer", "desc": "Lesson with 95% completion", "icon": "🗣️", "xp": 45, "type": "lesson_completion", "val": 95, "cat": "instructor"},
                {"name": "Activity Solver", "desc": "Activity with <10% error rate", "icon": "🔍", "xp": 40, "type": "problem_quality", "val": 10, "cat": "instructor"},
                {"name": "Innovation Award", "desc": "Create a quest with hints", "icon": "💡", "xp": 50, "type": "hints_used", "val": 1, "cat": "instructor"},
                {"name": "Student Success", "desc": "70%+ students pass all quests", "icon": "🎓", "xp": 75, "type": "class_pass_rate", "val": 70, "cat": "instructor"},
                {"name": "Daily Educator", "desc": "Login and act for 14 days", "icon": "📅", "xp": 30, "type": "instructor_streak", "val": 14, "cat": "instructor"},
                {"name": "Semester Veteran", "desc": "Teach for 16 weeks", "icon": "🎓", "xp": 100, "type": "weeks_taught", "val": 16, "cat": "instructor"},
                {"name": "Multi-Class Maestro", "desc": "Teach 3 different subjects", "icon": "🎭", "xp": 60, "type": "subjects_taught", "val": 3, "cat": "instructor"},
                {"name": "Platform Pioneer", "desc": "Use new features within 1 week", "icon": "🚀", "xp": 20, "type": "early_adopter", "val": 1, "cat": "instructor"}
            ]

            for data in achievements_data:
                db.session.add(Achievement(
                    name=data["name"],
                    description=data["desc"],
                    icon=data["icon"],
                    xp_reward=data["xp"],
                    requirement_type=data["type"],
                    requirement_value=data["val"],
                    category=data["cat"]
                ))
            db.session.commit()
            print("✅ Seeded 27 Achievements")
            # ── TeacherAssignment migration: block_id → section_id ──────────────
        # Step 1: add section_id if missing
        try:
            with db.engine.connect() as conn:
                conn.execute(text(
                    "ALTER TABLE teacher_assignments ADD COLUMN section_id INTEGER NULL "
                    "REFERENCES subject_sections(id) ON DELETE SET NULL"
                ))
                conn.commit()
                print("✅ teacher_assignments.section_id column added")
        except Exception:
            pass  # Already exists

        # Step 2: drop old unique constraint (handles both possible names)
        for old_constraint in ('unique_teacher_assignment', 'uq_teacher_assignment_old'):
            try:
                with db.engine.connect() as conn:
                    conn.execute(text(
                        f"ALTER TABLE teacher_assignments DROP INDEX {old_constraint}"
                    ))
                    conn.commit()
            except Exception:
                pass

        # Step 3: drop block_id column if it still exists
        try:
            with db.engine.connect() as conn:
                # Check if column exists first (information_schema is safe to query)
                result = conn.execute(text(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS "
                    "WHERE TABLE_NAME='teacher_assignments' AND COLUMN_NAME='block_id' "
                    "AND TABLE_SCHEMA=DATABASE()"
                ))
                if result.scalar() > 0:
                    conn.execute(text(
                        "ALTER TABLE teacher_assignments DROP COLUMN block_id"
                    ))
                    conn.commit()
                    print("✅ teacher_assignments.block_id column removed")
        except Exception as e:
            print(f"⚠️  block_id removal skipped: {e}")

        # Step 4: add new unique constraint if missing
        try:
            with db.engine.connect() as conn:
                conn.execute(text(
                    "ALTER TABLE teacher_assignments "
                    "ADD CONSTRAINT uq_teacher_assignment "
                    "UNIQUE (instructor_id, subject_id, section_id)"
                ))
                conn.commit()
                print("✅ uq_teacher_assignment constraint added")
        except Exception:
            pass  # Already exists

        # Step 5: drop stale visible_to_blocks column from problems if it still exists
        try:
            with db.engine.connect() as conn:
                result = conn.execute(text(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS "
                    "WHERE TABLE_NAME='problems' AND COLUMN_NAME='visible_to_blocks' "
                    "AND TABLE_SCHEMA=DATABASE()"
                ))
                if result.scalar() > 0:
                    conn.execute(text("ALTER TABLE problems DROP COLUMN `visible_to_blocks`"))
                    conn.commit()
                    print("✅ problems.visible_to_blocks stale column removed")
        except Exception as e:
            print(f"⚠️ visible_to_blocks removal skipped: {e}")

        # db.create_all() used to be called right here — moved to the top of
        # this same `with app.app_context():` block, see the comment up there.

        # Auto-migration for users table
        try:
            inspector = inspect(db.engine)
            user_columns = [col['name'] for col in inspector.get_columns('users')]
            if 'full_name' not in user_columns:
                with db.engine.connect() as conn:
                    conn.execute(text("ALTER TABLE users ADD COLUMN full_name VARCHAR(200) DEFAULT NULL"))
                    conn.commit()
                    print("✅ Added column 'full_name' to users table")
            # password-change support: additive, existing rows get the harmless defaults
            # (nobody is flagged and no session is invalidated by the upgrade itself)
            for col, ddl in (('must_change_password', "BOOLEAN NOT NULL DEFAULT 0"),
                             ('token_version', "INT NOT NULL DEFAULT 0"),
                             ('password_changed_at', "DATETIME NULL")):
                if col not in user_columns:
                    with db.engine.connect() as conn:
                        conn.execute(text(f"ALTER TABLE users ADD COLUMN {col} {ddl}"))
                        conn.commit()
                        print(f"✅ Added column '{col}' to users table")
        except Exception as e:
            print(f"⚠️ Users migration check skipped: {e}")

        # recorded per-test results on submissions (additive; older rows stay NULL)
        try:
            _sub_cols = [col['name'] for col in inspect(db.engine).get_columns('submissions')]
            if 'result_details' not in _sub_cols:
                with db.engine.connect() as conn:
                    conn.execute(text("ALTER TABLE submissions ADD COLUMN result_details JSON NULL"))
                    conn.commit()
                    print("✅ Added column 'result_details' to submissions table")
        except Exception as e:
            print(f"⚠️ Submissions migration check skipped: {e}")

        # Auto-migration for Problem table
        try:
            inspector = inspect(db.engine)
            problem_columns = [col['name'] for col in inspector.get_columns('problems')]

            def add_col_if_missing(col_name, col_def):
                if col_name not in problem_columns:
                    with db.engine.connect() as conn:
                        conn.execute(text(f"ALTER TABLE problems ADD COLUMN {col_name} {col_def}"))
                        conn.commit()
                        print(f"✅ Added column '{col_name}' to problems table")

            add_col_if_missing('problem_type', "ENUM('coding', 'debugging') DEFAULT 'coding'")
            add_col_if_missing('languages', "JSON DEFAULT ('[\"python\"]')")
            add_col_if_missing('is_event_quest', "BOOLEAN DEFAULT 0")
            add_col_if_missing('visible_to_sections', "JSON DEFAULT ('[]')")
            add_col_if_missing('hints', "JSON DEFAULT ('[]')")
            add_col_if_missing('tags', "JSON DEFAULT ('[]')")
            add_col_if_missing('prerequisites', "JSON DEFAULT ('[]')")
            add_col_if_missing('estimated_time', "VARCHAR(50)")
            add_col_if_missing('partial_credit', "INTEGER DEFAULT 100")
            add_col_if_missing('auto_grade', "BOOLEAN DEFAULT 1")
            add_col_if_missing('plagiarism_threshold', "FLOAT DEFAULT 0.85")
            add_col_if_missing('due_date', "DATETIME DEFAULT NULL")
            add_col_if_missing('login_attempts', "INT DEFAULT 0")
            add_col_if_missing('locked_until', "DATETIME DEFAULT NULL")
        except Exception as e:
            print(f"⚠️ Migration check skipped: {e}")

        # Seed default config
        if not SystemConfig.query.first():
            for k,v in {'execution_timeout':'5','enabled_languages':'python,java,csharp','xp_multiplier':'1.0','plagiarism_threshold':'0.85','maintenance_mode':'false'}.items():
                db.session.add(SystemConfig(key=k, value=v))
            db.session.commit()

        ensure_award_pair_unique()

        print("✅ DB Initialized | 🔐 JWT | 🎮 Gamification | 📚 Sections | 🛡️ Admin System")


AWARD_PAIR = ('user_id', 'achievement_id')


def award_pair_unique_present(insp):
    """True only when the table really enforces uniqueness of exactly (user_id, achievement_id): a unique
    constraint, unique index or primary key over exactly those two columns, whatever it is called, and with no
    column prefix / filter condition. Two separate unique columns, a 3-column unique index, or a plain
    index do NOT count."""
    want = set(AWARD_PAIR)
    try:
        if set((insp.get_pk_constraint('user_achievements') or {}).get('constrained_columns') or []) == want:
            return True
        for uc in insp.get_unique_constraints('user_achievements'):
            if set(uc.get('column_names') or []) == want and len(uc['column_names']) == 2:
                return True
        for ix in insp.get_indexes('user_achievements'):
            cols = ix.get('column_names') or []
            opts = ix.get('dialect_options') or {}
            if (ix.get('unique') and len(cols) == 2 and set(cols) == want
                    and not opts.get('sqlite_where') and not opts.get('postgresql_where')
                    and not opts.get('mysql_length')):
                return True
    except Exception:
        return False
    return False


def award_pair_duplicate_summary():
    """READ-ONLY, aggregate counts only (no user ids): duplicate (user, achievement) pairs in user_achievements."""
    with app.app_context():
        r = db.session.execute(text(
            "SELECT COUNT(*), COALESCE(SUM(c - 1), 0) FROM ("
            "SELECT COUNT(*) AS c FROM user_achievements GROUP BY user_id, achievement_id HAVING COUNT(*) > 1) d")).fetchone()
        db.session.rollback()
        return {"duplicate_pairs": int(r[0] or 0), "excess_rows": int(r[1] or 0)}


def ensure_award_pair_unique():
    """Part of the EXPLICIT upgrade only. Adds UNIQUE(user_id, achievement_id) when it is safe: never deletes,
    merges or rewrites a row. If duplicate pairs exist it changes nothing and returns 'blocked_duplicates'
    (the reviewed preservation design in docs/ACHIEVEMENT_PRESERVATION_DESIGN.md is required first).
    DDL commits by itself on MySQL; it is a single statement, so it either exists afterwards or not at all."""
    with app.app_context():
        if award_pair_unique_present(inspect(db.engine)):
            return 'present'
        dup = award_pair_duplicate_summary()
        if dup["duplicate_pairs"]:
            print(f"⛔ user_achievements has {dup['duplicate_pairs']} duplicate (user, achievement) pair(s) "
                  f"({dup['excess_rows']} extra rows). The uniqueness constraint was NOT added and no row was touched. "
                  "See docs/ACHIEVEMENT_PRESERVATION_DESIGN.md.")
            return 'blocked_duplicates'
        with db.engine.connect() as conn:
            if db.engine.dialect.name == 'sqlite':
                conn.execute(text("CREATE UNIQUE INDEX uq_user_achievement ON user_achievements (user_id, achievement_id)"))
            else:
                conn.execute(text("ALTER TABLE user_achievements ADD CONSTRAINT uq_user_achievement "
                                  "UNIQUE (user_id, achievement_id)"))
            conn.commit()
        print("✅ user_achievements: UNIQUE(user_id, achievement_id) added")
        return 'added'


def schema_status():
    """READ-ONLY: what the database is missing compared with the models. Never writes."""
    from sqlalchemy import inspect as _inspect
    missing_tables, missing_columns, missing_constraints = [], {}, {}
    with app.app_context():
        insp = _inspect(db.engine)
        existing = set(insp.get_table_names())
        for name, table in db.metadata.tables.items():
            if name not in existing:
                missing_tables.append(name)
                continue
            have = {c['name'] for c in insp.get_columns(name)}
            lacking = [c.name for c in table.columns if c.name not in have]
            if lacking:
                missing_columns[name] = lacking
        if 'user_achievements' in existing and not award_pair_unique_present(insp):
            missing_constraints['user_achievements'] = ['UNIQUE(user_id, achievement_id)']
    return {"up_to_date": not missing_tables and not missing_columns and not missing_constraints,
            "missing_tables": missing_tables, "missing_columns": missing_columns,
            "missing_constraints": missing_constraints}


def describe_database_target():
    """host/database of the configured database, without credentials."""
    from sqlalchemy.engine import make_url
    u = make_url(app.config['SQLALCHEMY_DATABASE_URI'])
    return f"{u.drivername}://{u.host or ''}{':' + str(u.port) if u.port else ''}/{u.database or ''}"


SCHEMA_AUTO = os.environ.get('FORGE_AUTO_SCHEMA', '').strip().lower() in ('1', 'true', 'yes')
SCHEMA_STATE = {"checked": False, "up_to_date": None, "detail": None}

if SCHEMA_AUTO:
    # explicit opt-in (test/demo databases): the old behaviour
    apply_schema_and_seed()
    SCHEMA_STATE.update(checked=True, up_to_date=True)
else:
    try:
        _st = schema_status()
        SCHEMA_STATE.update(checked=True, up_to_date=_st["up_to_date"], detail=_st)
        if _st["up_to_date"]:
            print("DB schema is up to date (read-only check; nothing was changed).")
        else:
            print("DATABASE SCHEMA IS OUT OF DATE. The app did NOT change it. Missing: "
                  f"tables={_st['missing_tables']} columns={_st['missing_columns']} constraints={_st['missing_constraints']}. "
                  "Back up, then run: python manage_schema.py upgrade")
    except Exception as _e:
        SCHEMA_STATE.update(checked=False, up_to_date=None, detail={"error": type(_e).__name__})
        print(f"Could not check the database schema (read-only): {type(_e).__name__}")


@app.before_request
def _block_while_schema_outdated():
    # a stale schema would make queries fail halfway; answer clearly instead
    if SCHEMA_STATE.get("up_to_date") is False and request.path.startswith('/api/') and request.path != '/api/health':
        return jsonify({"error": "schema_upgrade_required",
                        "message": "The database needs an administrator-run upgrade before the app can be used."}), 503
    return None


if __name__ == '__main__':
    print("🚀 Forge.dev Backend | 📊 System-Ready | 🧪 Sandbox Active")
    # FLASK_DEBUG defaults on for local dev; the production container sets it to
    # 'false' explicitly (the Werkzeug debugger lets anyone who can reach it run
    # arbitrary code, so it must never be on for something exposed publicly) and
    # runs behind gunicorn instead of this dev server anyway — see docker-compose.
    debug_mode = os.environ.get('FLASK_DEBUG', 'true').lower() == 'true' and not IS_PRODUCTION
    app.run(debug=debug_mode, host='0.0.0.0', port=5000)