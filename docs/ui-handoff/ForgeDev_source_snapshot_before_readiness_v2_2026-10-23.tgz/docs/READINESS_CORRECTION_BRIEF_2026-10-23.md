# Claude — focused readiness corrections

23 October 2026. Owner-approved next priorities, before further production UI integration. Codex owns planning/design/independent review; **Claude owns application edits and application tests**. Codex wrote independent probes only under `_testing/` and saved evidence/docs. No commits, deployment, new tunnels, accounts, live-data/identity changes, migrations or record deletion. Preserve every existing uncommitted file and approved preview/artwork.

## Read first

1. [Current status](C:/Users/Christian/forge-dev/docs/CURRENT_STATE_HANDOFF_2026-10-23.md), [decision log](C:/Users/Christian/forge-dev/docs/PROJECT_DECISIONS.md), [overview](C:/Users/Christian/forge-dev/docs/PROJECT_OVERVIEW.md).
2. [Original integrity contract](C:/Users/Christian/forge-dev/docs/ACHIEVEMENT_INTEGRITY_IMPLEMENTATION_BRIEF_2026-10-23.md), especially transactions, actual POST overlap, API fields and preservation; its section 3 describes the pre-v1 baseline.
3. [Independent v1 checkpoint](C:/Users/Christian/forge-dev/docs/reviews/ACHIEVEMENT_INTEGRITY_V1_INDEPENDENT_REVIEW_2026-10-23.md), developer v1 package/report, [preservation proposal](C:/Users/Christian/forge-dev/docs/ACHIEVEMENT_PRESERVATION_DESIGN.md).
4. [Direct-request assertions](C:/Users/Christian/forge-dev/docs/reviews/evidence/readiness-2026-10-23/direct_access_tests.py) and [raw results](C:/Users/Christian/forge-dev/docs/reviews/evidence/readiness-2026-10-23/direct-access-results.txt). Their original runnable isolated layout is `_testing/readiness-priorities-2026-10-23/`; source hashes accompany the evidence. Do not run them against a real DB.
5. `backend/app.py` quest create/update, lesson create, general/student announcements, shared access helpers, evaluate_code; `backend/routes/sandbox.py`; frontend achievement store/notifications/celebrations; existing access/grading/award tests and actual MySQL harness.
6. [Session/hosting plan](C:/Users/Christian/forge-dev/docs/SCHOOL_SESSION_AND_HOSTING_PLAN_2026-10-23.md), [preliminary evaluation](C:/Users/Christian/forge-dev/docs/PRELIMINARY_EVALUATION_2026-09-22.md), [client curriculum research](C:/Users/Christian/forge-dev/docs/CURRICULUM_RESEARCH_LCC_BINAN_2026-10-23.md).

## P1 — confirmed cross-class authorization gaps

Independent Flask test-client requests to an isolated copy of current code, fresh SQLite with synthetic users/classes, **7 failed / 5 passed**. These are actual application routes, not frontend mocks; no external HTTP server/Docker/real data was used. Test context: instructor A teaches section A; instructor B teaches section B of the **same subject**. Subject-level assignment must not grant section-B rights.

| Probe / required denial | Actual result |
|---|---|
| Student A reads `GET /api/announcements?class_id=B` | 200, denial assertion fails |
| Instructor A reads that same class-B endpoint | 200, denial assertion fails |
| Instructor A creates published quest visible only to B | 201 |
| Instructor A creates quest visible to A and B | 201 |
| Instructor A creates quest with nonexistent section ID | 201 |
| Instructor A creates lesson in B | 201 |
| Instructor A updates own quest to add B | 200 |

Positive/negative controls passed: own announcement read; filtered student-announcement feed excludes other-class marker; own quest creation; own lesson creation; cross-class student quest detail returns 404. Existing protected routes must remain functional. The general announcement route's class filter bypasses the safer student feed. The seeded foreign announcement content is synthetic; no school data was exposed during tests.

Follow-up extended run: **7 failed / 8 passed**. Three added independent assertions pass: master CSV creates/enrolls the proposed numeric synthetic profile without a year column, login is blocked until forced password change and invalidates the old token while assigned-identifier login works; irregular multi-class import repeats without duplicate users/memberships; public registration returns 410. This supports the existing supervised-provisioning path, not a full session/load/real-browser rehearsal. [Extended test source](C:/Users/Christian/forge-dev/docs/reviews/evidence/readiness-2026-10-23/direct_access_and_provisioning_tests.py), [extended raw results](C:/Users/Christian/forge-dev/docs/reviews/evidence/readiness-2026-10-23/direct-access-and-provisioning-results.txt). Original 12-test evidence is retained separately. Fixture credentials remained in memory and were not logged.

Acceptance:

- Enforce role and class membership/teaching on **direct requests** before query results or writes. Student sees own enrolled class/global announcements only; instructor sees own taught class/global scope; preserve legitimate administrator read access. Define consistent empty/global query behavior; reject invalid IDs without leakage.
- Validate every quest target section exists, belongs to the selected subject and is authorized for that instructor on create **and update**. A mixed valid/invalid list is rejected atomically, not partially saved. Do not silently broaden visibility. Lesson creation must validate the specific section assignment, not merely any assignment to its subject.
- Preserve documented administrator privileges and current legitimate author workflows. Existing administrator authoring also requires assignments today; do not silently change that policy. Document any ownership-policy edge that needs separate approval.
- Tests must assert status, absence of forbidden content and **unchanged DB state on denial**, including original quest fields/visibility after rejected update. Add nonexistent, foreign-subject, mixed-list, unpublished and temporary-password cases; test both general and role-specific access paths. Keep historical read behavior and section-scoped files intact. Include allowed controls so deny-all cannot pass.
- Audit sibling read/write endpoints for this same bypass pattern and report concrete findings; do not claim a whole-system security certification. Analytics' cross-quest aggregation is a distinct known metric issue; do not change formulas or historical scores as an incidental authorization fix.

## P1 — real Docker C# classification

Reviewer actual sandbox run: 14/15 cases pass; C# compile-error case reports `wrong_output`, expected `runtime_error` (the existing evaluate_code contract groups compile/crash outcomes there). Evidence in the v1 checkpoint, `_testing/achievement-integrity-independent-review-2026-10-23/evidence/docker-execution.txt` and generated verification JSON. This is a real execution result, not merely a mocked unit test.

Inspect raw stdout/stderr/exit status safely: current evaluate_code only treats nonzero return as error when stdout is empty. A nonzero compiler/program exit must not become accepted just because stdout happens to equal expected output. Fix classification consistently through quest Run, final Submit and practice sandbox, preserving appropriate public/hidden feedback. If changing public kind/status semantics, document and cover compatibility rather than invent a new UI contract.

Acceptance: assert Python/Java/C# correct, wrong output, runtime/compile failure, timeout, and **nonzero exit with nonempty/matching stdout**; no false accepted grade. Re-run real Docker cases on available images plus direct Submit tests proving student-code errors consume the one final attempt, while actual infrastructure errors do not and XP/hint rules remain unchanged. Preserve hidden-case redaction and compile-line offsets. Report engine/image identifiers and actual vs mocked evidence separately.

## P2 — notification refresh ordering

The 13 supplied Node tests pass but two independent assertions fail. See `_testing/achievement-integrity-independent-review-2026-10-23/refresh-race.test.mjs`. `finally` clears ownership before queued fresh follow-up starts; an awaiting caller can enter that gap, creating concurrent requests, after which an older response can replace newer earned state.

Acceptance: enforce safe ownership through the handoff (or reuse existing request), prevent stale response replacement and unhandled rejection. Deterministically assert the exact microtask gap with two callers, one queued fresh refresh, remount, rejection and owner switch; maximum allowed active requests and last committed state must be explicit. Queue only server `just_earned`, each award once per account; preserve first/multiple awards, StrictMode, sign-out clearing, static/silent reduced motion and screen-reader announcements. Follow-up fetch failure must never turn a committed Submit into failure. Do not claim guaranteed celebration after a lost response.

## Preservation/recovery requirement

Correct proposal sections 5–7 before approval: backup before write exclusion is not a final lossless recovery point; restoring it after intervening or post-cutover writes discards records. Define consistent final backup/position under actual write exclusion, pre-reopen rollback, and post-reopen preservation/replay or forward recovery. Include schema/code compatibility, DDL auto-commit, idempotency and restore rehearsal on synthetic duplicate history. A maintenance status flag is not write exclusion. Keep option(a) canonical entitlement/history as an unapproved proposal. **No duplicate cleanup, historical XP/level inference, backfill, live audit or migration.**

## Confirmed client and delivery corrections

Change **active** application branding and documentation prepared for delivery to **La Consolacion College Biñan**; keep **Adamson University** for researchers. Current source occurrence includes `frontend/src/components/Landing.jsx:162`; inspect the active build/document inputs rather than blindly replacing all reports. Do not rename genuine Adamson affiliations or historical evidence. Institution confirmation does not approve BSIT/version/catalog. Self-registration remains disabled. Record September 22 three-person preliminary evaluation and verified averages; do not claim formal UAT or all-5 ratings. Larger school testing remains planned: owner estimates 100–200 simultaneous users, with uncertain upper bound below 400; exact date/final count unknown. These are demand estimates, not verified capacity. The September participants were one client-school student and two professors testing Student, Instructor and Administrator respectively; do not call the latter professor a school administrator. Exact tested build/tasks/assistance/procedure remain unknown.

No new artwork or broad visual integration. Correct text in the existing application without redesigning it. Launcher hardening/session isolation is a separately bounded prerequisite identified in the session plan: do not run the existing public-debug path, edit actual environment values or open tunnels during this batch. Return a concrete launcher change proposal if needed; all publicly exposed runs require later session authorization.

## Return and stop for independent review

Recheck git status; establish changed-file ownership before editing. Return a focused diff, changed-file list with pristine comparisons, exact commands, sanitized assertion results, actual Docker/MySQL versions/isolation, UI evidence relevant to notification behavior and explicit unverified items. Run the original integrity regressions, real POST Submit-overlap harness and whole frontend build after corrections; broaden tests only for affected behavior. Separate prior developer/reviewer results from new executions. Preserve every preexisting change. Stop for Codex review; no production UI integration or release actions.

## Consolidated checkpoint addendum

Follow [READINESS_REVIEW_CHECKPOINT](C:/Users/Christian/forge-dev/docs/READINESS_REVIEW_CHECKPOINT_2026-10-23.md) before proposing an operating limit: correct/regress first, then measure browser/API and real Docker concurrency separately on isolated targets. Demand was explicitly supplied by the owner as “Probably 100-200 or below 400”; label both low-confidence tentative planning estimates, never requirements or demonstrated support. Do not turn the upper bound into an exact stress target. Existing v1 report resubmission is not a correction batch. Parallel design review preparation belongs to Codex and remains separate from application integration.
