"""Independent direct Flask requests. Fresh synthetic SQLite, no Docker or external calls."""
import os
import sys
import tempfile
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
scratch = ROOT / 'temp'
scratch.mkdir(exist_ok=True)
tempfile.tempdir = str(scratch)
os.environ.update(PYTHON_DOTENV_DISABLED='1', FORGE_ENV='test', FORGE_AUTO_SCHEMA='1',
    DATABASE_URL='sqlite:///' + (ROOT / ('access_test_' + uuid.uuid4().hex + '.db')).as_posix(),
    JWT_SECRET_KEY='synthetic-independent-access-review-key',
    HEAD_ADMIN_EMAIL='head.admin@forge-test.example', STUDENT_EMAIL_DOMAIN='student.com',
    FORGE_UPLOADS_DIR=str(ROOT / 'uploads'), TMP=str(scratch), TEMP=str(scratch))
for key in ['ALLOWED_EMAIL_DOMAIN', 'FORGE_DEMO', 'FORGE_DEMO_RUNNER', 'GEMINI_API_KEY']:
    os.environ.pop(key, None)
sys.path.insert(0, str(ROOT.parent / 'achievement-integrity-independent-review-2026-10-23' / 'deps'))
sys.path.insert(0, str(ROOT / 'backend'))
import pytest
import app as A
from flask_jwt_extended import create_access_token
from werkzeug.security import generate_password_hash


@pytest.fixture
def world():
    with A.app.app_context():
        A.db.drop_all()
        A.db.create_all()
        users = {}
        for name, role in [('teacher_a', 'instructor'), ('teacher_b', 'instructor'),
                           ('student_a', 'student'), ('student_b', 'student'), ('admin', 'administrator')]:
            user = A.User(username=name, email=name+'@forge-test.example', role=role,
                          password_hash=generate_password_hash('FixtureOnly17'), must_change_password=False)
            A.db.session.add(user)
            users[name] = user
        subject = A.Subject(name='Synthetic introductory fixture', subject_code='FIX1', year_level=1)
        A.db.session.add(subject)
        A.db.session.flush()
        a = A.SubjectSection(subject_id=subject.id, section_no='REVIEW-A')
        b = A.SubjectSection(subject_id=subject.id, section_no='REVIEW-B')
        A.db.session.add_all([a, b])
        A.db.session.flush()
        A.db.session.add_all([
            A.TeacherAssignment(instructor_id=users['teacher_a'].id, subject_id=subject.id, section_id=a.id),
            A.TeacherAssignment(instructor_id=users['teacher_b'].id, subject_id=subject.id, section_id=b.id),
            A.IrregularEnrollment(student_id=users['student_a'].id, section_id=a.id),
            A.IrregularEnrollment(student_id=users['student_b'].id, section_id=b.id),
            A.Announcement(instructor_id=users['teacher_a'].id, class_id=a.id, title='A only', content='A_PRIVATE_MARKER'),
            A.Announcement(instructor_id=users['teacher_b'].id, class_id=b.id, title='B only', content='B_PRIVATE_MARKER'),
        ])
        A.db.session.commit()
        result = {'a':a.id, 'b':b.id, 'subject':subject.id,
                  'headers':{name:{'Authorization':'Bearer '+create_access_token(identity=str(u.id))} for name,u in users.items()},
                  'client':A.app.test_client()}
        yield result
        A.db.session.rollback()


def quest(w, sections):
    return dict(title='Synthetic access probe', description='Fixture only', difficulty='Easy',
                xp_reward=50, test_cases=[{'input':'1','expected':'1'}],
                subject_id=w['subject'], visible_to_sections=sections, is_published=True)


def test_own_class_announcement_is_readable(world):
    w=world
    r=w['client'].get('/api/announcements?class_id='+str(w['a']), headers=w['headers']['student_a'])
    assert r.status_code==200 and 'A_PRIVATE_MARKER' in r.get_data(as_text=True)


@pytest.mark.parametrize('actor', ['student_a','teacher_a'])
def test_other_class_announcement_is_denied(world, actor):
    w=world
    r=w['client'].get('/api/announcements?class_id='+str(w['b']), headers=w['headers'][actor])
    assert r.status_code in (403,404), 'Unauthorized direct announcement request returned '+str(r.status_code)
    assert 'B_PRIVATE_MARKER' not in r.get_data(as_text=True)


def test_filtered_student_announcements_do_not_leak(world):
    w=world
    r=w['client'].get('/api/student/announcements',headers=w['headers']['student_a'])
    assert r.status_code==200
    assert 'A_PRIVATE_MARKER' in r.get_data(as_text=True) and 'B_PRIVATE_MARKER' not in r.get_data(as_text=True)


def test_own_quest_creation_succeeds(world):
    w=world
    r=w['client'].post('/api/problems',json=quest(w,[w['a']]),headers=w['headers']['teacher_a'])
    assert r.status_code==201


@pytest.mark.parametrize('mixed', [False,True])
def test_foreign_section_quest_creation_is_atomic_denial(world,mixed):
    w=world
    with A.app.app_context(): before=A.Problem.query.count()
    r=w['client'].post('/api/problems',json=quest(w,[w['a'],w['b']] if mixed else [w['b']]),headers=w['headers']['teacher_a'])
    assert r.status_code in (400,403,404), 'Foreign section quest creation returned '+str(r.status_code)
    with A.app.app_context(): assert A.Problem.query.count()==before


def test_nonexistent_section_quest_creation_is_denied(world):
    w=world
    r=w['client'].post('/api/problems',json=quest(w,[999999]),headers=w['headers']['teacher_a'])
    assert r.status_code in (400,403,404), 'Nonexistent section accepted: '+str(r.status_code)


def test_own_lesson_creation_succeeds(world):
    w=world
    r=w['client'].post('/api/lessons',json=dict(title='Own',description='Synthetic',week_number=1,
        subject_id=w['subject'],section_id=w['a']),headers=w['headers']['teacher_a'])
    assert r.status_code==201


def test_other_class_lesson_creation_is_denied(world):
    w=world
    r=w['client'].post('/api/lessons',json=dict(title='Foreign',description='Synthetic',week_number=1,
        subject_id=w['subject'],section_id=w['b'],is_published=True),headers=w['headers']['teacher_a'])
    assert r.status_code in (403,404), 'Foreign section lesson creation returned '+str(r.status_code)


def test_quest_update_cannot_add_foreign_section(world):
    w=world
    r=w['client'].post('/api/problems',json=quest(w,[w['a']]),headers=w['headers']['teacher_a'])
    assert r.status_code==201
    qid=r.get_json()['problem_id']
    r=w['client'].put('/api/problems/'+str(qid),json=quest(w,[w['a'],w['b']]),headers=w['headers']['teacher_a'])
    assert r.status_code in (400,403,404), 'Quest update adds foreign section: '+str(r.status_code)


def test_cross_class_quest_read_is_denied(world):
    w=world
    r=w['client'].post('/api/problems',json=quest(w,[w['a']]),headers=w['headers']['teacher_a'])
    assert r.status_code==201
    qid=r.get_json()['problem_id']
    r=w['client'].get('/api/problems/'+str(qid),headers=w['headers']['student_b'])
    assert r.status_code==404


if __name__=='__main__':
    raise SystemExit(pytest.main([__file__,'-q','--tb=short','-p','no:cacheprovider']))
