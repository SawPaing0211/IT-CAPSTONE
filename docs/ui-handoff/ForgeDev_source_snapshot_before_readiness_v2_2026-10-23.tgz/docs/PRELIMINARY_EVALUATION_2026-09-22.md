# Preliminary evaluation — 22 September 2026

Verified 23 October 2026, with subsequent owner confirmation of participant affiliation. **Completed preliminary evaluation: three La Consolacion College Biñan participants on 22 September 2026; formal UAT classification unverified.**

Source: [original supplied export ZIP](<C:/Users/Christian/Downloads/survey.csv (1).zip>). ZIP SHA-256 `595d3d1683b6a80de8ee0b00adc52df79db2b1dc64e6ff30a69c9dbfa94d3649`; contained CSV SHA-256 `bde091cc9ccf6eeeceb290a723387fb9eeff241637ba0c0f6a470507586f25af`. The original archive/responses remain unchanged. Raw demographics/free text were not copied into delivery documentation or printed; access to the original must remain controlled.

## Verified arithmetic

One CSV, 22 columns, three data rows. Columns 4–19 (1-based) contain the 16 rating items, question numbers 3–18. All 48 values are integers within 1–5, no missing rating. All response dates are 2026/09/22; export timezone was not independently established. The role is taken from the role value in the two screening columns, whose duplicate header names must not cause an overwritten column during parsing.

| Self-described role | Items | Sum | Mean | Ratings of 3 / 4 / 5 |
|---|---:|---:|---:|---|
| Admin | 16 | 63 | **3.9375** | 1 / 15 / 0 |
| Instructor | 16 | 77 | **4.8125** | 0 / 3 / 13 |
| Student | 16 | 80 | **5.0000** | 0 / 0 / 16 |
| All respondents/items | 48 | 220 | **4.583333…** | 1 / 18 / 29 |

Owner-confirmed actual affiliations, separate from the export's application-role labels:

| Participant affiliation at La Consolacion College Biñan | Application role tested |
|---|---|
| Student | Student |
| Professor | Instructor |
| Professor | Administrator |

No participant names are needed for this mapping. The Administrator test-role rating must not be described as a rating from a confirmed institutional administrator.

Method: sum each respondent's 16 numeric ratings, divide by 16; pooled mean `220 / 48`, rounded to **4.5833**. No 1s or 2s. “Everyone gave 5 stars” is incorrect; **29/48 item ratings** were 5. Because each respondent answered the same number of items, averaging the three respondent means gives the same pooled mean. This is not a five-domain equally weighted score: usability has four items and the other four domains three each.

Reproducible sanitized intermediate: [aggregate JSON](C:/Users/Christian/forge-dev/docs/reviews/evidence/readiness-2026-10-23/survey-aggregate.json). Verification used bundled Python `csv.reader` and `Decimal` on ZIP bytes in memory, preserving positional duplicate headers. No workbook or original response values were edited.

## Interpretation and thesis chronology

The export establishes three subjective responses under the listed application-role labels on 22 September. **The owner separately confirms that all three participants were from La Consolacion College Biñan: one student tested the Student role, one professor tested the Instructor role, and a second professor tested the Administrator role.** The professor testing Administrator is not established as a school administrator. These affiliations are owner-confirmed context, not independently established by the role labels in the export. The exact application version, tasks, assistance provided, evaluation procedure, test environment, authorization/consent and acceptance criteria remain unconfirmed. One respondent per role cannot establish population-wide satisfaction or learning improvement. A favorable security rating does not prove access controls; current direct-request tests demonstrate why these evidence types must remain separate.

For delivery documentation, replace broad assertions of completed formal UAT with:

> A preliminary evaluation was completed on 22 September 2026 with three participants from La Consolacion College Biñan: one student tested the Student role, one professor tested the Instructor role, and another professor tested the Administrator role. The tested application roles do not establish institutional job titles. The Google Forms export contains 16 ratings per respondent, with means of 5.0000, 4.8125 and 3.9375 for the Student, Instructor and Administrator test roles respectively; the pooled item mean was 4.5833 out of 5. The application version, tasks, assistance and evaluation procedure remain unconfirmed, so formal UAT and technical acceptance are not claimed. A larger school testing session remains planned for next week, with an owner-estimated 100–200 simultaneous users and an uncertain upper bound below 400; its exact date, procedure, final count and classification remain unconfirmed.

The original thesis is preserved. Its sections 3.2/3.4 describe completed interviews, surveys, prototype validation and UAT, while section 3.7 describes anticipated results. This export supports only the preliminary evaluation above. Do not retroactively claim evidence for interviews, separate needs surveys, laboratory observation, formal acceptance, response-time benchmarks or improved outcomes. Clause-by-clause thesis revisions should distinguish completed preliminary work, planned school testing and anticipated benefits.

Still needed: exact tested application version/build, tasks, assistance provided, evaluation procedure, test environment, acceptance criteria if any, consent/collection arrangements, and evidence for other claimed research activities. Participant school affiliation and student/professor status are now owner-confirmed and should not be requested again. Do not solicit identifiable respondent details merely to strengthen the report.
