// note to self: instructor dashboard uses routes + <Outlet/> so tabs get real URLs. student/admin dashboards just switch tabs internally, no child routes for those two.

import { useState, useEffect, useLayoutEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom'

// Public Components
import Landing from './components/Landing'
import Auth from './components/Auth'

// Dashboard Components
import InstructorDashboard from './pages/Instructor/InstructorDashboard'
import StudentDashboard from './pages/Student/StudentDashboard'
import AdminDashboard from './pages/Admin/AdminDashboard'

// Instructor Pages (only these need importing here — they're rendered via <Outlet/>)
import DashboardOverview from './pages/Instructor/DashboardOverview'
import MyClasses from './pages/Instructor/MyClasses'
import ProblemManagement from './pages/Instructor/ProblemManagement'
import CreateProblem from './pages/Instructor/CreateProblem'
import SelectClassForQuest from './pages/Instructor/SelectClassForQuest'
import ClassDetail from './pages/Instructor/ClassDetail'
import Announcements from './pages/Instructor/Announcements'
import PlagiarismCheck from './pages/Instructor/PlagiarismCheck'
import Analytics from './pages/Instructor/Analytics'
import CourseMaterials from './pages/Instructor/CourseMaterials'
import ProblemSubmissions from './pages/Instructor/ProblemSubmissions'
import InstructorAchievements from './pages/Instructor/InstructorAchievements'
import { API_BASE } from './api/client'
import ChangePasswordModal from './components/ChangePasswordModal'
import { CHANGE_PASSWORD_EVENT } from './utils/accountEvents'
import { achievementStore } from './utils/achievementStore'
import AchievementCelebrations from './components/AchievementCelebrations'

// student/admin sub-pages are handled inside those dashboards themselves, not routed here

function AppContent() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showChangePw, setShowChangePw] = useState(false)
  const navigate = useNavigate()

  // every role's account menu opens the same dialog
  useEffect(() => {
    const open = () => setShowChangePw(true)
    window.addEventListener(CHANGE_PASSWORD_EVENT, open)
    return () => window.removeEventListener(CHANGE_PASSWORD_EVENT, open)
  }, [])

  // a demo server (simulated code runner) says so; real servers report 'docker-sandbox'
  const [simulatedRunner, setSimulatedRunner] = useState(false)
  useEffect(() => {
    fetch(`${API_BASE}/api/health`).then(r => r.json()).then(h => setSimulatedRunner(h.execution_mode === 'demo-stub')).catch(() => {})
  }, [])

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      fetch(`${API_BASE}/api/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(data => {
          if (data.id) setUser(data);
          else {
            localStorage.removeItem('token')
            localStorage.removeItem('refresh_token')
            navigate('/auth')
          }
        })
        .catch(() => {
          localStorage.removeItem('token')
          localStorage.removeItem('refresh_token')
          navigate('/auth')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [navigate])

  const handleLogin = (userData) => {
    setUser(userData)
    // Redirect based on role
    if (userData.role === 'instructor') navigate('/instructor')
    else if (userData.role === 'student') navigate('/student')
    else if (userData.role === 'administrator') navigate('/admin')
  }

  // The celebration queue/cache belong to exactly one signed-in account.
  useLayoutEffect(() => {
    achievementStore.setOwner(user && !user.must_change_password ? { id: user.id, role: user.role } : null)
  }, [user?.id, user?.role, user?.must_change_password])

  const handleLogout = () => {
    achievementStore.clear()
    localStorage.removeItem('token')
    localStorage.removeItem('refresh_token')
    setUser(null)
    navigate('/')
  }

  // Protected Route Component
  const ProtectedRoute = ({ children, allowedRoles }) => {
    if (!user) return <Navigate to="/auth" replace />
    if (!allowedRoles.includes(user.role)) return <Navigate to="/" replace />
    return children
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-purple-600 border-t-transparent mx-auto mb-4"></div>
          <p className="text-white font-mono text-lg drop-shadow-lg">Summoning Forge.dev...</p>
        </div>
      </div>
    )
  }

  const mustChange = !!(user && user.must_change_password)

  return (
    <>
    {simulatedRunner && (
      <div className="fixed top-0 inset-x-0 z-[100000] bg-amber-500 text-black text-xs font-bold text-center py-1 pointer-events-none">
        DEMO: code results are simulated, not produced by the real sandbox
      </div>
    )}
    {mustChange && (
      <ChangePasswordModal
        forced
        onChanged={() => setUser(u => ({ ...u, must_change_password: false }))}
        onLogout={handleLogout}
      />
    )}
    {showChangePw && !mustChange && (
      <ChangePasswordModal onClose={() => setShowChangePw(false)} onChanged={() => setTimeout(() => setShowChangePw(false), 1200)} />
    )}
    <AchievementCelebrations />
    {mustChange ? (
      // nothing else is mounted until the temporary password is replaced: every other API call is refused meanwhile
      <div className="min-h-screen bg-slate-950" />
    ) : (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Landing />} />
      <Route path="/auth" element={<Auth onLogin={handleLogin} />} />

      {/* instructor side, uses <Outlet/> so these tabs are real pages */}
      <Route
        path="/instructor/*"
        element={
          <ProtectedRoute allowedRoles={['instructor']}>
            <InstructorDashboard user={user} onLogout={handleLogout} />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardOverview />} /> {/* the home tab when you first log in */}
        <Route path="classes" element={<MyClasses />} /> {/* list of my classes */}
        <Route path="class/:id" element={<ClassDetail />} /> {/* one class, tabs inside for materials/quests/etc */}
        <Route path="problems" element={<ProblemManagement />} /> {/* the quests list */}
        <Route path="create-problem" element={<CreateProblem />} /> {/* the quest builder wizard */}
        <Route path="create-problem/pick-class" element={<SelectClassForQuest />} /> {/* pick a class first when there's no class context yet */}
        <Route path="problem/:problemId/submissions" element={<ProblemSubmissions />} />
        <Route path="announcements" element={<Announcements />} /> {/* posting announcements to students */}
        <Route path="plagiarism" element={<PlagiarismCheck />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="materials" element={<CourseMaterials />} /> {/* uploading modules/lessons/files */}
        <Route path="achievements" element={<InstructorAchievements />} />
      </Route>

      {/* student side manages its own tabs internally, no child routes needed */}
      <Route
        path="/student/*"
        element={
          <ProtectedRoute allowedRoles={['student']}>
            <StudentDashboard user={user} onLogout={handleLogout} />
          </ProtectedRoute>
        }
      />

      {/* admin side, same deal, manages its own tabs internally */}
      <Route
        path="/admin/*"
        element={
          <ProtectedRoute allowedRoles={['administrator']}>
            <AdminDashboard user={user} onLogout={handleLogout} />
          </ProtectedRoute>
        }
      />

      {/* Catch All */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    )}
    </>
  )
}

// Main App component
function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  )
}

export default App
