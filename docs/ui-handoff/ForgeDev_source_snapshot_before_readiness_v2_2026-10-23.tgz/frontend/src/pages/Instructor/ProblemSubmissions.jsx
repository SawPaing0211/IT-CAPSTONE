import { useState, useEffect } from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import StudentCodeModal from "./StudentCodeModal";
import { API_BASE } from '../../api/client'

export default function ProblemSubmissions() {
  const { problemId } = useParams()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  // where this page came from — falls back to the standalone quests list
  // if it was reached some other way and no "from" was ever set
  const goBack = () => navigate(searchParams.get('from') || '/instructor/problems')
  const [problem, setProblem] = useState(null)
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [error, setError] = useState(null)
  const [viewingSubmissionId, setViewingSubmissionId] = useState(null)

  // Load submission data whenever the problem id changes
  useEffect(() => {
    fetchData()
  }, [problemId])

  // Fetch this problem's submissions and per-student status
  const fetchData = async () => {
    setLoading(true)
    setError(null)
    try {
      const token = localStorage.getItem('token')
      const res = await fetch(
        `${API_BASE}/api/instructor/problems/${problemId}/submissions`,
        { headers: { 'Authorization': `Bearer ${token}` } }
      )
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Failed to fetch submissions')
      }
      const data = await res.json()
      setProblem(data.problem)
      setStudents(data.students)
    } catch (err) {
      console.error('Failed to fetch data:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // Filter students by submission status
  const filteredStudents = students.filter(student => {
    if (filter === 'submitted') return student.submitted
    if (filter === 'pending') return !student.submitted
    return true
  })

  // Compute submission counts and the average score across submitted students
  const submittedCount = students.filter(s => s.submitted).length
  const pendingCount = students.filter(s => !s.submitted).length
  const avgScore = submittedCount > 0
    ? Math.round(students.filter(s => s.submitted).reduce((acc, s) => acc + s.score, 0) / submittedCount)
    : 0

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent mx-auto mb-4"></div>
        Loading submissions...
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <p className="text-red-400 mb-4">⚠️ {error}</p>
        <button
          onClick={goBack}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300"
        >
          ← Back to Problems
        </button>
      </div>
    )
  }

  if (!problem) {
    return (
      <div className="text-center py-20 text-red-400">Problem not found</div>
    )
  }

  return (
    <div className="space-y-6">

      {/* Modal */}
      {viewingSubmissionId && (
        <StudentCodeModal
          submissionId={viewingSubmissionId}
          onClose={() => setViewingSubmissionId(null)}
        />
      )}

      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <button
            onClick={goBack}
            className="shrink-0 min-w-[44px] min-h-[44px] flex items-center justify-center text-slate-400 hover:text-white transition rounded-lg hover:bg-slate-800"
            aria-label="Back"
          >
            <span className="sm:hidden text-xl">←</span>
            <span className="hidden sm:inline">← Back</span>
          </button>
          <div className="min-w-0">
            <h1 className="text-lg sm:text-2xl font-bold text-white truncate">{problem.title}</h1>
            <p className="text-slate-400 text-xs sm:text-base">Submission Overview</p>
          </div>
        </div>
        <button
          onClick={fetchData}
          className="px-4 py-2 min-h-[44px] bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 font-medium transition shrink-0"
        >
          🔄 Refresh
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-slate-400 text-sm">Total Students</p>
          <p className="text-2xl font-bold text-white">{students.length}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-slate-400 text-sm">Submitted</p>
          <p className="text-2xl font-bold text-green-400">{submittedCount}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-slate-400 text-sm">Pending</p>
          <p className="text-2xl font-bold text-yellow-400">{pendingCount}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-slate-400 text-sm">Avg Score</p>
          <p className="text-2xl font-bold text-blue-400">{avgScore} XP</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {[
          { key: 'all', label: `All (${students.length})`, active: 'bg-blue-600' },
          { key: 'submitted', label: `Submitted (${submittedCount})`, active: 'bg-green-600' },
          { key: 'pending', label: `Pending (${pendingCount})`, active: 'bg-yellow-600' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-4 py-2 min-h-[44px] rounded-lg font-medium transition shrink-0 whitespace-nowrap ${
              filter === tab.key
                ? `${tab.active} text-white`
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-x-auto">
        <table className="w-full text-left min-w-[640px]">
          <thead className="bg-slate-800/50 text-slate-400 text-sm">
            <tr>
              <th className="p-3 sm:p-4 font-medium">Student</th>
              <th className="p-3 sm:p-4 font-medium">Status</th>
              <th className="p-3 sm:p-4 font-medium">Score</th>
              <th className="p-3 sm:p-4 font-medium hidden md:table-cell">Language</th>
              <th className="p-3 sm:p-4 font-medium hidden lg:table-cell">Submitted At</th>
              <th className="p-3 sm:p-4 font-medium">Code</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {filteredStudents.length === 0 ? (
              <tr>
                <td colSpan="6" className="p-8 text-center text-slate-500">
                  {students.length === 0
                    ? 'No students enrolled in your classes yet.'
                    : 'No students match this filter.'}
                </td>
              </tr>
            ) : (
              filteredStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-800/30 transition">

                  {/* Student */}
                  <td className="p-3 sm:p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center font-bold text-sm">
                        {(student.full_name || student.username)[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-white">{student.full_name || student.username}</p>
                        <p className="text-slate-500 text-xs">{student.username} · {student.email}</p>
                      </div>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-3 sm:p-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      !student.submitted
                        ? 'bg-slate-700/50 text-slate-400'
                        : student.status === 'accepted'
                        ? 'bg-green-600/20 text-green-400'
                        : student.status === 'partial'
                        ? 'bg-blue-600/20 text-blue-400'
                        : student.status === 'wrong_answer'
                        ? 'bg-yellow-600/20 text-yellow-400'
                        : 'bg-red-600/20 text-red-400'
                    }`}>
                      {!student.submitted ? '⏳ Not Submitted'
                        : student.status === 'accepted'      ? '✅ Accepted'
                        : student.status === 'partial'       ? '⚡ Partial'
                        : student.status === 'wrong_answer'  ? '⚠️ Wrong Answer'
                        : student.status === 'timeout'       ? '⏱️ Timeout'
                        : student.status === 'compile_error' ? '🔴 Compile Error'
                        : student.status === 'error'         ? '❌ Error'
                        : `📝 ${student.status}`}
                    </span>
                  </td>

                  {/* Score */}
                  <td className="p-3 sm:p-4">
                    {student.submitted
                      ? <span className="text-yellow-400 font-mono font-bold">{student.score} XP</span>
                      : <span className="text-slate-500">—</span>}
                  </td>

                  {/* Language */}
                  <td className="p-4 hidden md:table-cell">
                    {student.language
                      ? <span className="text-slate-300 text-sm">
                          {student.language === 'python' ? '🐍'
                            : student.language === 'java' ? '☕' : '🔷'} {student.language}
                        </span>
                      : <span className="text-slate-500">—</span>}
                  </td>

                  {/* Submitted At */}
                  <td className="p-4 text-slate-400 text-sm hidden lg:table-cell">
                    {student.submitted_at
                      ? new Date(student.submitted_at).toLocaleString()
                      : '—'}
                  </td>

                  {/* View Code */}
                  <td className="p-3 sm:p-4">
                    {student.submission_id ? (
                      <button
                        onClick={() => setViewingSubmissionId(student.submission_id)}
                        className="px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-600/40 hover:border-blue-600 rounded-lg text-xs font-medium transition-all duration-150"
                      >
                        {'</>'}  View Code
                      </button>
                    ) : (
                      <span className="text-slate-600 text-xs">No submission</span>
                    )}
                  </td>

                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}