import { useState, useEffect } from "react";
import DownloadIcon from "../../components/DownloadIcon";
import { API_BASE } from '../../api/client'

export default function StudentLessons({ subjectId, sectionId, sectionName }) {
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch lessons for the current subject
  useEffect(() => {
    const fetchLessons = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!sectionId) {
          setLessons([]);
          setLoading(false);
          return;
        }
        const res = await fetch(
          `${API_BASE}/api/student/lessons?section_id=${sectionId}`,
          { headers: { Authorization: `Bearer ${token}` } },
        );
        if (res.ok) {
          const data = await res.json();
          // Lessons are scoped to this exact class code by the backend
          // (section_id filter) -- a module uploaded for another section
          // of the same subject never shows up here.
          setLessons(data);
        }
      } catch (err) {
        console.error("Failed to fetch lessons:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchLessons();
  }, [subjectId, sectionId]);

  // Download a lesson file
  const handleDownload = async (lessonId, fileId, filename) => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `${API_BASE}/api/lessons/${lessonId}/files/${fileId}/download`,
        { headers: { Authorization: `Bearer ${token}` } },
      );
      if (!res.ok) {
        alert("Download failed");
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Download error:", err);
      alert("Download failed");
    }
  };

  // Pick a display icon for the file's type
  const getFileIcon = (fileType) => {
    if (fileType === "pdf") return "📄";
    if (fileType === "ppt" || fileType === "pptx") return "📊";
    if (fileType === "doc" || fileType === "docx") return "📝";
    if (fileType === "zip") return "📦";
    return "📎";
  };

  // Show skeleton week-cards while lessons are being fetched
  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
        <div>
          <div className="h-7 bg-slate-800 rounded w-56 mb-2 animate-pulse" />
          <div className="h-4 bg-slate-800 rounded w-40 animate-pulse" />
        </div>
        {[...Array(2)].map((_, w) => (
          <div key={w} className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 space-y-3 animate-pulse">
            <div className="h-5 bg-slate-800 rounded w-28 mb-2" />
            {[...Array(2)].map((_, r) => (
              <div key={r} className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                <div className="h-4 bg-slate-700 rounded w-1/2 mb-2" />
                <div className="h-3 bg-slate-700 rounded w-full" />
              </div>
            ))}
          </div>
        ))}
      </div>
    );
  }

  // Show an empty state when no lessons have been uploaded yet
  if (lessons.length === 0) {
    return (
      <div className="p-4 sm:p-6 max-w-6xl mx-auto">
        <div className="text-center py-20">
          <div className="text-6xl mb-4">📚</div>
          <h2 className="text-2xl font-bold text-white mb-2">No Lessons Yet</h2>
          <p className="text-slate-400">
            Your instructor hasn't uploaded any lessons for {sectionName} yet.
          </p>
        </div>
      </div>
    );
  }

  // Group lessons by week
  const lessonsByWeek = lessons.reduce((acc, lesson) => {
    const week = `Week ${lesson.week_number}`;
    if (!acc[week]) acc[week] = [];
    acc[week].push(lesson);
    return acc;
  }, {});

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">📚 Course Lessons</h2>
        <p className="text-slate-400">Learning materials for {sectionName}</p>
      </div>

      {/* Lessons by Week */}
      {Object.entries(lessonsByWeek).map(([week, weekLessons]) => (
        <div
          key={week}
          className="bg-slate-900/50 border border-slate-800 rounded-xl p-6"
        >
          <h3 className="text-lg font-bold text-purple-400 mb-4 flex items-center gap-2">
            <span>📅</span> {week}
          </h3>
          <div className="space-y-3">
            {weekLessons.map((lesson) => (
              <div
                key={lesson.id}
                className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 hover:border-purple-500/50 transition"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-bold text-white mb-1">
                      {lesson.title}
                    </h4>
                    <p className="text-sm text-slate-400 mb-3">
                      {lesson.description}
                    </p>

                    {/* Files */}
                    {lesson.files && lesson.files.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">
                          📎 Files
                        </p>
                        {lesson.files.map((file) => (
                          <div
                            key={file.id}
                            className="flex items-center gap-3 w-full px-3 py-2 bg-slate-700/50 rounded-lg"
                          >
                            <span className="text-lg">
                              {getFileIcon(file.file_type)}
                            </span>
                            <span className="text-sm text-slate-300 flex-1 truncate">
                              {file.filename}
                            </span>
                            <span className="text-xs text-slate-600 flex-shrink-0 italic mr-2">
                              .{file.file_type}
                            </span>
                            <button
                              onClick={() =>
                                handleDownload(
                                  lesson.id,
                                  file.id,
                                  file.filename,
                                )
                              }
                              title={`Download ${file.filename}`}
                              aria-label={`Download ${file.filename}`}
                              className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-purple-600/30 hover:bg-purple-600 border border-purple-600/40 rounded-full text-purple-300 hover:text-white transition"
                            >
                              <DownloadIcon size={15} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
